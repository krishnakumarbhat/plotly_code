import numpy as np
from scipy.stats import multivariate_normal

from radardetseval.simulation.Iface import SinglePointSimOut
from radardetseval.utilities.cart_state_to_polar_state import cart_state_to_polar_state


def sim_det_from_scs_cart_point(ref_state_cart: np.array, ref_cov: np.array, meas_cov: np.array, N_samples=1):
    """
    Function to simulate single detections from single reference detection. reference and measurement covariances
    need to be defined

    :param ref_state_cart: reference state: [x, y, vx, vy] - 1d array
    :param ref_cov: covariance matrix for corresponding state
    :param meas_cov: covariance matrix for measurement (should be diagonal)
    :param N_samples: number of samples of samples to be draw, default 1
    :return:
    """
    size = [N_samples, 1]

    # Simulate reference
    sim_ref_state_cart = multivariate_normal.rvs(mean=ref_state_cart, cov=ref_cov, size=size)
    sim_ref_range, sim_ref_azimuth, sim_ref_range_rate, sim_ref_cross_radial_vel = \
        cart_state_to_polar_state(sim_ref_state_cart[:, 0],
                                  sim_ref_state_cart[:, 1],
                                  sim_ref_state_cart[:, 2],
                                  sim_ref_state_cart[:, 3])

    ref_range, ref_azimuth, ref_range_rate, ref_cross_radial_vel = \
        cart_state_to_polar_state(ref_state_cart[0],
                                  ref_state_cart[1],
                                  ref_state_cart[2],
                                  ref_state_cart[3])

    ref_state_polar = np.array([ref_range, ref_azimuth, ref_range_rate])

    sim_measurement = multivariate_normal.rvs(mean=ref_state_polar, cov=meas_cov, size=size)

    # Populate outputs
    outputs = SinglePointSimOut()
    outputs.ref_x = ref_state_cart[0]
    outputs.ref_y = ref_state_cart[1]
    outputs.ref_vx = ref_state_cart[2]
    outputs.ref_vy = ref_state_cart[3]
    outputs.ref_range = ref_range
    outputs.ref_azimuth = ref_azimuth
    outputs.ref_range_rate = ref_range_rate
    outputs.ref_cross_radial_vel = ref_cross_radial_vel
    outputs.ref_cov = ref_cov
    outputs.meas_cov = meas_cov

    outputs.signals["sim_ref_x"] = sim_ref_state_cart[:, 0]
    outputs.signals["sim_ref_y"] = sim_ref_state_cart[:, 1]
    outputs.signals["sim_ref_vx"] = sim_ref_state_cart[:, 2]
    outputs.signals["sim_ref_vy"] = sim_ref_state_cart[:, 3]

    outputs.signals["sim_ref_range"] = sim_ref_range
    outputs.signals["sim_ref_azimuth"] = sim_ref_azimuth
    outputs.signals["sim_ref_range_rate"] = sim_ref_range_rate
    outputs.signals["sim_ref_cross_radial_vel"] = sim_ref_cross_radial_vel

    outputs.signals["sim_meas_range"] = sim_measurement[:, 0]
    outputs.signals["sim_meas_azimuth"] = sim_measurement[:, 1]
    outputs.signals["sim_meas_range_rate"] = sim_measurement[:, 2]

    return outputs



