import pickle
import numpy as np
import matplotlib.pyplot as plt

from radardetseval.Iface.PolyLineDS import PolyLineDS
from radardetseval.utilities.ecdf import ecdf
from scipy.stats import chi2

from radardetseval.visualization.plot_polyline import plot_polyline, plot_polyline_range_rates
from radardetseval.visualization.plot_sensor import plot_sensor


def visualize_results(df):

    chi2_dof = [2.0, 2.5, 3.0]  # 3 variables so 3 degree of freedom
    x_ref = np.linspace(0, 20, 1000)
    n_bins = 20

    plt.figure()
    plt.subplot(3, 1, 1)
    for dof in chi2_dof:
        y_ref = chi2.pdf(x_ref, dof)
        plt.plot(x_ref, y_ref, label=f'Chi-square with k = {dof:.1f}')
    df['nees_value'].hist(bins=n_bins, density=True, label='NEES from sim')
    plt.ylabel('Density [-]')
    plt.title('NEES distribution of simulated detection')
    plt.legend()

    plt.subplot(3, 1, 2)
    x_ecdf, y_ecdf = ecdf(df['nees_value'])

    for dof in chi2_dof:
        y_ref_cdf = chi2.cdf(x_ref, dof)
        plt.plot(x_ref, y_ref_cdf, label=f'Chi-square with k = {dof:.1f}')
    plt.plot(x_ecdf, y_ecdf, label='NEES from sim')
    plt.ylabel('Quantile [-]')
    plt.title('NEES cumulative distribution of simulated detection')
    plt.grid()
    plt.legend()

    plt.subplot(3, 1, 3)
    for dof in chi2_dof:
        y_ref_ecdf = chi2.cdf(x_ecdf, dof)
        ecdf_diff = y_ecdf - y_ref_ecdf
        plt.plot(x_ecdf, ecdf_diff, label=f'Chi-square with k = {dof:.1f}')
    plt.xlabel('NEES value [-]')
    plt.ylabel('CDF difference [-]')
    plt.grid()
    plt.legend()
    plt.xlim([0, 20])
    plt.title('Difference between empirical and reference cumulative distribution')


data_path = r'private\sim_line_out_vel_0.pickle'

with open(data_path, 'rb') as handle:
    data = pickle.load(handle)

sim_out_00_df = data['sim_out_00_df']
sim_out_05_df = data['sim_out_05_df']
sim_out_025_df = data['sim_out_025_df']
sim_out_1_df = data['sim_out_1_df']
gt_polyline = data['gt_polyline']

visualize_results(sim_out_00_df)
visualize_results(sim_out_05_df)
visualize_results(sim_out_025_df)
visualize_results(sim_out_1_df)

fig0, ax0 = plt.subplots()
plot_sensor(ax0, azimuth=np.deg2rad(75.0), max_range=15.0)
plot_polyline(ax0, gt_polyline)
gt_polyline.signals = gt_polyline.discretize_single_polygon(gt_polyline.signals, 0.5)
plot_polyline_range_rates(ax0, gt_polyline)
ax0.axis('equal')
ax0.grid()

df = sim_out_1_df
ref_vertex_id = 1.0

poly_length_array = PolyLineDS.calc_segment_lengths_in_polygon(gt_polyline.signals)
df['distance'] = (df['vertex_id'] - ref_vertex_id) * poly_length_array.sum()
fig0, ax0 = plt.subplots()
df['distance'].hist(bins=100, density=True, label='NEES from sim')

