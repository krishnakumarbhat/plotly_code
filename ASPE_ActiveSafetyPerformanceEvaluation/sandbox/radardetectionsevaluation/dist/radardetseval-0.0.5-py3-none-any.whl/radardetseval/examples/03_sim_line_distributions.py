import pickle

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from time import time
from tqdm import tqdm

from radardetseval.Iface.PolyLineDS import PolyLineDS

# Setup
from radardetseval.association.nearest_point_on_line import find_nearest_point_on_line_minimize
from radardetseval.simulation.DetFromPolyLineSim import DetFromPolyLineSim
from radardetseval.simulation.PolyLineSim import PolyLineSim
from radardetseval.visualization.plot_polyline import plot_polyline, plot_polyline_range_rates
from radardetseval.visualization.plot_sensor import plot_sensor

data_path = r'private\sim_line_out_vel_0.pickle'

ref_pos_std = 0.05
ref_vel_std = 0.1

range_std = 0.2
azimuth_std = np.deg2rad(0.3)
range_rate_std = 0.06

dl = 0.01

meas_cov = np.power(np.diag([range_std, azimuth_std, range_rate_std]), 2.0)
ref_cov = np.power(np.diag([ref_pos_std, ref_pos_std, ref_vel_std, ref_vel_std]), 2)


gt_polyline = PolyLineDS()
gt_polyline.add_point(4, -4, 0, 0)
gt_polyline.add_point(4, 12, 0, 0)

polyline_simulator = PolyLineSim(gt_polyline)
det_simulator = DetFromPolyLineSim(gt_polyline)

n_simulations = 1000

sim_out_00 = list()
sim_out_05 = list()
sim_out_025 = list()
sim_out_1 = list()

t1 = time()

for i in tqdm(range(n_simulations)):
    sim_polyline_cons_dev = polyline_simulator.sim_with_the_same_deviation(ref_cov)

    detection = det_simulator.sim_single_point_from_vertex(meas_cov, vertex_id=0.0)
    sim_out_00.append(find_nearest_point_on_line_minimize(sim_polyline_cons_dev, detection))

    detection = det_simulator.sim_single_point_from_vertex(meas_cov, vertex_id=0.25)
    sim_out_025.append(find_nearest_point_on_line_minimize(sim_polyline_cons_dev, detection))

    detection = det_simulator.sim_single_point_from_vertex(meas_cov, vertex_id=0.5)
    sim_out_05.append(find_nearest_point_on_line_minimize(sim_polyline_cons_dev, detection))

    detection = det_simulator.sim_single_point_from_vertex(meas_cov, vertex_id=1.0)
    sim_out_1.append(find_nearest_point_on_line_minimize(sim_polyline_cons_dev, detection))
t2 = time()
print('Simulation time [s] ', t2 - t1)

sim_out_00_df = pd.DataFrame(sim_out_00)
sim_out_025_df = pd.DataFrame(sim_out_025)
sim_out_05_df = pd.DataFrame(sim_out_05)
sim_out_1_df = pd.DataFrame(sim_out_1)

data = {'gt_polyline': gt_polyline,
        'sim_out_00_df': sim_out_00_df,
        'sim_out_025_df': sim_out_025_df,
        'sim_out_05_df': sim_out_05_df,
        'sim_out_1_df': sim_out_1_df}


with open(data_path, 'wb') as handle:
    pickle.dump(data, handle, protocol=pickle.HIGHEST_PROTOCOL)


