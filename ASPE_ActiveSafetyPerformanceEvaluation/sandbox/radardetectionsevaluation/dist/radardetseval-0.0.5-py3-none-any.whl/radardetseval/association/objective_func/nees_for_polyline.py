import numpy as np

from radardetseval.Iface.Detection import Detection
from radardetseval.Iface.PolyLineDS import PolyLineDS
from radardetseval.stats.nees import nees_value
from radardetseval.unc_prop.pos_vel_cart_to_polar import pos_vel_cart_to_polar
from radardetseval.utilities.cart_state_to_polar_state import cart_state_to_polar_state


def nees_value_for_single_vertex_id(vertex_id: float, polyline: PolyLineDS, detection: Detection, unique_id=0.0):
    polygon = polyline.signals[polyline.signals.unique_id == unique_id]
    vertex_ids = polygon['vertex_id'].values
    single_point_df = polyline.interpolate_polygon(np.array([vertex_id]), vertex_ids, polygon)
    point_series = single_point_df.iloc[0, :]
    ref_range, ref_azimuth, ref_range_rate, _ = cart_state_to_polar_state(point_series.x,
                                                                          point_series.y,
                                                                          point_series.vx,
                                                                          point_series.vy)

    ref_cov_polar = pos_vel_cart_to_polar(point_series.x,
                                          point_series.y,
                                          point_series.vx,
                                          point_series.vy,
                                          point_series.cov_matrix)

    det_cov = np.diag([detection.det_range_var, detection.det_azimuth_var, detection.det_range_rate_var])
    cov_sum = ref_cov_polar + det_cov

    deviation = np.array([ref_range - detection.det_range,
                          ref_azimuth - detection.det_azimuth,
                          ref_range_rate - detection.det_range_rate])

    nees = nees_value(deviation, cov_sum)
    return nees


def nees_value_for_vertex_ids(vertex_ids: np.array, polyline: PolyLineDS, detection: Detection, unique_id=0.0):
    nees = np.zeros_like(vertex_ids)

    for i, vertex_id in enumerate(vertex_ids):
        nees[i] = nees_value_for_single_vertex_id(vertex_id, polyline, detection, unique_id)

    return nees

