from PyQt5.QtGui import QColor
from aspe.evaluation.RadarObjectsEvaluation.BinaryClassification import BCType
from aspe.gui.drawers.abstract_drawers.DrawerComposite import DrawerComposite
from aspe.gui.drawers.DrawerPoints import DrawerPoints


class DrawerBinaryClassification(DrawerComposite):
    def __init__(self, parent, extracted_data_set, plot_item, name):
        super().__init__(parent, extracted_data_set, plot_item, name)

    def create_selection_drawer(self, plot_item):
        return None

    def create_drawers(self, plot_item):
        true_positives_drawer = DrawerPoints(self, 'TruePositives', plot_item, symbol='o', color=QColor(0, 255, 128), symbol_size=8)
        false_positives_drawer = DrawerPoints(self, 'FalsePositives', plot_item, symbol='o', color=QColor(255, 0, 0), symbol_size=8)
        false_negatives_drawer = DrawerPoints(self, 'FalseNegatives', plot_item, symbol='o', color=QColor(255, 255, 0), symbol_size=8)

        true_positives_drawer.set_data(self.data_set.loc[self.data_set.binary_classification == BCType.TruePositive, :], 'center_x', 'center_y')
        false_positives_drawer.set_data(self.data_set.loc[self.data_set.binary_classification == BCType.FalsePositive, :], 'center_x', 'center_y')
        false_negatives_drawer.set_data(self.data_set.loc[self.data_set.binary_classification == BCType.FalseNegative, :], 'center_x', 'center_y')

        return [true_positives_drawer, false_positives_drawer, false_negatives_drawer]

    def select(self, df_index):
        pass

