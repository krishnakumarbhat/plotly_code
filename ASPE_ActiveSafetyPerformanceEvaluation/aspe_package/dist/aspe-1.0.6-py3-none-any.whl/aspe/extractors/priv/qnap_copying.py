from pathlib import Path
from glob import glob
from shutil import copyfile
from tqdm import tqdm
import re


def copy_scenario_from_given_folder(qnap_dir: Path, output_dir: Path, scenario: str, folder_name: str):
    file_paths = [p for p in (qnap_dir / folder_name).glob(f'*{scenario}*.MF4')]

    dst_dir = output_dir / folder_name
    dst_dir.mkdir(exist_ok=True, parents=True)

    for src in tqdm(file_paths):
        print(f'Copying {src.name}')
        dst = dst_dir / src.name
        copyfile(src, dst)


def copy_scenario_using_log_list(qnap_dir: Path, output_dir: Path, scenario: str, folder_name: str, log_list: str):
    mf4_files = [str(p) for p in ((qnap_dir / folder_name).glob(f'*{scenario}*.MF4'))]
    paths_to_cp = []
    for p in log_list:
        date = re.search(r'\d{8}_\d{6}', p).group()
        number = re.search(r'_\d{4}[_.]', p).group().replace('_', '').replace('.', '')
        matching_paths = [file for file in mf4_files if date in file and number in file]
        if len(matching_paths) == 1:
            paths_to_cp.append(Path(matching_paths[0]))
        else:
            print('dupa')
    dst_dir = output_dir / folder_name
    dst_dir.mkdir(exist_ok=True)

    for src in tqdm(paths_to_cp):
        print(f'Copying {src.name}')
        dst = dst_dir / src.name
        copyfile(src, dst)

log_list = [
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_40_L_C_BN_FASETH_WBATR91070LC63638_20200618_131107_fas_0000.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_40_L_C_BN_FASETH_WBATR91070LC63638_20200618_131107_fas_0001.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_40_L_F_BN_FASETH_WBATR91070LC63638_20200618_130843_fas_0000.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_40_L_F_BN_FASETH_WBATR91070LC63638_20200618_130843_fas_0007.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_40_R_C_BN_FASETH_WBATR91070LC63638_20200618_131848_fas_0000.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_40_R_C_BN_FASETH_WBATR91070LC63638_20200618_131848_fas_0007.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_50_L_C_BN_FASETH_WBATR91070LC63638_20200618_132618_fas_0000.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_50_L_C_BN_FASETH_WBATR91070LC63638_20200618_132618_fas_0006.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_50_R_C_BN_FASETH_WBATR91070LC63638_20200618_133247_fas_0000.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_50_R_C_BN_FASETH_WBATR91070LC63638_20200618_133247_fas_0001.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_L_C_BN_FASETH_WBATR91070LC63638_20200618_133945_fas_0000.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_L_F_BN_FASETH_WBATR91070LC63638_20200618_133759_fas_0001.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_L_C_BN_FASETH_WBATR91070LC63638_20200618_140034_fas_0000.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_L_C_BN_FASETH_WBATR91070LC63638_20200618_140034_fas_0001.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_L_R_BN_FASETH_WBATR91070LC63638_20200618_140212_fas_0001.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_L_R_BN_FASETH_WBATR91070LC63638_20200618_140212_fas_0004.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_R_C_BN_FASETH_WBATR91070LC63638_20200618_140712_fas_0000.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_R_C_BN_FASETH_WBATR91070LC63638_20200618_140712_fas_0001.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_R_C_BN_FASETH_WBATR91070LC63638_20200618_140712_fas_0002.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_R_C_BN_FASETH_WBATR91070LC63638_20200618_140712_fas_0003.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_R_C_BN_FASETH_WBATR91070LC63638_20200618_140712_fas_0004.MF4",
    r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_24_60_OSCIL_R_F_BN_FASETH_WBATR91070LC63638_20200618_140530_fas_0001.MF4",
]

if __name__ == '__main__':
    qnap_dir = Path(r"C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\ALL\far")
    output_dir = Path(r'C:\logs\VTV_mf4_logs\A370\DS_24_side_collision\A430_ATS+6\FAR')

    copy_scenario_using_log_list(qnap_dir, output_dir, scenario='DS_24', folder_name='SRR_REFERENCE', log_list=log_list)
