from aspe.extractors import extract_f360_from_mudp
from aspe.extractors.Interfaces.Enums.Object import MovementStatus
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def calc_dets_azimuth_vcs(extracted_data, wrap=True):
    if extracted_data.detections is not None:
        dets = extracted_data.detections.signals
        if extracted_data.sensors is not None:
            sensors = extracted_data.sensors.per_sensor
            dets_w_sensors = dets.join(sensors.set_index('sensor_id'), on='sensor_id', rsuffix='_sensor')
            dets['azimuth_vcs'] = dets_w_sensors.azimuth + dets_w_sensors.boresight_az_angle
        else:
            dets['azimuth_vcs'] = np.arctan2(dets['position_y'], dets['position_x'])
        if wrap:
            below_0 = dets.loc[:, 'azimuth_vcs'] < 0
            dets.loc[below_0, 'azimuth_vcs'] = dets.loc[below_0, 'azimuth_vcs'] + 2*np.pi


def get_moving_dets(extracted_data):
    calc_dets_azimuth_vcs(extracted_data)
    dets = extracted.detections
    dets = dets.signals.join(dets.raw_signals, rsuffix='_raw')
    moving_dets = dets.loc[dets.motion_status == 1, :]
    return moving_dets


def get_relevant_objects(objs, n_objects=4):
    moving_filter = objs.movement_status == MovementStatus.MOVING
    orientation_gates = (np.deg2rad(-45), np.deg2rad(45))
    heading_filter = (orientation_gates[0] < objs.bounding_box_orientation) & (objs.bounding_box_orientation < orientation_gates[1])

    objs_filtered = objs.loc[moving_filter & heading_filter, :]
    counted_instances = objs_filtered.groupby('unique_id').count().sort_values(by='scan_index', ascending=False)
    target_unique_ids = counted_instances.scan_index.head(n_objects)

    target = objs.loc[objs.unique_id.isin(target_unique_ids.index), :]
    return target


def get_target_assoc_dets(target, dets):
    target_id = target.id.iloc[0]
    target_dets = dets.loc[dets.assigned_obj_id == target_id, :]
    return target_dets


def filter_data_set_by_roi(data_set, roi_x=(-np.inf, np.inf), roi_y=(-10, 10)):
    x_filter = (roi_x[0] < data_set.position_x) & (data_set.position_x < roi_x[1])
    y_filter = (roi_y[0] < data_set.position_y) & (data_set.position_y < roi_y[1])
    ds_filtered = data_set.loc[x_filter & y_filter, :]
    return ds_filtered


def mark_detections(axes, dets, flag_to_use, marker_type, marker_size, points_label, mark_positives=True):
    if mark_positives:
        filter = dets.loc[:, flag_to_use] == 1
    else:
        filter = dets.loc[:, flag_to_use] == 0

    dets_filtered = dets.loc[filter, :]
    dets_filtered.plot.scatter('position_y', 'position_x', marker=marker_type, s=marker_size, label=points_label, ax=axes, c='none', edgecolor='black')


def extrapolate_target(target, scan_indexes_to_extrapolate, dt=0.05):
    target_si = target.loc[:, 'scan_index'].to_numpy()

    initial_vel = target.loc[:, 'velocity_otg_x'].head(20).median()
    initial_lat_pos = target.loc[:, 'position_y'].median()
    initial_lon_pos = target['position_x'].iloc[0]

    first_target_si = target_si.min()
    first_si_to_interp = scan_indexes_to_extrapolate.min()
    si_count = first_target_si - first_si_to_interp

    pos_diff = si_count*dt * initial_vel
    start_pos = initial_lon_pos - pos_diff
    si_to_extrpl = np.arange(first_si_to_interp, first_target_si)
    extrp_pos_x = np.interp(si_to_extrpl, [first_si_to_interp, first_target_si], [start_pos, initial_lon_pos])

    mask = -130 < extrp_pos_x
    extrp_pos_x = extrp_pos_x[mask]
    si_to_extrpl = si_to_extrpl[mask]

    extrp_obj = pd.DataFrame({
        'scan_index': si_to_extrpl,
        'position_x': extrp_pos_x,
        'position_y': np.full(len(extrp_pos_x), initial_lat_pos),
        'velocity_otg_x': np.full(len(extrp_pos_x), initial_vel),
    })
    extrp_target = target.append(extrp_obj).sort_values('scan_index').reset_index(drop=True)
    return extrp_target


def get_target_dets_by_range_rates(target, dets, sensors, rrate_gate=5):
    target_exp = extrapolate_target(target, dets['scan_index'].to_numpy())
    target = target_exp.set_index('scan_index').loc[:, ['position_x', 'position_y', 'velocity_otg_x']]
    sensors = sensors.set_index('sensor_id')

    filtered_dets = []
    for (scan_index, sensor_id), dets_scan in dets.groupby(by=['scan_index', 'sensor_id']):
        sensor_x, sensor_y = sensors.loc[sensor_id, 'position_x'], sensors.loc[sensor_id, 'position_y']
        if scan_index in target.index:
            target_x = target.loc[scan_index, 'position_x'] + sensor_x
            target_y = target.loc[scan_index, 'position_y'] + sensor_y
            target_vel = target.loc[scan_index, 'velocity_otg_x']
            target_az = np.arctan2(target_y, target_x)
            predicted_rrate = target_vel*np.cos(2*np.pi - target_az)
            min_rrate, max_rrate = predicted_rrate - rrate_gate / 2, predicted_rrate + rrate_gate / 2
            rrate_filter = (min_rrate < dets_scan.loc[:, 'range_rate_comp']) & (dets_scan.loc[:, 'range_rate_comp'] < max_rrate)
            filtered_dets.append(dets_scan.loc[rrate_filter, :])
    target_dets = pd.concat(filtered_dets)

    return target_dets


def set_axes_props(axes):
    axes[0].set_xlim(roi_y)
    axes[0].set_ylim(roi_x)
    for ax in axes:
        ax.grid()


def plot_top_n_targets(objects, detections, axes, n_to_plot=4):
    COLOR_PALETTE = ['#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf',
                    '#1f77b4']

    targets = get_relevant_objects(objects, n_objects=n_to_plot)
    for obj_num, (unique_id, target) in enumerate(targets.groupby(by='unique_id')):
        target_dets = get_target_assoc_dets(target, detections)
        color = COLOR_PALETTE[obj_num]
        target.plot('position_y', 'position_x', ax=axes[0], lw=2, c=color, label=f'object_{obj_num}')
        target_dets.plot.scatter('azimuth_vcs', 'range_rate_comp', ax=axes[1], s=2, c=color, label=f'object_{obj_num}')


if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"
    mudp_log_file_path = r"C:\logs\homologation_motorbike_issues\20201106T110145_20201106T110205_541618_H019172_SRR_DEBUG.mudp"
    roi_x = [-110, -30]
    roi_y = [-30, 30]

    extracted = extract_f360_from_mudp(mudp_log_file_path, mudp_stream_def_path=mudp_stream_def_path, raw_signals=True,
                                       detections=True, sensors=True, internal_objects=True, save_to_file=True)

    moving_dets = get_moving_dets(extracted)
    moving_dets = filter_data_set_by_roi(moving_dets, roi_x=roi_x, roi_y=roi_y)

    objs = extracted.internal_objects.signals
    objs = filter_data_set_by_roi(objs, roi_x=roi_x, roi_y=roi_y)

    rel_target = get_relevant_objects(objs, n_objects=1)
    target_dets = get_target_dets_by_range_rates(rel_target, moving_dets, extracted.sensors.per_sensor)

    f, axes = plt.subplots(ncols=2, figsize=(16, 8))

    target_dets.plot.scatter('position_y', 'position_x', c='range_rate_comp', colormap='jet', ax=axes[0])
    target_dets.plot.scatter('azimuth_vcs', 'range_rate_comp', ax=axes[1], marker='+', s=50)

    plot_top_n_targets(objs, moving_dets, axes=axes, n_to_plot=4)
    mark_detections(axes[0], moving_dets, flag_to_use='f_ok_to_use', marker_type='s', marker_size=30, points_label='not f_ok_to_use', mark_positives=False,)
    mark_detections(axes[0], moving_dets, flag_to_use='f_azimuth_error', marker_type='d', marker_size=30, points_label='f_azimuth_error')

    set_axes_props(axes)
