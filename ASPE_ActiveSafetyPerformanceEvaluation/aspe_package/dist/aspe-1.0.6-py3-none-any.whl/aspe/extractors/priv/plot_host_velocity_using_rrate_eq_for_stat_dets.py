from aspe.extractors.API.mudp import extract_f360_from_mudp
import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import lstsq
import pandas as pd
from pathlib import Path
from typing import Dict


def plot_host_velocity_using_rrate_eq_for_stat_dets(
        mudp_paths: Dict[str, str],
        mudp_stream_def_path: str,
        signal_to_plot: str,  # 'velocity_otg_x' or 'velocity_otg_y'
        speed_cor_factor: float = 1.0,
        host_vel_scan_shift: int = 0):

    f, axes = plt.subplots(nrows=2, sharex=True, figsize=(12, 6))
    for alias, mudp_path in mudp_paths.items():
        extracted = extract_f360_from_mudp(mudp_path, mudp_stream_def_path=mudp_stream_def_path, raw_signals=True,
                                           detections=True, sensors=True, internal_objects=True, save_to_file=True,
                                           oal_objects=True)
        sensors = extracted.sensors.per_sensor
        dets = extracted.detections.signals

        sensor_bsa = sensors.loc[:, ['sensor_id', 'boresight_az_angle']].set_index('sensor_id', drop=True)
        dets = dets.join(sensor_bsa, on='sensor_id')
        dets['vcs_azimuth'] = dets.loc[:, 'azimuth'] + dets.loc[:, 'boresight_az_angle']

        stat_dets_mask = dets.loc[:, 'motion_status'] == 2
        stat_dets = dets.loc[stat_dets_mask, :]

        output = {
            'scan_index': [],
            'velocity_otg_x': [],
            'velocity_otg_y': []
        }
        for scan_index, single_scan_dets in stat_dets.groupby('scan_index'):
            range_rate = single_scan_dets.loc[:, 'range_rate_dealiased'].to_numpy()
            vcs_azimuth = single_scan_dets.loc[:, 'vcs_azimuth'].to_numpy()

            a_mat = np.vstack([np.cos(vcs_azimuth), np.sin(vcs_azimuth)]).T
            b_mat = range_rate

            x, res, rnk, s = lstsq(a=a_mat, b=b_mat)
            output['scan_index'].append(scan_index)
            output['velocity_otg_x'].append(-x[0])
            output['velocity_otg_y'].append(-x[1])

        host_vel_from_dets = pd.DataFrame(output)

        extracted.host.signals.loc[:, signal_to_plot] = speed_cor_factor * extracted.host.signals.loc[:, signal_to_plot]
        extracted.host.signals.loc[:, 'scan_index'] = extracted.host.signals.loc[:, 'scan_index'] + host_vel_scan_shift

        axes[0].plot(extracted.host.signals.loc[:, 'scan_index'], extracted.host.signals.loc[:, signal_to_plot],
                     label=f'host stream - {alias}')

        extr_host_sub_df = extracted.host.signals.loc[:, ['scan_index', 'velocity_otg_x', 'velocity_otg_y']].set_index(
            'scan_index', drop=True)
        both_vel = host_vel_from_dets.join(extr_host_sub_df, on='scan_index', lsuffix='_rrate_eq', rsuffix='_host')
        vel_diff = both_vel.loc[:, f'{signal_to_plot}_host'] - both_vel.loc[:, f'{signal_to_plot}_rrate_eq']
        axes[1].plot(both_vel.loc[:, 'scan_index'], vel_diff, label=f'{alias}')

    axes[0].plot(host_vel_from_dets.loc[:, 'scan_index'], host_vel_from_dets.loc[:, signal_to_plot],
                 label=f'rrate eq. estimate')

    titles = [f'Host output with rrate equation estimation - {signal_to_plot}',
              f'Difference between host output and rrate equation']
    for ax, title in zip(axes, titles):
        ax.grid()
        ax.legend()
        ax.set_title(title)

    axes[-1].set_xlabel('scan index [-]')
    f.suptitle(Path(list(mudp_paths.values())[0]).name)
    f.tight_layout(rect=[0, 0.03, 1, 0.95])


if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,
    mudp_log_file_path = {
        '': r"C:\logs\VTV_mf4_logs\A370\DS_04_oncomming_traffic\A430_ATS+6\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_04_30_30_L_BN_FASETH_WBATR91070LC63638_20200617_173901_fas_0001.mf4",
    }
    signal_to_plot = 'velocity_otg_x'
    speed_cor_factor = 1.0
    host_vel_scan_shift = 2
    plot_host_velocity_using_rrate_eq_for_stat_dets(mudp_log_file_path, mudp_stream_def_path, signal_to_plot, speed_cor_factor, host_vel_scan_shift)

