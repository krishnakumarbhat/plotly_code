import subprocess

if __name__ == '__main__':
    resim_exe_path = r"C:\wkspaces_git\F360Core\F360TrackerPC_SRR_ESR_vs2015\output\Debug_Win32\resim_f360.exe"
    suffix = '_DEX_435_17fd44e'

    # DEX 450 EVENT LOG
    log_file = [r"C:\logs\DEX_435\20200112T170646_20200112T170656_543078_LB36408_SRR_DEBUG.dvl",
                r"C:\logs\DEX_435\20200112T170656_20200112T170706_543078_LB36408_SRR_DEBUG.dvl"]

    for log in log_file:
        command = f'{resim_exe_path} {log} -dvl -osuffix {suffix} -f360trkopt -xtrklog -init_from_log -sync_input -endopt'
        subprocess.call(command)

    ## DEX 451 LOG
    #log_file = r"C:\logs\DEX-450\log20-29\20200125T175208_20200125T175218_543078_LB36408_SRR_DEBUG.dvl"
    #command = f'{resim_exe_path} {log_file} -dvl -osuffix {suffix} -f360trkopt -xtrklog -init_from_log -sync_input -endopt'
    #subprocess.call(command)