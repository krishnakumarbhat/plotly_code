from aspe.utilities.SupportingFunctions import load_from_pkl
from aspe.utilities.MathFunctions import calc_position_in_bounding_box
import matplotlib.pyplot as plt
import numpy as np

data_path = r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124747_20200131T124807_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle"
extracted = load_from_pkl(data_path)

objects = extracted.objects
dets = extracted.detections

unique_obj_id = 52
ts_threshold = 16240


target_obj_signals = objects.signals.loc[objects.signals.unique_id == unique_obj_id, :]
target_obj_raw_signals = objects.raw_signals.loc[target_obj_signals.index, :]

target_obj_id = target_obj_signals.tracker_id.to_numpy()[0]

target_obj_signals = target_obj_signals.loc[target_obj_signals.timestamp > ts_threshold, :]
first_si = target_obj_signals.scan_index.to_numpy()[0]
last_si = target_obj_signals.scan_index.to_numpy()[-1]

dets.signals = dets.signals.loc[dets.signals.scan_index > first_si, :]
dets.signals = dets.signals.loc[dets.signals.scan_index < last_si, :]
dets.raw_signals = dets.raw_signals.loc[dets.signals.index, :]

target_dets_signals = dets.signals.loc[dets.signals.assigned_obj_id == target_obj_id, :]
target_dets_raw_signals = dets.raw_signals.loc[target_dets_signals.index, :]

bbox_data = target_obj_signals.loc[:, ['scan_index', 'position_x', 'position_y', 'center_x', 'center_y', 'bounding_box_orientation',
                                       'bounding_box_dimensions_x', 'bounding_box_dimensions_y', 'bounding_box_dimensions_refpoint_long_offset_ratio',
                                       'bounding_box_dimensions_refpoint_lat_offset_ratio']]
ref_point_x_in = np.array([0.5] * bbox_data.shape[0])
ref_point_y_in = np.array([0.5] * bbox_data.shape[0])

ref_point_x_out = np.array([1.0] * bbox_data.shape[0])
ref_point_y_out = np.array([0.0] * bbox_data.shape[0])

bbox_ref_x, bbox_ref_y = calc_position_in_bounding_box(bbox_data.center_x.to_numpy(), bbox_data.center_y.to_numpy(),
                                                       bbox_data.bounding_box_dimensions_x.to_numpy(),
                                                       bbox_data.bounding_box_dimensions_y.to_numpy(),
                                                       bbox_data.bounding_box_orientation.to_numpy(),
                                                       ref_point_x_in,
                                                       ref_point_y_in,
                                                       ref_point_x_out,
                                                       ref_point_y_out)

bbox_data.loc[:, 'position_x'] = bbox_ref_x
bbox_data.loc[:, 'position_y'] = bbox_ref_y

dets_signals_bbox = target_dets_signals.join(bbox_data.set_index('scan_index'), on='scan_index', rsuffix='_bbox')

orientation = -dets_signals_bbox.bounding_box_orientation

pos_x_rel = dets_signals_bbox.position_x - dets_signals_bbox.position_x_bbox
pos_y_rel = dets_signals_bbox.position_y - dets_signals_bbox.position_y_bbox

new_x = pos_x_rel * np.cos(orientation) - pos_y_rel * np.sin(orientation)
new_y = pos_x_rel * np.sin(orientation) + pos_y_rel * np.cos(orientation)

target_dets_signals.loc[:, 'position_x_in_bbox'] = new_x
target_dets_signals.loc[:, 'position_y_in_bbox'] = new_y


target_dets_filt = target_dets_signals.loc[target_dets_signals.timestamp > ts_threshold, :]

min_bbox_len = bbox_data.bounding_box_dimensions_x.to_numpy().min()
max_bbox_len = bbox_data.bounding_box_dimensions_x.to_numpy().max()
min_bbox_wid = bbox_data.bounding_box_dimensions_y.to_numpy().min()
max_bbox_wid = bbox_data.bounding_box_dimensions_y.to_numpy().max()

min_bbox_lon = [0, 0, -min_bbox_len, -min_bbox_len, 0]
min_bbox_lat = [0, min_bbox_wid, min_bbox_wid, 0, 0]

max_bbox_lon = [0, 0, -max_bbox_len, -max_bbox_len, 0]
max_bbox_lat = [0, max_bbox_wid, max_bbox_wid, 0, 0]

plt.plot(target_dets_filt.position_y_in_bbox, target_dets_filt.position_x_in_bbox, '+')
plt.plot(min_bbox_lat, min_bbox_lon)
plt.plot(max_bbox_lat, max_bbox_lon)
plt.grid()
plt.axis('equal')
plt.xlabel('position lateral [m]')
plt.ylabel('position longitudinal [m]')
plt.legend(['detection', 'smallest observed bbox', 'largest observed bbox'], loc=4)
plt.title('Radar detections distribution in target bbox')