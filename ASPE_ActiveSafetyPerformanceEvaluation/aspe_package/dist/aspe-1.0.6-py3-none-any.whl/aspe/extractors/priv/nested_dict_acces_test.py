from functools import reduce  # forward compatibility for Python 3
import operator


def getFromDict(dataDict, mapList):
    return reduce(operator.getitem, mapList, dataDict)


a = {
    'b': {
        'c': {
            0: [0, 1],
            1: [1, 2]
        }
    }
}

map = ['b', 'c', 0]

print(getFromDict(a, map))