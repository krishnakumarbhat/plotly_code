import pickle
import numpy as np
from scipy.stats import gaussian_kde
import matplotlib.pyplot as plt
import pandas as pd
p1_cluster_path = r"C:\logs\relevant_logs\rRf360t3060304v202r1_p11_800_250_32\cluster_data.pickle"
p2_cluster_path = r"C:\logs\relevant_logs\rRf360t3060304v202r1_p11_256_128_32\cluster_data.pickle"

clusters_data_full = []
clusters_data_per_scan = []

with open(p1_cluster_path, 'rb') as handle:
    data = pickle.load(handle)
clusters_data_full.append(data['cluster_data_full'])
clusters_data_per_scan.append(['cluster_data_per_scan'])

with open(p2_cluster_path, 'rb') as handle:
    data = pickle.load(handle)
clusters_data_full.append(data['cluster_data_full'])
clusters_data_per_scan.append(['cluster_data_per_scan'])


def plot_pdf(data_list, signal_name, title_suffix, save_path):
    mins = []
    maxs = []
    for idx, sw_data in enumerate(data_list):
        data = sw_data[signal_name]
        mins.append(data.min())
        maxs.append(data.max())
    min = np.array(mins).min()
    max = np.array(maxs).max()

    x = np.linspace(min, max, 100)
    data_raw = {'x': x}
    for idx, sw_data in enumerate(data_list):
        data = sw_data[signal_name]
        kernel = gaussian_kde(data)
        y_pdf = kernel(x)
        data_raw['sw' + str(idx)] = y_pdf
    df = pd.DataFrame(data_raw)
    df.set_index('x', inplace=True)
    ax = df.plot()
    ax.set_title('Kernel density estimation of ' + title_suffix)
    ax.grid()
    ax.set_xlabel(signal_name)
    ax.set_ylabel('density')
    plt.show()
    plt.savefig(save_path)

def plot_cdf(data_list, signal_name, title_suffix, save_path):
    mins = []
    maxs = []
    for idx, sw_data in enumerate(data_list):
        data = sw_data[signal_name]
        mins.append(data.min())
        maxs.append(data.max())
    min = np.array(mins).min()
    max = np.array(maxs).max()

    x = np.linspace(min, max, 100)
    data_raw = {'x': x}
    for idx, sw_data in enumerate(data_list):
        xp = np.sort(sw_data[signal_name])
        yp = np.array(range(len(xp))) / float(len(xp))
        y_cdf = np.interp(x, xp, yp)
        data_raw['sw' + str(idx)] = y_cdf
    df = pd.DataFrame(data_raw)
    df.set_index('x', inplace=True)
    ax = df.plot()
    ax.set_title('CDF of ' + title_suffix)
    ax.grid()
    ax.set_xlabel(signal_name)
    ax.set_ylabel('quantile')
    plt.show()
    plt.savefig(save_path)

plot_pdf(clusters_data_full, 'priority', 'cluster priority', 'cluster_priority_kde.png')
plot_cdf(clusters_data_full, 'priority', 'cluster priority', 'cluster_priority_cdf.png')

plot_pdf(clusters_data_full, 'priority_norm', 'cluster priority normalized', 'cluster_priority_norm_kde.png')
plot_cdf(clusters_data_full, 'priority_norm', 'cluster priority normalized', 'cluster_priority_norm_cdf.png')

plot_pdf(clusters_data_full, 'range', 'cluster range', 'cluster_range_kde.png')
plot_cdf(clusters_data_full, 'range', 'cluster range', 'cluster_range_cdf.png')

plot_pdf(clusters_data_full, 'vcs_position.longitudinal', 'cluster VCS position longitudinal', 'cluster_vcsx_kde.png')
plot_cdf(clusters_data_full, 'vcs_position.longitudinal', 'cluster VCS position longitudinal', 'cluster_vcsx_cdf.png')

plot_pdf(clusters_data_full, 'rep_rdotcomp', 'cluster range rate', 'cluster_range_rate_kde.png')
plot_cdf(clusters_data_full, 'rep_rdotcomp', 'cluster range rate', 'cluster_range_rate_cdf.png')

