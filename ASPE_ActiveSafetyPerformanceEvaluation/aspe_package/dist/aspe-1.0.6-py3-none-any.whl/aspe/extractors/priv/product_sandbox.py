from itertools import product
a = product([1, 2], [10, 20], [100, 200])


