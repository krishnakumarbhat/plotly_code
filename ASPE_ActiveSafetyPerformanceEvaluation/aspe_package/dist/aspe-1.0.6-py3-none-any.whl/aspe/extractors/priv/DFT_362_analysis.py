from aspe.extractors.aspe.extractors.F360.Mudp.example_f360_mudp_extractor import example_from_mudp

mudp_log_path = r"C:\logs\ASPE_example_data\F360_RT_Range\LSS\rRf360t4100309v205p50_2_15\FTP201_TC1_160040_001_rRf360t4100309v205p50_2_15.mudp"
extracted_data = example_from_mudp(mudp_log_path)
