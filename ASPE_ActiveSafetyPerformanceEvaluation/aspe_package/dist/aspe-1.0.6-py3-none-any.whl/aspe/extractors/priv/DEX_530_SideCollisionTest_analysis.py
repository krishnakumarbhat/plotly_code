from aspe.utilities.SupportingFunctions import load_from_pkl
from aspe.extractors.Interfaces.Enums.Object import MovementStatus
import pandas as pd
import numpy as np
import matplotlib
from matplotlib import pyplot as plt
from scipy.io import loadmat
from aspe.utilities.transform_rt_data_mat2data_frame import transform_rt_range_data_mat2data_frame
from aspe.utilities.synchronize_rt_2_tracker import synchronize_rt_2_tracker

PLOT_SAVE_PATH = r'C:\logs\BYK_589_DEX_530\ANALYSIS_362'
RT_DATA_PATH = r"C:\logs\BYK_589_DEX_530\ANALYSIS_362\rt_range_data.mat"

# DEX-530


def get_det_associated_to_objs(dets, objs):
    det_signals = dets.set_index(['scan_index', 'assigned_obj_id'])
    obj_signals = objs.set_index(['scan_index', 'tracker_id'])

    det_signals.index.names = [None, None]
    obj_signals.index.names = [None, None]

    merged = obj_signals.join(det_signals, how='inner', lsuffix='_obj', rsuffix='_det')
    return merged


def plot_rt_traces(rt_data):
    host_x = rt_data.Range1HunterPosLocal__Range1HunterPosLocalX
    host_y = rt_data.Range1HunterPosLocal__Range1HunterPosLocalY
    target_x = rt_data.Range1TargetPosLocal__Range1TargetPosLocalX
    target_y = rt_data.Range1TargetPosLocal__Range1TargetPosLocalY

    f, axes = plt.subplots(ncols=2, figsize=(11, 6))
    axes[0].plot(host_y, host_x, label='host')
    axes[0].plot(target_y, target_x, label='target')

    axes[1].plot(host_y, host_x, label='host')
    axes[1].plot(target_y, target_x, label='target')

    axes[1].set_xlim((-790, -740))
    axes[1].set_ylim((-2400, -2225))

    axes[0].grid()
    axes[1].grid()
    axes[0].set_xlabel('position y [m]')
    axes[1].set_xlabel('position y [m]')
    axes[0].set_ylabel('position x [m]')

    axes[0].set_title('Host/Target traces')
    axes[1].set_title('Host/Target traces zoomed')

    f.tight_layout()
    f.savefig(f'{PLOT_SAVE_PATH}\\rt_traces.png')
    plt.close(f)


def plot_signal_compare(df_list, label_list, plot_title, signal_to_compare, unit, x_label):
    fig, axes = plt.subplots(figsize=(12, 6))
    for df, label in zip(df_list, label_list):
        x = df.index.to_numpy()
        y = df.loc[:, signal_to_compare]
        axes.plot(x, y, label=label)
    axes.set_title(plot_title)
    axes.set_xlabel(x_label)
    axes.set_ylabel(f'{signal_to_compare} {unit}')
    axes.legend()
    axes.grid()
    file_title = plot_title.lower().replace(' ', '_')
    fig.savefig(f'{PLOT_SAVE_PATH}\\{file_title}')
    plt.close(fig)


def filter_dets_by_roi(dets_df, x_min, x_max, y_min, y_max):
    dets_out = dets_df.loc[(x_min < dets_df.position_x) & (dets_df.position_x < x_max), :]
    dets_out = dets_out.loc[(y_min < dets_out.position_y) & (dets_out.position_y < y_max), :]
    return dets_out


def put_nans_in_scan_index_jumps(dataframe, time_jump = 0.5):
    ts = np.sort(np.unique(dataframe.index.to_numpy()))
    scan_index_jumps = ts[np.where(np.diff(ts) > time_jump)[0]]
    for jump_ts in scan_index_jumps:
        dataframe.loc[jump_ts + 0.05, :] = np.nan
    dataframe.sort_index(inplace=True)


def load_and_concat_data(pickle_paths_list, ids):
    targets = []
    dets = []
    dets_all = []
    for id, pickle_path in zip(ids, pickle_paths_list):
        extracted = load_from_pkl(pickle_path)
        obj_signals = extracted.objects.signals.join(extracted.objects.raw_signals, rsuffix='_raw')
        obj_signals = obj_signals.loc[obj_signals.tracker_id == id, :]
        det_signals = extracted.detections.signals.join(extracted.detections.raw_signals, rsuffix='_raw')
        dets_all.append(det_signals)
        det_signals = det_signals.loc[det_signals.assigned_obj_id == id, :]
        dets.append(det_signals)
        targets.append(obj_signals)

    out_targets = pd.concat(targets)
    out_targets.set_index('timestamp', inplace=True, drop=False)
    out_targets.sort_index(inplace=True)
    out_targets['bounding_box_orientation_deg'] = np.rad2deg(out_targets['bounding_box_orientation'])
    out_detections = pd.concat(dets)
    out_detections.set_index('timestamp', inplace=True, drop=False)
    out_detections.sort_index(inplace=True)
    dets_all = pd.concat(dets_all).set_index('timestamp', drop=False)
    dets_all.sort_index(inplace=True)
    sensors = extracted.sensors.per_sensor
    return out_targets, out_detections, sensors, dets_all


def get_selected_by_trk_count(dets_df):
    grouped_dets = dets_df.groupby(by='scan_index')
    output = grouped_dets['f_selected_by_trk'].sum()
    timestamps = grouped_dets['timestamp'].min()
    output.index = timestamps
    return output


def plot_velocity_and_selected_dets_count(objects_df_list, sel_by_trk_list, labels):
    f, axes = plt.subplots(nrows=3, sharex=True)
    for obj, dets in zip(objects_df_list, sel_by_trk_list):
        obj.velocity_otg_x.plot(ax=axes[0])
        obj.velocity_otg_variance_x.plot(ax=axes[1])
        dets.plot(ax=axes[2])

    titles =['Longitudinal abs. velocity', 'Longitudinal abs. velocity variance', 'Number of detections used in measurement update']
    for ax, title in zip(axes, titles):
        ax.grid()
        ax.legend(labels)
        ax.set_title(title)


logs_pickle_paths_2_14 =[
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T114758_20200131T114818_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T114818_20200131T114838_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T114838_20200131T114858_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T114858_20200131T114918_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T114918_20200131T114938_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T114938_20200131T114958_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T114958_20200131T115018_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T115018_20200131T115036_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
]
logs_pickle_paths_2_20 = [
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T114758_20200131T114818_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T114818_20200131T114838_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T114838_20200131T114858_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T114858_20200131T114918_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T114918_20200131T114938_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T114938_20200131T114958_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T114958_20200131T115018_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T115018_20200131T115036_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle"
]

logs_pickle_paths_host_clutter_fix = [
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_2_20_host_clutter_fix\20200131T114758_20200131T114818_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_2_20_host_clutter_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_2_20_host_clutter_fix\20200131T114818_20200131T114838_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_2_20_host_clutter_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_2_20_host_clutter_fix\20200131T114838_20200131T114858_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_2_20_host_clutter_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_2_20_host_clutter_fix\20200131T114858_20200131T114918_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_2_20_host_clutter_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_2_20_host_clutter_fix\20200131T114918_20200131T114938_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_2_20_host_clutter_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_2_20_host_clutter_fix\20200131T114938_20200131T114958_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_2_20_host_clutter_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_2_20_host_clutter_fix\20200131T114958_20200131T115018_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_2_20_host_clutter_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK_589_DEX_530\SRR_DEBUG\rRf360t4150309v205p50_2_20_host_clutter_fix\20200131T115018_20200131T115036_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_2_20_host_clutter_fix_f360_mudp_extracted.pickle"
]

obj_id_2_14 = [46, 109, 109, 46, 46, 46, 46, 46]
obj_id_2_20 = [12, 109, 109, 46, 46, 46, 46, 46]
obj_id_host_clutter_fix = [12] * 8

out_targets_2_14, detections_2_14, sensors_2_14, _ = load_and_concat_data(logs_pickle_paths_2_14, obj_id_2_14)
out_targets_2_20, detections_2_20, sensors_2_20, _ = load_and_concat_data(logs_pickle_paths_2_20, obj_id_2_20)
out_targets_hcf, dets_hcf, sensors_hcf, dets_all = load_and_concat_data(logs_pickle_paths_host_clutter_fix, obj_id_host_clutter_fix)

put_nans_in_scan_index_jumps(out_targets_2_14, time_jump=0.1)
put_nans_in_scan_index_jumps(out_targets_2_20, time_jump=0.1)
put_nans_in_scan_index_jumps(out_targets_hcf, time_jump=0.1)

rt_data = transform_rt_range_data_mat2data_frame(RT_DATA_PATH, rt_ref_x=0.0, rt_ref_y=0.5, ref_length=4.9, ref_width=1.9, include_host_yawing=False)
rt_data.set_index('time', inplace=True)
rt_data['bounding_box_orientation_deg'] = np.rad2deg(rt_data['bounding_box_orientation'])

out_targets_2_14 = out_targets_2_14.loc[out_targets_2_14.index > 12660, :]
out_targets_2_20 = out_targets_2_20.loc[out_targets_2_20.index > 12660, :]
out_targets_hcf = out_targets_hcf.loc[out_targets_hcf.index > 12660, :]

detections_2_20 = detections_2_20.loc[detections_2_20.index > 12660, :]
rt_data = rt_data.loc[rt_data.index > 12660, :]

plots_info = [
    # plot name                                 signal_to_compare               # unit
    ('Reference point longitudinal position',   'position_x',                   '[m]'),
    ('Reference point lateral position',        'position_y',                   '[m]'),
    ('Bounding box center longitudinal position', 'center_x',                   '[m]'),
    ('Bounding box center lateral position',     'center_y',                    '[m]'),
    ('Absolute velocity longitudinal',          'velocity_otg_x',               '[m/s]'),
    ('Absolute velocity lateral',               'velocity_otg_y',               '[m/s]'),
    ('Speed',                                   'speed',                        '[m/s]'),
    ('Bounding box longitudinal dimension',     'bounding_box_dimensions_x',    '[m]'),
    ('Bounding box lateral dimension',          'bounding_box_dimensions_y',    '[m]'),
    ('Bounding box orientation',                'bounding_box_orientation_deg', '[deg]')
]

#for plot_info in plots_info:
#    plot_title, signal_to_compare, unit = plot_info
#    plot_signal_compare([out_targets_2_14, out_targets_2_20, rt_data, out_targets_hcf], ['tracker core 2.14', 'tracker core 2.20', 'rt range', 'host clutter fix'],
#                        plot_title, signal_to_compare, unit, 'time [s]')

for plot_info in plots_info:
    plot_title, signal_to_compare, unit = plot_info
    plot_signal_compare([out_targets_hcf, out_targets_2_20, rt_data], ['host clutter fix', 'tracker core 2.20', 'rt range', ],
                        plot_title, signal_to_compare, unit, 'time [s]')

#plot_rt_traces(rt_data)

rt_synch = synchronize_rt_2_tracker(rt_data, out_targets_2_20)

# filter_relevant_dets
x_min, x_max = -6, 2
y_min, y_max = -4.5, -1.5

dets_w_sensors = detections_2_20.join(sensors_2_20.set_index('sensor_id'), on='sensor_id', rsuffix='_sensor')
detections_2_20['azimuth_vcs'] = dets_w_sensors.azimuth.to_numpy() + dets_w_sensors.boresight_az_angle.to_numpy()
detections_2_20 = detections_2_20.join(rt_synch.set_index('scan_index'), on='scan_index', rsuffix='_rt')
detections_2_20['predicted_range_rate'] = detections_2_20.target_vel_rel_x * np.cos(detections_2_20.azimuth_vcs) + detections_2_20.target_vel_rel_y * np.sin(detections_2_20.azimuth_vcs)
detections_2_20['range_rate_prediction_err'] = detections_2_20.predicted_range_rate - detections_2_20.range_rate

sel_by_trk_count_2_14 = get_selected_by_trk_count(detections_2_14)
sel_by_trk_count_2_20 = get_selected_by_trk_count(detections_2_20)
sel_by_trk_count_hcf = get_selected_by_trk_count(dets_hcf)

ts_min, ts_max = 12763, 12765.4

plot_velocity_and_selected_dets_count([out_targets_2_20, out_targets_hcf], [sel_by_trk_count_2_20, sel_by_trk_count_hcf], ['2_20', 'host clutter fix'])

objs_w_dets = get_det_associated_to_objs(dets_hcf, out_targets_hcf)
target_dets = objs_w_dets.loc[:, ['f_selected_by_trk']].groupby(level=0).sum()
target_obj_pos = objs_w_dets.loc[:, ['position_x_obj', 'position_y_obj']].groupby(level=0).min()
joined = target_obj_pos.join(target_dets)