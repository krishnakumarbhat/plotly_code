import glob
import subprocess

RESIM_PATH = r"C:\wkspaces_git\F360Core\sw\output\Debug_Win32\resim_f360.exe"
SUFFIX = '_ford_demo_da67ee'

if __name__ == '__main__':
    logs_list = glob.glob(r'C:\logs\BYK_542_events_trucks_lateraly_close\SRR_DEBUG\*.dvl')
    logs_list = [
        r"C:\logs\BYK_542_events_trucks_lateraly_close\SRR_DEBUG\20200506T141752_20200506T141812_543078_LB36408_SRR_DEBUG.dvl",
        r"C:\logs\BYK_542_events_trucks_lateraly_close\SRR_DEBUG\20200506T135932_20200506T135952_543078_LB36408_SRR_DEBUG.dvl",
        r"C:\logs\BYK_542_events_trucks_lateraly_close\SRR_DEBUG\20200506T135952_20200506T140012_543078_LB36408_SRR_DEBUG.dvl",
    ]
    logs_list = [
        r"C:\logs\BYK_542_events_trucks_lateraly_close\SRR_DEBUG\20201012T144701_20201012T144721_543078_LB36408_SRR_DEBUG.dvl"
    ]
    for log_path in logs_list:
        command = f'{RESIM_PATH} {log_path} -osuffix {SUFFIX} -f360trkopt -init_from_log -sync_input -endopt'
        subprocess.call(command)

    log_list = r"C:\logs\BYK_542_events_trucks_lateraly_close\SRR_DEBUG\cont_resim_2.txt"
    command = f'{RESIM_PATH} {log_list} -filelist -osuffix {SUFFIX} -stream BMW -f360trkopt -init_from_log -sync_input -endopt'
    subprocess.call(command)