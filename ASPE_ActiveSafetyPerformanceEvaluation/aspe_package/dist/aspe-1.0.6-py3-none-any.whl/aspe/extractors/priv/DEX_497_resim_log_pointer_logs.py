import subprocess
import glob

if __name__ == '__main__':
    resim_exe_path = r"C:\wkspaces_git\F360Core\F360TrackerPC_SRR_ESR_vs2015\output\Debug_Win32\resim_f360.exe"
    bad_events_list = glob.glob(r'C:\logs\DEX_497\logs_from_MST_log_pointer\ticket_events\*.dvl')
    #fine_event_list = glob.glob(r'C:\logs\DEX_497\logs_from_log_pointer\stop_and_go_good_events\*.dvl')

    suffix = '_DEX_497_assoc_dets_nearby_logic'
    for log_path in bad_events_list:
        command = f'{resim_exe_path} {log_path} -osuffix {suffix} -f360trkopt -xtrklog -init_from_log -sync_input -endopt'
        subprocess.call(command)