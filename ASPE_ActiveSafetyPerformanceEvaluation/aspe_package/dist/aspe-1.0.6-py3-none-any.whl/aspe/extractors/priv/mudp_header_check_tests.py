stream_chunks = 3
stream_ref_index = [1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 5, 6, 6, 6]
stream_ref_index_unique = []
ref_idxs_to_save = []
beg_idx = 0
end_idx = beg_idx + stream_chunks

while end_idx <= len(stream_ref_index):
    chunk = stream_ref_index[beg_idx: end_idx]
    unique_ref_indexes_in_chunk = sorted(list(set(chunk)))
    if len(unique_ref_indexes_in_chunk) == 1 and len(chunk) == stream_chunks:
        stream_ref_index_unique.append(chunk[0])
        ref_idxs_to_save.extend(range(beg_idx, end_idx))
        beg_idx = end_idx
    else:
        """
        Case when chunk is [100, 100, 101] for stream chunk == 3. Stream ref index 100 is corrupted, so beg_index should
        be set on 101.
        """
        last_ref_idx_in_chunk = unique_ref_indexes_in_chunk[-1]
        last_ref_idx_position = chunk.index(last_ref_idx_in_chunk)
        beg_idx = beg_idx + last_ref_idx_position
    end_idx = beg_idx + stream_chunks