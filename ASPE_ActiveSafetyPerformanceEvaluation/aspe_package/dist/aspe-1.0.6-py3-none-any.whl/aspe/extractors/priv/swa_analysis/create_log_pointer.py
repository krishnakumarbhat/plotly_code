from aspe.extractors.API.mudp import extract_f360_from_mudp, extract_f360_from_mudp_folder, parse_mudp
from aspe.utilities.SupportingFunctions import recursive_dict_extraction
from pathlib import Path
import numpy as np
import pandas as pd
from tqdm import tqdm
from datetime import datetime


def check_if_large_rel_vel_obj_are_in_log(obj_signals, rel_vel_thr):
    return np.any(obj_signals.velocity_rel_x > rel_vel_thr)


def get_relevant_objs_unique_id(obj_signals, rel_vel_thr):
    high_rel_speed_mask = obj_signals.velocity_rel_x > rel_vel_thr
    in_rear_of_host_mask = obj_signals.position_x < 0
    heading_mask = np.abs(obj_signals.bounding_box_orientation) < np.deg2rad(30)
    lateral_mask = (-10 < obj_signals.position_y) & (obj_signals.position_y < -2)
    lateral_vel_mask = np.abs(obj_signals.velocity_otg_y) < 2
    summary_mask = high_rel_speed_mask & in_rear_of_host_mask & heading_mask & lateral_mask & lateral_vel_mask
    if np.any(summary_mask):
        return np.unique(obj_signals.loc[summary_mask, 'unique_id'])
    else:
        return []


def get_guardrail_info(log_path):
    parsed_stream_8 = parse_mudp(log_path, streams_to_parse=[8], unknown_size_per_stream={8: 4})['parsed_data'][8]
    in_dict, _ = recursive_dict_extraction(parsed_stream_8)
    out_dict = {}
    for k, v in in_dict.items():
        if "guard_rails" in k and len(v.shape) == 2:
            out_dict[k + '_left'] = v[:, 0]
            out_dict[k + '_right'] = v[:, 1]
        elif len(v.shape) == 1:
            out_dict[k] = v
    gr_df = pd.DataFrame(out_dict).rename(columns={'tracker_index': 'scan_index'})
    return gr_df


def trim_target_data(rel_obj_signals):
    pos_x_filter = rel_obj_signals.position_x < 0
    return rel_obj_signals.loc[pos_x_filter, :]


def get_object_assoc_dets(rel_obj_signals, all_dets):
    scan_index_start, scan_index_end = rel_obj_signals.scan_index.min(), rel_obj_signals.scan_index.max()
    all_dets_trimmed = all_dets.loc[(scan_index_start < all_dets.scan_index) & (all_dets.scan_index < scan_index_end), :]
    obj_id = rel_obj_signals.id.iloc[0]
    assigned_dets = all_dets_trimmed.loc[all_dets_trimmed.assigned_obj_id == obj_id, :]
    return assigned_dets


def get_lateral_position_from_dets(rel_obj_dets):
    scan_index_sorted = rel_obj_dets.sort_values(by='scan_index')
    return np.median(scan_index_sorted.tail(20).position_y)


def trim_gruardrail(rel_obj_signals, guardrail):
    scan_index_start, scan_index_end = rel_obj_signals.scan_index.min(), rel_obj_signals.scan_index.max()
    scan_index_mask = (scan_index_start <= guardrail.scan_index) & (guardrail.scan_index <= scan_index_end)
    return guardrail.loc[scan_index_mask, :]


def get_obj_class_type(rel_obj_signals):
    scan_index_sorted = rel_obj_signals.sort_values(by='scan_index')
    obj_class = scan_index_sorted.tail(20).object_class.to_numpy()
    obj_class_value_to_name = {c.value: c.name for c in obj_class}
    obj_values = [c.value for c in obj_class]
    most_freq_class_value = np.bincount(obj_values).argmax()
    return obj_class_value_to_name[most_freq_class_value]


def get_log_pointer_row(log_path, rel_obj_signals, rel_obj_dets, guardrail):
    guardrail_trimmed = trim_gruardrail(rel_obj_signals, guardrail)
    row = {
        'log_local_path': str(log_path),
        'log_name': log_path.name,
        'Event type': 0,
        'Tracker Idx start': rel_obj_signals.scan_index.min(),
        'Tracker Idx end': rel_obj_signals.scan_index.max(),
        'Object ID': rel_obj_signals.id.iloc[0],
        'Object class': get_obj_class_type(rel_obj_signals),
        'Relative velocity': np.median(rel_obj_signals.velocity_rel_x),
        'Expected lateral position': get_lateral_position_from_dets(rel_obj_dets),
        'Guardrail position left': np.median(guardrail_trimmed.guard_rails_lateral_position_left),
        'Guardrail position right': np.median(guardrail_trimmed.guard_rails_lateral_position_right),
        'Medial lateral distance': np.median(rel_obj_signals.position_y),
        'Probability motorcycle': np.mean(rel_obj_signals.tail(30).probability_motorcycle),
        'Length': np.mean(rel_obj_signals.tail(30).bounding_box_dimensions_x),
        'Width': np.mean(rel_obj_signals.tail(30).bounding_box_dimensions_y),
    }
    return row


def join_main_and_raw_signals(objects_ds):
    return objects_ds.signals.join(objects_ds.raw_signals, rsuffix='_raw')


def update_dict_of_lists(dict_to_be_updated, other_dict):
    for k, v in other_dict.items():
        try:
            dict_to_be_updated[k].append(v)
        except KeyError:
            dict_to_be_updated[k] = [v]


def filter_reduced_objects(objects_signals):
    reduced_mask = objects_signals.reduced_id != 0
    return objects_signals.loc[reduced_mask, :]


if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,
    mudp_log_file_path = r"C:\logs\SWA_tests_drives\event_1\20210421T115910_20210421T115930_541610_H019173_SRR_DEBUG.mudp"

    logs_dir = Path(r"C:\logs\SWA_tests_drives\rRf360t4310309v205p50_2_36_0")
    log_list = logs_dir.glob("*.mudp")

    log_pointer_dict = {}
    for log_path in tqdm(log_list):
        guardrail = get_guardrail_info(str(log_path))
        extracted = extract_f360_from_mudp(str(log_path), mudp_stream_def_path=mudp_stream_def_path,
                                           internal_objects=True,
                                           detections=True,
                                           raw_signals=True,
                                           save_to_file=True)
        dets = extracted.detections.signals

        if extracted.internal_objects is not None:
            objs = join_main_and_raw_signals(extracted.internal_objects)
            objs = filter_reduced_objects(objs)
            unique_ids = get_relevant_objs_unique_id(objs, 10.0)
            objs_grouped = objs.groupby(by='unique_id')
            for unique_id in unique_ids:
                rel_obj_signals = objs_grouped.get_group(unique_id)
                rel_obj_signals = trim_target_data(rel_obj_signals)
                rel_obj_dets = get_object_assoc_dets(rel_obj_signals, dets)
                log_pointer_row = get_log_pointer_row(log_path, rel_obj_signals, rel_obj_dets, guardrail)
                update_dict_of_lists(log_pointer_dict, log_pointer_row)

    log_pointer = pd.DataFrame(log_pointer_dict)
    date_time_now = datetime.now().strftime("%d%m%Y%H%M")
    log_pointer.to_excel(logs_dir / f'log_pointer_{date_time_now}.xls')