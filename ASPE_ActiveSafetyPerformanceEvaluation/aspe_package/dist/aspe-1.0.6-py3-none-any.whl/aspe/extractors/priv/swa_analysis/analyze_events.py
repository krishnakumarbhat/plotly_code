from aspe.utilities.SupportingFunctions import load_from_pkl
from aspe.utilities.MathFunctions import calc_position_in_bounding_box
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


def calculate_error(events):
    fr_coner_x, fr_corner_y = calc_position_in_bounding_box(events.center_x, events.center_y,
                                                            events.bounding_box_dimensions_x, events.bounding_box_dimensions_y,
                                                            events.bounding_box_orientation,
                                                            0.5, 0.5,
                                                            1.0, 1.0)
    events['lateral_error'] = events.expected_lateral_position - fr_corner_y
    events['abs_lateral_error'] = events['lateral_error'].abs()


def set_distance_ranges(events):
    def set_distance_range(events, min_range, max_range):
        range_filter = (min_range < events.position_x) & (events.position_x < max_range)
        events.loc[range_filter, 'distance_range'] = f'{abs(min_range)}-{abs(max_range)}[m]'

    set_distance_range(events, -90, -80)
    set_distance_range(events, -80, -70)
    set_distance_range(events, -70, -60)
    set_distance_range(events, -60, -50)
    set_distance_range(events, -50, -40)
    set_distance_range(events, -40, -20)
    nan_distance_range = events.distance_range.isna()
    return events.loc[~nan_distance_range, :]


def plot_boxplots_distributions(events):
    fig = plt.figure(figsize=(12, 9), constrained_layout=True)
    gs = fig.add_gridspec(3, 1)
    ax_1 = fig.add_subplot(gs[:2, :])
    sns.boxplot(ax=ax_1, data=events, x='distance_range', y='lateral_error', hue='event_type')
    ax_1.grid()

    ax_2 = fig.add_subplot(gs[2, :])
    n_samples = events.groupby(by=['distance_range', 'event_type']).count().reset_index().rename(columns={'scan_index': 'n_samples'})
    sns.barplot(ax=ax_2, data=n_samples, x='distance_range', y='n_samples', hue='event_type',  order=np.flip(n_samples.distance_range.unique()))
    ax_2.grid()
    return fig


def plot_error_quantile_bars(events, q):
    q_column_name = f"Q{int(q*100)} abs. lateral error [m]"
    grouped = events.loc[:, ['distance_range', 'event_type', 'abs_lateral_error']].groupby(by=['distance_range', 'event_type'])
    quantile_info = grouped.quantile(0.95).reset_index().rename(columns={'abs_lateral_error': q_column_name})
    fig, axes = plt.subplots(figsize=(12, 9))
    sns.barplot(ax=axes, data=quantile_info, x='distance_range', y=q_column_name, hue='event_type', order=np.flip(quantile_info.distance_range.unique()))
    axes.grid()
    return fig


def plot_line_plots_quantils(events, quantils=(0.5, 0.9, 0.95)):
    fig, axes = plt.subplots(figsize=(12, 9))
    grouped = events.loc[:, ['distance_range', 'event_type', 'abs_lateral_error']].groupby(by=['distance_range', 'event_type'])
    for (distance_range, event_type), group in grouped:
        pass


if __name__ == '__main__':
    events_data_path = 'C:\\logs\\SWA_tests_drives\\rRf360t4310309v205p50_2_36_0\\events_290420211248.pickle'
    events = load_from_pkl(events_data_path)

    calculate_error(events)
    events = set_distance_ranges(events)

    #plot_line_plots_quantils(events)
    plot_boxplots_distributions(events)
    plot_error_quantile_bars(events, q=0.95)

    sorted_samples = events.sort_values(by=['event_type', 'abs_lateral_error'])
    events_sorted_by_mean_error = events.groupby('event_id').mean().sort_values(by='lateral_error', ascending=False)

    f, axes = plt.subplots()
    for ev_type, ev in events.groupby(by='event_type'):
        gr_present = ev.guard_rails_f_present_left
        gr_present_count = np.sum(gr_present)
        total_samples = len(ev)
        ratio = gr_present_count / total_samples
        print(f"Event {ev_type} - guardrail present: {gr_present_count} scans, total scans: {total_samples}, ratio: {ratio}")
        axes.bar(ev_type, ratio)
