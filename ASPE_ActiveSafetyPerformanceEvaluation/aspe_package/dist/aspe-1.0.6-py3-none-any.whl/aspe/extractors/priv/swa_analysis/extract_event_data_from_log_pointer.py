from aspe.extractors.API.mudp import extract_f360_from_mudp, extract_f360_from_mudp_folder, parse_mudp
from aspe.utilities.SupportingFunctions import recursive_dict_extraction
from pathlib import Path
import numpy as np
import pandas as pd
from tqdm import tqdm
from datetime import datetime
from aspe.extractors.priv.swa_analysis.create_log_pointer import join_main_and_raw_signals, trim_target_data, get_guardrail_info, trim_gruardrail, filter_reduced_objects
from aspe.extractors.Interfaces.Enums.Object import MovementStatus
from tqdm import tqdm
from aspe.utilities.SupportingFunctions import save_to_pkl


def filter_obj_relevant_columns(rel_obj):
    columns_to_filter = ['scan_index', 'timestamp', 'unique_id', 'id', 'reduced_id', 'status',
                         'position_x', 'position_y', 'center_x', 'center_y', 'vcs_heading',
                         'position_variance_x', 'position_variance_y', 'position_covariance',
                         'velocity_otg_x', 'velocity_otg_y', 'velocity_rel_x', 'velocity_rel_y', 'speed', 'yaw_rate',
                         'bounding_box_dimensions_x', 'bounding_box_dimensions_y', 'bounding_box_orientation',
                         'bounding_box_refpoint_long_offset_ratio', 'bounding_box_refpoint_lat_offset_ratio',
                         'movement_status', 'object_class', 'object_class_probability', 'probability_motorcycle',
                         'guard_rails_f_present_left', 'guard_rails_f_present_right',
                         'guard_rails_lateral_position_left', 'guard_rails_lateral_position_right',
                         'existence_indicator'
                         ]
    return rel_obj.loc[:, columns_to_filter]


def get_obj_by_id(objects, rel_obj_id):
    moving_filter = objects.movement_status == MovementStatus.MOVING
    rel_speed_filter = 10 < objects.velocity_rel_x
    moving_objs = objects.loc[moving_filter & rel_speed_filter, :]
    rel_objs = moving_objs.loc[moving_objs.id == rel_obj_id, :]
    if len(np.unique(rel_objs.unique_id)) > 1:
        raise AttributeError
    return rel_objs


def get_event_data(log_pointer_row, logs_dir, event_index):
    log_name = log_pointer_row['log_name']
    rel_object_id = log_pointer_row['Object ID']

    log_path = Path(logs_dir) / log_name
    guardrail = get_guardrail_info(str(log_path))
    extracted = extract_f360_from_mudp(str(log_path), raw_signals=True, internal_objects=True, detections=True)

    objects = join_main_and_raw_signals(extracted.internal_objects)
    objects = filter_reduced_objects(objects)
    objects = trim_target_data(objects)

    rel_obj = get_obj_by_id(objects, rel_object_id)
    guardrail = trim_gruardrail(rel_obj, guardrail)

    rel_obj = rel_obj.join(guardrail.set_index('scan_index'), on='scan_index')
    rel_obj = filter_obj_relevant_columns(rel_obj)

    rel_obj['expected_lateral_position'] = log_pointer_row['Expected lateral position']
    rel_obj['event_id'] = event_index
    rel_obj['event_type'] = log_pointer_row['Event type']
    return rel_obj


if __name__ == '__main__':
    log_pointer_path = r"C:\logs\SWA_tests_drives\rRf360t4310309v205p50_2_36_0\log_pointer_260420211532.xlsx"
    logs_dir = r"C:\logs\SWA_tests_drives\rRf360t4310309v205p50_2_36_0"
    log_pointer = pd.read_excel(log_pointer_path, index_col=0, engine='openpyxl')

    events = []
    for event_index, event_info in tqdm(log_pointer.iterrows()):
        if event_info['valid'] == 'yes':
            event_data = get_event_data(event_info, logs_dir, event_index)
            events.append(event_data)
    events = pd.concat(events).reset_index(drop=True)

    date_time_now = datetime.now().strftime("%d%m%Y%H%M")
    events_save_path = str(Path(logs_dir) / f'events_{date_time_now}.pickle')
    save_to_pkl(events, events_save_path)