from aspe.utilities.SupportingFunctions import load_from_pkl
from aspe.utilities.MathFunctions import calc_position_in_bounding_box
from aspe.extractors.priv.swa_analysis.config import get_SWA_zone
from aspe.extractors.priv.swa_analysis.flags import IsInLCDAZones
from shapely.geometry import Polygon
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


def get_SWA_old_zone(SWA_zone_pos_x = [-5.0, -40.0, -90.0, -90.0, -40.0, -5.0], zones_size_offset=0.0, SWA_zone_fac_y=None):
    if SWA_zone_fac_y is None:
        SWA_zone_fac_y = [1.6, 1.6, 2.0, 0.1, 0.5, 0.5]
    lateral_zone_dist = 3.5
    SWA_zone_pos_y = [elem * lateral_zone_dist for elem in SWA_zone_fac_y]
    SWA_zone_fac_y_hist = []
    SWA_zone_fac_y_hist += [elem * lateral_zone_dist for elem in [0.1, 0.3, 0.4]]
    SWA_zone_fac_y_hist += [-elem * lateral_zone_dist for elem in [0.4, 0.3, 0.1]]
    SWA_zone_pos_y_hist = [elem1 + elem2 for elem1, elem2 in zip(SWA_zone_pos_y, SWA_zone_fac_y_hist)]

    # mlp
    for x in range(len(SWA_zone_pos_y)):
        if x < len(SWA_zone_pos_y) / 2:
            SWA_zone_pos_y[x] = SWA_zone_pos_y[x] - zones_size_offset
            SWA_zone_pos_y_hist[x] = SWA_zone_pos_y_hist[x] - zones_size_offset
        else:
            SWA_zone_pos_y[x] = SWA_zone_pos_y[x] + zones_size_offset
            SWA_zone_pos_y_hist[x] = SWA_zone_pos_y_hist[x] + zones_size_offset

    SWA_right_zone = Polygon([(pos_x, pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y)])
    SWA_right_hist_zone = Polygon([(pos_x, pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y_hist)])
    SWA_left_zone = Polygon([(pos_x, -pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y)])
    SWA_left_hist_zone = Polygon([(pos_x, -pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y_hist)])
    return SWA_left_zone, SWA_right_zone, SWA_left_hist_zone, SWA_right_hist_zone, SWA_zone_fac_y_hist


def get_SWA_zone(SWA_zone_pos_x, zones_size_offset=0.0, SWA_zone_fac_y=None):
    if SWA_zone_fac_y is None:
        SWA_zone_fac_y = [1.3, 1.6, 1.2, 0.5, 0.1, 0.5]
    lateral_zone_dist = 3.5
    SWA_zone_pos_y = [elem * lateral_zone_dist for elem in SWA_zone_fac_y]
    SWA_zone_fac_y_hist = []
    SWA_zone_fac_y_hist += [elem * lateral_zone_dist for elem in [0.1, 0.3, 0.4]]
    SWA_zone_fac_y_hist += [-elem * lateral_zone_dist for elem in [0.4, 0.3, 0.1]]
    SWA_zone_pos_y_hist = [elem1 + elem2 for elem1, elem2 in zip(SWA_zone_pos_y, SWA_zone_fac_y_hist)]

    # mlp
    for x in range(len(SWA_zone_pos_y)):
        if x < len(SWA_zone_pos_y) / 2:
            SWA_zone_pos_y[x] = SWA_zone_pos_y[x] - zones_size_offset
            SWA_zone_pos_y_hist[x] = SWA_zone_pos_y_hist[x] - zones_size_offset
        else:
            SWA_zone_pos_y[x] = SWA_zone_pos_y[x] + zones_size_offset
            SWA_zone_pos_y_hist[x] = SWA_zone_pos_y_hist[x] + zones_size_offset

    SWA_right_zone = Polygon([(pos_x, pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y)])
    SWA_right_hist_zone = Polygon([(pos_x, pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y_hist)])
    SWA_left_zone = Polygon([(pos_x, -pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y)])
    SWA_left_hist_zone = Polygon([(pos_x, -pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y_hist)])
    return SWA_left_zone, SWA_right_zone, SWA_left_hist_zone, SWA_right_hist_zone, SWA_zone_fac_y_hist


def plot_in_swa_zone_by_event_type(events):
    fig, axes = plt.subplots(nrows=3)
    for event_id, event_type in events.groupby(by='event_type'):
        axes[event_id-1].plot(event_type.loc[:, 'position_x'], event_type.loc[:, 'in_swa_zone'], '.')


def filter_by_x_pos(events, x_min, x_max):
    return events.loc[(x_min < events.position_x) & (events.position_x < x_max),:]


def recalculate_positions(events, new_pos_x, new_pos_y):
    pos_x, pos_y = calc_position_in_bounding_box(events.center_x, events.center_y,
                                                            events.bounding_box_dimensions_x, events.bounding_box_dimensions_y,
                                                            events.bounding_box_orientation, 0.5, 0.5,
                                                            new_pos_x, new_pos_y)
    events['position_x'] = pos_x
    events['position_y'] = pos_y


if __name__ == '__main__':
    #zone 1
    SWA_zone_pos_x = [-5.0, -65.0, -80.0, -80.0, -65.0, -5.0]
    SWA_zone_fac_y = [1.3, 1.6, 1.2, 0.5, 0.1, 0.5]

    ## zone 2
    SWA_zone_pos_x = [-5.0, -65.0, -80.0, -80.0, -65.0, -5.0]
    SWA_zone_fac_y = [1.5, 1.6, 1.2, 0.5, 0.4, 0.3]

    SWA_left_zone, SWA_right_zone, SWA_left_hist_zone, SWA_right_hist_zone, SWA_zone_fac_y_hist = get_SWA_zone(SWA_zone_pos_x, SWA_zone_fac_y=SWA_zone_fac_y)
    #SWA_left_zone, SWA_right_zone, SWA_left_hist_zone, SWA_right_hist_zone, SWA_zone_fac_y_hist = get_SWA_old_zone()

    zone_x, zone_y = SWA_left_zone.exterior.xy
    zone_hist_x, zone_hist_y = SWA_left_hist_zone.exterior.xy

    min_zone_x, max_zone_x = np.min(zone_x), np.max(zone_x)
    lca_early_warning_zone = IsInLCDAZones(SWA_left_zone, SWA_left_hist_zone, SWA_right_zone, SWA_right_hist_zone, flag_signature='in_swa_zone')

    events_data_path = r"C:\logs\SWA_tests_drives\rRf360t4310309v205p50_2_36_0\events_300420211324.pickle"
    events = load_from_pkl(events_data_path)

    recalculate_positions(events, 1.0, 0.5)
    events = filter_by_x_pos(events, min_zone_x, max_zone_x)

    for event_index, single_event in events.groupby(by='event_id'):
        events.loc[single_event.index, 'in_swa_zone'] = lca_early_warning_zone.calc_flag(single_event)

    in_swa_zones = events.loc[:, ['event_type', 'in_swa_zone']].groupby(by=['event_type']).sum()
    total_samples = events.loc[:, ['event_type', 'in_swa_zone']].groupby(by=['event_type']).count()

    event_type_1_tpr = in_swa_zones.loc[1, 'in_swa_zone'] / total_samples.loc[1, 'in_swa_zone']
    event_type_2_tpr = in_swa_zones.loc[2, 'in_swa_zone'] / total_samples.loc[2, 'in_swa_zone']
    event_type_3_fpr = in_swa_zones.loc[3, 'in_swa_zone'] / total_samples.loc[3, 'in_swa_zone']

    print('Event 1 TPR: ', event_type_1_tpr)
    print('Event 2 TPR: ', event_type_2_tpr)
    print('Event 3 FPR: ', event_type_3_fpr)

    f, axes = plt.subplots(ncols=3, sharex=True)
    for ax, event_type in zip(axes, (1, 2, 3)):
        event_type_df = events.groupby(by='event_type').get_group(event_type)
        sns.scatterplot(ax=ax, data=event_type_df, x='position_y', y='position_x', hue='in_swa_zone', alpha=0.5)
        ax.plot(zone_y, zone_x)
        ax.plot(zone_hist_y, zone_hist_x, '--')
        ax.grid()
        ax.set_title(f'Event type: {event_type}')

