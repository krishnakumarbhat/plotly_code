import matplotlib.pyplot as plt
import numpy as np
from aspe.evaluation.RadarObjectsEvaluation.Flags import AllTrueFlag
from shapely.geometry import Polygon


def get_default_data_subsets():
    data_subsets = get_15_12_data_subsets()
    data_subsets.update(get_17_12_data_subsets())

    return data_subsets


def get_whole_data_subsets():
    data_subsets = get_original_data_subsets()
    data_subsets.update(get_4_12_data_subsets())
    data_subsets.update(get_7_12_data_subsets())
    data_subsets.update(get_15_12_data_subsets())
    data_subsets.update(get_17_12_data_subsets())
    return data_subsets


def get_original_data_subsets():
    data_subsets = {
        'BYK-1103, No abs, Pitch 0.0, rel V 60': {
            'Found in F360 bundle version': '02.26.01',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'Pitch': 0,
            'Delta': 60
        },
        'BYK-1103, No abs, Pitch 0.0, rel V 40': {
            'Found in F360 bundle version': '02.26.01',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'Pitch': 0,
            'Delta': 40
        },
        'BYK-1103, With abs, Pitch 0.0, rel V 60': {
            'Found in F360 bundle version': '02.26.01',
            'Suitable for automated testing': 'YES',
            'Absorber': 'with absorber',
            'Pitch': 0,
            'Delta': 60
        },
        'BYK-1103, With abs, Pitch 0.0, rel V 40': {
            'Found in F360 bundle version': '02.26.01',
            'Suitable for automated testing': 'YES',
            'Absorber': 'with absorber',
            'Pitch': 0,
            'Delta': 40
        },
        'BYK-1103, No abs, Pitch 3.7, rel V 60': {
            'Found in F360 bundle version': '02.26.01',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'Pitch': 3.7,
            'Delta': 60
        },
        'BYK-1103, With abs, Pitch 3.7, rel V 60': {
            'Found in F360 bundle version': '02.26.01',
            'Suitable for automated testing': 'YES',
            'Absorber': 'with absorber',
            'Pitch': 3.7,
            'Delta': 60
        },
        'BYK-1103, With abs, Pitch 3.7, rel V 40': {
            'Found in F360 bundle version': '02.26.01',
            'Suitable for automated testing': 'YES',
            'Absorber': 'with absorber',
            'Pitch': 3.7,
            'Delta': 40
        },
        'BYK-1103, With abs, Pitch -3.7, rel V 60': {
            'Found in F360 bundle version': '02.26.01',
            'Suitable for automated testing': 'YES',
            'Absorber': 'with absorber',
            'Pitch': -3.7,
            'Delta': 60
        },
    }
    return data_subsets


def get_4_12_data_subsets():
    data_subsets = {
        '4.12, No abs, Pitch 0.0, rel V 45, left lane': {
            'Found in F360 bundle version': '02.29.0',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'lane': 'left lane',
            'Pitch': 0.0,
            'Delta': 45
        },
        '4.12, No abs, Pitch 0.0, rel V 60, left lane': {
            'Found in F360 bundle version': '02.29.0',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'lane': 'left lane',
            'Pitch': 0.0,
            'Delta': 60
        },
        '4.12, No abs, Pitch -3.7, rel V 45, left lane': {
            'Found in F360 bundle version': '02.29.0',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'lane': 'left lane',
            'Pitch': -3.7,
            'Delta': 45
        },
        '4.12, No abs, Pitch -3.7, rel V 60, left lane': {
            'Found in F360 bundle version': '02.29.0',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'lane': 'left lane',
            'Pitch': -3.7,
            'Delta': 60
        },
        '4.12, No abs, Pitch 3.7, rel V 45, left lane': {
            'Found in F360 bundle version': '02.29.0',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'lane': 'left lane',
            'Pitch': 3.7,
            'Delta': 45
        },
        '4.12, No abs, Pitch 3.7, rel V 60, left lane': {
            'Found in F360 bundle version': '02.29.0',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'lane': 'left lane',
            'Pitch': 3.7,
            'Delta': 60
        }
    }
    return data_subsets


def get_7_12_data_subsets():
    data_subsets = {
        '7.12, With abs, Pitch 3.7, rel V 45, left lane': {
            'Found in F360 bundle version': '2.30.50',
            'Suitable for automated testing': 'YES',
            'Absorber': 'with absorber',
            'lane': 'left lane',
            'Pitch': 3.7,
            'Delta': 45
        },
        '7.12, With abs, Pitch 3.7, rel V 60, left lane': {
            'Found in F360 bundle version': '2.30.50',
            'Suitable for automated testing': 'YES',
            'Absorber': 'with absorber',
            'lane': 'left lane',
            'Pitch': 3.7,
            'Delta': 60
        },
        '7.12, No abs, Pitch 3.7, rel V 45, left lane': {
            'Found in F360 bundle version': '2.30.50',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'lane': 'left lane',
            'Pitch': 3.7,
            'Delta': 45
        },
        '7.12, No abs, Pitch 3.7, rel V 60, left lane': {
            'Found in F360 bundle version': '2.30.50',
            'Suitable for automated testing': 'YES',
            'Absorber': 'no absorber',
            'lane': 'left lane',
            'Pitch': 3.7,
            'Delta': 60
        },
    }
    return data_subsets


def get_15_12_data_subsets():
    data_subsets = {
        '15.12 no absorber, sensor pitch 0.0': {
            'Found in F360 bundle version': '02.30.51',
            'Valid for analysis': 'YES',
            'Absorber': 'no absorber',
            'Pitch': 0
        },
        '15.12 no absorber, sensor pitch -3.7': {
            'Found in F360 bundle version': '02.30.51',
            'Valid for analysis': 'YES',
            'Absorber': 'no absorber',
            'Pitch': -3.7
        },
    }
    return data_subsets


def get_17_12_data_subsets():
    data_subsets = {
        '17.12 with absorber, sensor pitch 0.0': {
            'Found in F360 bundle version': '02.30.51',
            'Valid for analysis': 'YES',
            'Absorber': 'with absorber',
            'Pitch': 0.0
        },
        '17.12 with absorber, sensor pitch -3.7': {
            'Found in F360 bundle version': '02.30.51',
            'Valid for analysis': 'YES',
            'Absorber': 'with absorber',
            'Pitch': -3.7
        },
        '17.12 with absorber, sensor pitch 3.7': {
            'Found in F360 bundle version': '02.30.51',
            'Valid for analysis': 'YES',
            'Absorber': 'with absorber',
            'Pitch': 3.7
        }
    }
    return data_subsets



def get_main_zone():
    # Visualization of simple current version of ROI for particular points ;)
    #   5 _ 4
    #  6 | | 3
    # 1 /___\ 2

    point_1 = (-110.0, -16.0)
    point_2 = (-110.0, 16.0)
    point_3 = (-40.0, 8.0)
    point_4 = (-4.0, 8.0)
    point_5 = (-4.0, -8.0)
    point_6 = (-40.0, -8.0)
    detection_zone = Polygon([point_1,
                              point_2,
                              point_3,
                              point_4,
                              point_5,
                              point_6,
                              point_1])
    return detection_zone


def get_SWA_zone(zones_size_offset=0.0, SWA_zone_fac_y=None):
    if SWA_zone_fac_y is None:
        SWA_zone_fac_y = [1.6, 1.6, 2.0, 0.1, 0.5, 0.5]
    lateral_zone_dist = 3.5
    SWA_zone_pos_x = [-5.0, -40.0, -90.0, -90.0, -40.0, -5.0]
    SWA_zone_pos_y = [elem * lateral_zone_dist for elem in SWA_zone_fac_y]
    SWA_zone_fac_y_hist = []
    SWA_zone_fac_y_hist += [elem * lateral_zone_dist for elem in [0.1, 0.3, 0.4]]
    SWA_zone_fac_y_hist += [-elem * lateral_zone_dist for elem in [0.4, 0.3, 0.1]]
    SWA_zone_pos_y_hist = [elem1 + elem2 for elem1, elem2 in zip(SWA_zone_pos_y, SWA_zone_fac_y_hist)]

    # mlp
    for x in range(len(SWA_zone_pos_y)):
        if x < len(SWA_zone_pos_y) / 2:
            SWA_zone_pos_y[x] = SWA_zone_pos_y[x] - zones_size_offset
            SWA_zone_pos_y_hist[x] = SWA_zone_pos_y_hist[x] - zones_size_offset
        else:
            SWA_zone_pos_y[x] = SWA_zone_pos_y[x] + zones_size_offset
            SWA_zone_pos_y_hist[x] = SWA_zone_pos_y_hist[x] + zones_size_offset

    SWA_right_zone = Polygon([(pos_x, pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y)])
    SWA_right_hist_zone = Polygon([(pos_x, pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y_hist)])
    SWA_left_zone = Polygon([(pos_x, -pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y)])
    SWA_left_hist_zone = Polygon([(pos_x, -pos_y) for pos_x, pos_y in zip(SWA_zone_pos_x, SWA_zone_pos_y_hist)])
    return SWA_left_zone, SWA_right_zone, SWA_left_hist_zone, SWA_right_hist_zone


def get_CVW_zone(zones_size_offset=0.0):
    lateral_zone_dist = 3.5
    CVW_zone_pos_x = [-5.0, -40.0, -90.0, -90.0, -40.0, -5.0]
    CVW_zone_fac_y = [1.5, 1.4, 1.4, 0.6, 0.6, 0.5]
    CVW_zone_pos_y = [elem * lateral_zone_dist for elem in CVW_zone_fac_y]
    CVW_zone_fac_y_hist = []
    CVW_zone_fac_y_hist += [elem * lateral_zone_dist for elem in [0.1, 0.3, 0.4]]
    CVW_zone_fac_y_hist += [-elem * lateral_zone_dist for elem in [0.4, 0.3, 0.1]]
    CVW_zone_pos_y_hist = [elem1 + elem2 for elem1, elem2 in zip(CVW_zone_pos_y, CVW_zone_fac_y_hist)]

    # mlp
    for x in range(len(CVW_zone_pos_y)):
        if x < len(CVW_zone_pos_y) / 2:
            CVW_zone_pos_y[x] = CVW_zone_pos_y[x] - zones_size_offset
            CVW_zone_pos_y_hist[x] = CVW_zone_pos_y_hist[x] - zones_size_offset
        else:
            CVW_zone_pos_y[x] = CVW_zone_pos_y[x] + zones_size_offset
            CVW_zone_pos_y_hist[x] = CVW_zone_pos_y_hist[x] + zones_size_offset

    CVW_right_zone = Polygon([(pos_x, pos_y) for pos_x, pos_y in zip(CVW_zone_pos_x, CVW_zone_pos_y)])
    CVW_right_hist_zone = Polygon([(pos_x, pos_y) for pos_x, pos_y in zip(CVW_zone_pos_x, CVW_zone_pos_y_hist)])
    CVW_left_zone = Polygon([(pos_x, -pos_y) for pos_x, pos_y in zip(CVW_zone_pos_x, CVW_zone_pos_y)])
    CVW_left_hist_zone = Polygon([(pos_x, -pos_y) for pos_x, pos_y in zip(CVW_zone_pos_x, CVW_zone_pos_y_hist)])
    return CVW_left_zone, CVW_right_zone, CVW_left_hist_zone, CVW_right_hist_zone


def plot_zone(zone: Polygon, linewidth=2):
    x, y = zone.exterior.xy
    plt.grid('True')
    plt.axis('equal')
    plt.plot(y, x, linewidth=linewidth)


if __name__ == '__main__':
    plt.figure()
    plt.subplot(1, 2, 1)
    swa_zones = get_SWA_zone()
    [plot_zone(swa_zone) for swa_zone in swa_zones]
    plt.legend(['SWA_left_zone', 'SWA_right_zone', 'SWA_left_hist_zone', 'SWA_right_hist_zone'])
    plt.title('SWA zones')

    plt.subplot(1, 2, 2)
    swa_zones = get_CVW_zone()
    [plot_zone(swa_zone) for swa_zone in swa_zones]
    plt.legend(['CVW_left_zone', 'CVW_right_zone', 'CVW_left_hist_zone', 'CVW_right_hist_zone'])
    plt.title('CVW zones')

    plt.figure()
    plt.subplot(1, 2, 1)
    plt.title('SWA_zones')
    swa_new_narrow_zones_nooverlap = get_SWA_zone(zones_size_offset=0.0, SWA_zone_fac_y=[1.6, 1.6, 2.0, 0.1, 0.5, 0.5])
    swa_new_narrow_zones = get_SWA_zone(zones_size_offset=0.0, SWA_zone_fac_y=[1.6, 1.6, 2.0, 0.0, 0.5, 0.5])
    swa_zones_0_0 = get_SWA_zone(0.0)
    plt.xlim([-10, 10])
    plot_zone(swa_zones_0_0[0], linewidth=1)
    plot_zone(swa_new_narrow_zones[0], linewidth=1)
    plot_zone(swa_new_narrow_zones_nooverlap[0], linewidth=1)
    plt.legend(['SWA_old_zone', 'SWA_new_proposed_zone', 'SWA_new_proposed_zone_nooverlapped'])

    plt.subplot(1, 2, 2)
    plt.title('SWA_hist_zones')
    swa_new_narrow_zones_nooverlap = get_SWA_zone(zones_size_offset=0.0, SWA_zone_fac_y=[1.6, 1.6, 2.0, 0.1, 0.5, 0.5])
    swa_new_narrow_zones = get_SWA_zone(zones_size_offset=0.0, SWA_zone_fac_y=[1.6, 1.6, 2.0, 0.0, 0.5, 0.5])
    swa_zones_0_0 = get_SWA_zone(0.0)
    plt.xlim([-10, 10])
    plot_zone(swa_zones_0_0[2], linewidth=1)
    plot_zone(swa_new_narrow_zones[2], linewidth=1)
    plot_zone(swa_new_narrow_zones_nooverlap[2], linewidth=1)
    plt.legend(['SWA_old_hist_zone', 'SWA_new_proposed_hist_zone', 'SWA_new_proposed_hist_zone_nooverlapped'])

    plt.figure()
    plt.subplot(1, 2, 1)
    plt.title('SWA_left_zones_hist')
    swa_zones_0_0 = get_SWA_zone(0.0)
    swa_zones_0_5 = get_SWA_zone(0.5)
    swa_zones_1_0 = get_SWA_zone(1.0)
    plt.xlim([-10, 10])
    plot_zone(swa_zones_0_0[2], linewidth=1)
    plot_zone(swa_zones_0_5[2], linewidth=1)
    plot_zone(swa_zones_1_0[2], linewidth=1)
    plt.legend(['SWA_left_zone_0.0', 'SWA_left_zone_0.5', 'SWA_left_zone_1.0'])

    plt.subplot(1, 2, 2)
    plt.title('CVW_left_zones_hist')
    cvw_zones_0_0 = get_CVW_zone(0.0)
    cvw_zones_0_5 = get_CVW_zone(0.5)
    cvw_zones_1_0 = get_CVW_zone(1.0)
    plt.xlim([-10, 10])
    plot_zone(cvw_zones_0_0[2], linewidth=1)
    plot_zone(cvw_zones_0_5[2], linewidth=1)
    plot_zone(cvw_zones_1_0[2], linewidth=1)
    plt.legend(['CVW_left_zone_0.0', 'CVW_left_zone_0.5', 'CVW_left_zone_1.0'])
    plt.show()
