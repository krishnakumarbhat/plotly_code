from aspe.extractors.API.mudp import parse_mudp

mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions" # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,
mudp_log_file_path = r"C:\Users\zj2hns\Downloads\WDD404_RWUP_AMS_20191114_085633_114.mudp"

parsed = parse_mudp(mudp_log_file_path, mudp_stream_def_path, streams_to_parse=(3, 4, 5, 6, 7))