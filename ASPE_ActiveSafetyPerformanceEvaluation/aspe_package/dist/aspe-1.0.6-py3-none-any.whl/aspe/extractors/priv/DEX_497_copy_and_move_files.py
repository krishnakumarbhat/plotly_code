from shutil import copyfile
import os

bad_events = [
    r'C:\Logs\DEX_497\DEX_435\20200112T170646_20200112T170656_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_454\BYK-521_NewEvents\SRR_DEBUG\20200208T065841_20200208T065901_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_454\BYK-521_NewEvents\SRR_DEBUG\20200208T065841_20200208T065901_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_454\BYK-521_NewEvents\SRR_DEBUG\20200208T065841_20200208T065901_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_454\BYK-514\log40-49\20200125T175528_20200125T175538_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160037_20200128T160057_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160037_20200128T160057_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160037_20200128T160057_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160057_20200128T160117_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160057_20200128T160117_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160117_20200128T160137_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160117_20200128T160137_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160137_20200128T160157_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\Logs\DEX_497\DEX_475\SRR_DEBUG\20200128T160137_20200128T160157_543078_LB36408_SRR_DEBUG.dvl']

good_events = [
    r'C:\logs\DEX_497\DEX_475\NewEvents_3_12_1\SRR_DEBUG\20200128T155937_20200128T155957_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\logs\DEX_497\DEX_435\20200112T170126_20200112T170136_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\logs\DEX_497\DEX_435\20200112T170226_20200112T170236_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\logs\DEX_497\DEX_435\20200112T170346_20200112T170356_543078_LB36408_SRR_DEBUG.dvl',
    r'C:\logs\DEX_497\DEX_435\20200112T170546_20200112T170556_543078_LB36408_SRR_DEBUG.dvl']

bad_events_out_path = r'C:\logs\DEX_497\logs_from_MST_log_pointer\ticket_events'
good_events_out_path = r'C:\logs\DEX_497\logs_from_log_pointer\stop_and_go_good_events'

for log in bad_events:
    log_mf4 = log.replace('.dvl', '.MF4')
    log_mudp = log.replace('.dvl', '.mudp')

    log_dvl_new_path = os.path.join(bad_events_out_path, os.path.split(log)[1])
    log_mf4_new_path = os.path.join(bad_events_out_path, os.path.split(log_mf4)[1])
    log_mudp_new_path = os.path.join(bad_events_out_path, os.path.split(log_mudp)[1])
    try:
        copyfile(log, log_dvl_new_path)
        copyfile(log_mf4, log_mf4_new_path)
        copyfile(log_mudp, log_mudp_new_path)
    except FileNotFoundError:
        print(f'{log} was not found')

#for log in good_events:
#    log_mf4 = log.replace('.dvl', '.MF4')
#    log_mudp = log.replace('.dvl', '.mudp')
#
#    log_dvl_new_path = os.path.join(good_events_out_path, os.path.split(log)[1])
#    log_mf4_new_path = os.path.join(good_events_out_path, os.path.split(log_mf4)[1])
#    log_mudp_new_path = os.path.join(good_events_out_path, os.path.split(log_mudp)[1])
#
#    copyfile(log, log_dvl_new_path)
#    copyfile(log_mf4, log_mf4_new_path)
#    copyfile(log_mudp, log_mudp_new_path)