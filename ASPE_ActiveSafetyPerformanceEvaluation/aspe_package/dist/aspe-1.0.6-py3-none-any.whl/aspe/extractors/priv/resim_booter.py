from sandbox.resim.F360ResimRunner import F360ResimRunner
from sandbox.resim.F360ResimRunner import TxtReader


log_list_path_1="C:\projects\F360\ASPE\BMW_analysis_for_hanna\log_lists_for_resim\logs_BMWscenarioID19432.txt"
log_list_path_2="C:\projects\F360\ASPE\BMW_analysis_for_hanna\log_lists_for_resim\logs_BMWscenarioID19433.txt"
log_list_path_3="C:\projects\F360\ASPE\BMW_analysis_for_hanna\log_lists_for_resim\logs_BMWscenarioID19434.txt"
log_list_path_4="C:\projects\F360\ASPE\BMW_analysis_for_hanna\log_lists_for_resim\logs_BMWscenarioID19428.txt"
log_list_path_5="C:\projects\F360\ASPE\BMW_analysis_for_hanna\log_lists_for_resim\logs_BMWscenarioID19429.txt"

log_list = TxtReader.get_multi_lines(log_list_path_1)
log_list += TxtReader.get_multi_lines(log_list_path_2)
log_list += TxtReader.get_multi_lines(log_list_path_3)
log_list += TxtReader.get_multi_lines(log_list_path_4)

ini_path = r"\\10.224.186.68\AD-Shared\ASPE\Logs\F360\OXTS_RT-Range\RNA_SRR5\Opole_CW19\F360Tracker_RNA_SUV_Espace.ini"
resim_exe_path = r"C:\wkspaces_git\F360Core\F360TrackerPC_SRR_ESR_vs2015\output\Debug_Win32\resim_f360.exe"
booter = F360ResimRunner(resim_exe_path)
booter.resim_log_list(log_list, ini_path)

