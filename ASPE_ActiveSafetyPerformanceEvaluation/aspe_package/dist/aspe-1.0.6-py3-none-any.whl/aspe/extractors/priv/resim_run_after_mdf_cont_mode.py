import subprocess
import glob

if __name__ == '__main__':
    resim_exe_path = r"C:\wkspaces_git\F360Core\sw\output\Debug_Win32\resim_f360.exe"
    suffix = '_dim_up_fix_b'

    log_list = r"C:\logs\DEX_1260_dim_update_fix\DS_12\SRR_DEBUG\log_list_cont_resim.txt"
    command = f'{resim_exe_path} {log_list} -filelist -osuffix {suffix} -stream BMW -f360trkopt -init_from_log -sync_input -endopt'
    subprocess.call(command)

    log_list = r"C:\logs\DEX_1260_dim_update_fix\DS_12\SRR_DEBUG\log_list_cont_resim_2.txt"
    command = f'{resim_exe_path} {log_list} -filelist -osuffix {suffix} -stream BMW -f360trkopt -init_from_log -sync_input -endopt'
    subprocess.call(command)

    log_list = r"C:\logs\DEX_1260_dim_update_fix\DS_12\SRR_DEBUG\log_list_cont_resim_3.txt"
    command = f'{resim_exe_path} {log_list} -filelist -osuffix {suffix} -stream BMW -f360trkopt -init_from_log -sync_input -endopt'
    subprocess.call(command)