from aspe.extractors.API.mdf import extract_rt_range_3000_from_mf4, extract_f360_bmw_mid_from_mf4
from aspe.extractors.API.mudp import extract_f360_from_mudp
import pandas as pd

mudp_stream_def_path = r"C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"
mudp_path = r"C:\logs\VTV_mf4_logs\A370_mudp_mdf_testing\SRR_DEBUG\rRf360t4180309v205p50_core_2_23\MID_ECU_3_14_210_S_3_14_106_TRA_DS_03_50_35_L_SRR_DEBUG_WBATR91070LC63638_20200617_171104_deb_0005_rRf360t4180309v205p50_core_2_23.mudp"
mudp_converted = r"C:\logs\VTV_mf4_logs\A370_mudp_mdf_testing\SRR_DEBUG\MID_ECU_3_14_210_S_3_14_106_TRA_DS_03_50_35_L_SRR_DEBUG_WBATR91070LC63638_20200617_171104_deb_0005.mudp"
mdf_ref_path = r"C:\logs\VTV_mf4_logs\A370_mudp_mdf_testing\SRR_REFERENCE\MID_ECU_3.14.210_S_3.14.106_TRA_DS_03_50_35_L_SRR_REFERENCE_WBATR91070LC63638_20200617_171104_ref_0005.MF4"
mdf_fas_path = r"C:\logs\VTV_mf4_logs\A370_mudp_mdf_testing\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_03_50_35_L_BN_FASETH_WBATR91070LC63638_20200617_171104_fas_0005.MF4"

f360_debug_orig = extract_f360_from_mudp(mudp_converted, raw_signals=True, objects=False, host=False, mudp_stream_def_path=mudp_stream_def_path)
f360_bmw = extract_f360_bmw_mid_from_mf4(mdf_fas_path, sw_version='A370', raw_signals=True)
f360_resim = extract_f360_from_mudp(mudp_path, raw_signals=True, internal_objects=True, mudp_stream_def_path=mudp_stream_def_path)
rt_extr = extract_rt_range_3000_from_mf4(mdf_ref_path, raw_signals=True)

mudp_scan_indexes = f360_debug_orig.tracker_info.signals.loc[:, 'scan_index'].to_numpy()
mdf_vigem_ts = f360_bmw.objects_header.signals.loc[:, 'vigem_timestamp'].to_numpy()
scan_idx_to_vigem_ts = pd.DataFrame({'vigem_timestamp': mdf_vigem_ts}, index=mudp_scan_indexes)

f360_resim.internal_objects.signals = f360_resim.internal_objects.signals.join(scan_idx_to_vigem_ts, on='scan_index')

