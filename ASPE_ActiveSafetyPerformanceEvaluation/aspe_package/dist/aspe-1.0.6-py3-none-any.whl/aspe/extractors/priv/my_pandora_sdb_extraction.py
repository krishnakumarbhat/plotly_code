from aspe.extractors.API.sdb import extract_pandora_log_from_sdb
from pathlib import Path
from time import time

log_id = '20200709_150423'
t1 = time()
extr = extract_pandora_log_from_sdb(log_id=log_id, save_dir=Path(r'C:\logs\pandora_sdb_downloaded'), load_cache=True)
print(time() - t1)