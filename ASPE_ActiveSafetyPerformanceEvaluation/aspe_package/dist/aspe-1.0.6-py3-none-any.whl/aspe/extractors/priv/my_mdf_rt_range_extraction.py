from aspe.extractors.API.mdf import extract_rt_range_3000_from_mf4
from aspe.extractors.ReferenceExtractor.RtRangeMdfExtractor import RtRangeMdfExtractor
from aspe.utilities.SupportingFunctions import save_to_pkl
import glob
import tqdm
import traceback


logs_dir = r"C:\logs\DS_34_motorcycle_overtaking\SRR_REFERENCE"
logs = glob.glob(logs_dir + '\\*.MF4')

for log in tqdm.tqdm(logs):
    try:
        extracted = extract_rt_range_3000_from_mf4(log, hunter_length=4.7, hunter_width=1.9, hunter_target_instances_shift=10,
                                                   hunter_rear_axle_to_front_bumper_dist=3.7, save_to_file=True)
    except:
        traceback.print_exc()

#extracted = extract_rt_range_3000_from_mf4(log, hunter_length=4.7, hunter_width=1.9, hunter_target_instances_shift=10,
#                                                   hunter_rear_axle_to_front_bumper_dist=3.7, save_to_file=True)