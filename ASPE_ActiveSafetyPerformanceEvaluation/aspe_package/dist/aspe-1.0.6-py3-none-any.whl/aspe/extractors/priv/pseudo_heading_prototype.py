from aspe.extractors.API.mudp import extract_f360_from_mudp, extract_f360_from_mudp_folder
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def bisquare_weight(arr_in, constant_squared):
    below_res = np.abs(arr_in) < constant_squared
    out = np.zeros(len(arr_in))
    out[below_res] = 1 - (arr_in[below_res] / constant_squared)
    out[below_res] = out[below_res]**2
    out[~below_res] = 0
    return out

def huber_weight(arr_in, tuning_const):
    below_res = np.abs(arr_in) < tuning_const
    out = np.zeros(len(arr_in))
    out[below_res] = 1
    out[~below_res] = tuning_const / np.abs(arr_in[~below_res])
    return out


def get_assoc_obj_detections(extracted, unique_obj_id: int):
    object_track = extracted.internal_objects.signals.groupby(by='unique_id').get_group(unique_obj_id)
    object_track_raw = extracted.internal_objects.raw_signals.loc[object_track.index, :]

    object_track.loc[:, 'probability_undet'] = object_track_raw.loc[:, 'probability_undet']
    object_track.loc[:, 'probability_bicycle'] = object_track_raw.loc[:, 'probability_bicycle']

    min_scan_idx, max_scan_idx = object_track.scan_index.min(), object_track.scan_index.max()
    trk_id = object_track.id.iloc[0]

    dets = extracted.detections.signals
    dets_scan_mask = (min_scan_idx <= dets.scan_index) & (dets.scan_index <= max_scan_idx)
    dets_obj_id_mask = dets.assigned_obj_id == trk_id

    object_dets = dets.loc[dets_scan_mask & dets_obj_id_mask, :]
    return object_dets, object_track


def pseudo_heading_metric(pos_x_rotated, pos_y_rotated):
    min_x, min_y = pos_x_rotated.min(), pos_y_rotated.min()
    x_diff, y_diff = pos_x_rotated - min_x, pos_y_rotated - min_y

    #return np.sum(x_diff**2) + np.sum(y_diff**2)
    return np.sum(x_diff * huber_weight(x_diff, 0.25)) + np.sum(y_diff * huber_weight(y_diff, 0.25))


def get_pseudo_heading_in_scan(dets_in_scan):
    pos_x = dets_in_scan.position_x.to_numpy()
    pos_y = dets_in_scan.position_y.to_numpy()

    n_points = 45
    heading_vals = np.linspace(-np.pi/4, np.pi/4, n_points)[:-1]

    fit_scores = []
    for heading_val in heading_vals:
        pos_x_rotated, pos_y_rotated = rotate_by_angle(pos_x, pos_y, heading_val)
        fit_score = pseudo_heading_metric(pos_x_rotated, pos_y_rotated)
        fit_scores.append(fit_score)

    pseudo_heading_score = min(fit_scores)
    pseudo_heading = heading_vals[fit_scores.index(pseudo_heading_score)]

    # once again for debug purpose
    pos_x_rotated, pos_y_rotated = rotate_by_angle(pos_x, pos_y, pseudo_heading)
    fit_score = pseudo_heading_metric(pos_x_rotated, pos_y_rotated)

    return pseudo_heading, pseudo_heading_score


def rotate_by_angle(pos_x_in, pos_y_in, angle):
    pos_x_rotated = np.cos(angle) * pos_x_in + np.sin(angle) * pos_y_in
    pos_y_rotated = -np.sin(angle) * pos_x_in + np.cos(angle) * pos_y_in
    return pos_x_rotated, pos_y_rotated


if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,
    mudp_log_file_path, unique_obj_id = r"C:\logs\COT_2_36_0\TPC2p36_Special1\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario1_30kph_1_111133_001.mudp", 820
    mudp_log_file_path, unique_obj_id = r"C:\logs\COT_2_36_0\TPC2p36_Special1\rRf360t5010309v205p50_debug\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario1_30kph_1_111133_001_rRf360t5010309v205p50_debug.mudp", 810
    mudp_log_file_path, unique_obj_id = r"C:\logs\COT_2_36_0\TPC2p36_Special1\rRf360t5010309v205p50_dev_04603a\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario1_50kph_2_112338_001_rRf360t5010309v205p50_dev_04603a.mudp", 753
    mudp_log_file_path, unique_obj_id = r"C:\logs\COT_2_36_0\TPC2p36_Special3\rRf360t5010309v205p50_dev_04603a\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario3_10kph_1_144659_001_rRf360t5010309v205p50_dev_04603a.mudp", 208

    extracted = extract_f360_from_mudp(mudp_log_file_path, mudp_stream_def_path=mudp_stream_def_path,
                                       internal_objects=True,
                                       detections=True,
                                       raw_signals=True,
                                       force_extract=True,
                                       save_to_file=True)
    out = {
        'scan_index': [],
        'pseudo_heading': [],
        'pseudo_heading_score': []
    }

    object_dets, object_track = get_assoc_obj_detections(extracted, unique_obj_id)
    for scan_index, dets_in_scan in object_dets.groupby(by='scan_index'):
        if len(dets_in_scan) > 5:
            pseudo_heading, pseudo_heading_score = get_pseudo_heading_in_scan(dets_in_scan)
        else:
            pseudo_heading, pseudo_heading_score = np.nan, np.nan

        out['scan_index'].append(scan_index)
        out['pseudo_heading'].append(pseudo_heading)
        out['pseudo_heading_score'].append(pseudo_heading_score)

    out_df = pd.DataFrame(out)
    object_track = object_track.join(out_df.set_index('scan_index'), on='scan_index')

    object_track.set_index('scan_index', inplace=True)
    f, axes = plt.subplots(nrows=3, sharex=True)
    x = object_track.index.to_numpy()
    axes[0].plot(x, np.rad2deg(object_track.bounding_box_orientation), label='heading_from_log')
    axes[0].plot(x, np.rad2deg(object_track.pseudo_heading), label='psuedo heading - proto')
    axes[0].plot(x, np.rad2deg(object_track.probability_undet), label='pseudo heading log')
    axes[0].plot(x, np.rad2deg(object_track.probability_bicycle), label='pseudo heading log std')
    axes[0].axhline(y=0.0, label='expected', linestyle="--")

    axes[1].plot(object_track.n_dets, label='ndets')
    axes[2].plot(object_track.pseudo_heading_score, label='psuedo heading score')

    for ax in axes:
        ax.grid()
        ax.legend()