from glob import glob
from aspe.extractors.API.mdf import extract_rt_range_3000_from_mf4
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from pathlib import Path
from tqdm import tqdm


log_dir = r'C:\logs\DS_34_motorcycle_overtaking\SRR_REFERENCE'
logs_list = glob(log_dir + r'\*.MF4')
pp = PdfPages(log_dir + f'\\target_position_plots.pdf')

for log_path in tqdm(logs_list):
    extracted = extract_rt_range_3000_from_mf4(log_path, hunter_length=4.7, hunter_width=1.9, hunter_target_instances_shift=10,
                                               hunter_rear_axle_to_front_bumper_dist=3.7, save_to_file=True)

    target = extracted.objects.signals
    f, ax = plt.subplots(nrows=2, figsize=(16, 8))
    ax[0].plot(target.scan_index, target.position_x)
    ax[1].plot(target.scan_index, target.position_y)

    ax[0].set_title('position x')
    ax[1].set_title('position y')

    f.suptitle(Path(log_path).stem)
    pp.savefig(f)
    plt.close(f)
pp.close()
