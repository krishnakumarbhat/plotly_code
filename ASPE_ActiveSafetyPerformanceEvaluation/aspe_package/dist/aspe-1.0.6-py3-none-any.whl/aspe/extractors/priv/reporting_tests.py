from aspe.report_generator.support_functions import load_pickle
from aspe.report_generator.DeviationResultsBuilder import DeviationResultsBuilder
from aspe.report_generator.BinaryClassificationBuilder import BinaryClassificationBuilder
from aspe.report_generator.Plotter import Plotter
from aspe.report_generator.BaseBuilder import BaseBuilder
from aspe.report_generator.TestSetupBuilder import TestSetupBuilder

if __name__ == '__main__':
    data_paths = []
    data_paths.append(r"C:\logs\ASPE\LSS_CURVES\rRf360t3050303v202r1\rRf360t3050303v202r1_aggregated_data.pickle")
    data_paths.append(r"C:\logs\ASPE\LSS_CURVES\rRf360t3060304v202r1\rRf360t3060304v202r1_aggregated_data.pickle")
    output_data = {}
    ref_data = {}
    est_data = {}
    log_data = {}
    host_data = {}
    for path in data_paths:
        data = load_pickle(path)
        ref_data[data['resim_extension']] = data['reference_obj_data']
        est_data[data['resim_extension']] = data['estimated_obj_data']
        log_data[data['resim_extension']] = data['log_data']
        host_data[data['resim_extension']] = data['host_data']
    css_path = r"C:\wkspaces\ASPE0000_00_Common\report_generator\CSS\default.css"
    config = {'plot_style': 'default',
              'default_plot_size': (10, 4),
              'figures_save_path': r"\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example\report_module\temp_plots",
              'host_size': (2, 5)}
    BaseBuilder.templates_dir = r'C:\wkspaces\ASPE0000_00_Common\report_generator\templates'
    dev_columns = [
        'deviation_pos_vcsx',
        'deviation_pos_vcsy',
        'deviation_vel_vcsx',
        'deviation_vel_vcsy']
    sections_names = [
        'Position VCS X deviation',
        'Position VCS Y deviation',
        'Velocity VCS X deviation',
        'Velocity VCS Y deviation']
    units = ['[m]', '[m]', '[m/s]', '[m/s]']
    template_path = "SingleDeviationResults.html"
    plotter = Plotter(config)
    dev_results_builder = DeviationResultsBuilder(ref_data, dev_columns, sections_names, units, template_path, plotter)
    dev_results_builder.save_pdf(
        r'\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example\report_module\pdf_reports\dev_calc.pdf')
    template_path = "BinaryClassification.html"
    bin_results_builder = BinaryClassificationBuilder(ref_data, est_data, template_path, plotter)
    bin_results_builder.save_pdf(r'\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example\report_module\pdf_reports\bin_class.pdf')
    #template_path = "LogsData.html"
    #logs_data_builder = LogsDataBuilder(log_data, template_path, plotter)
    #logs_data_builder.save_pdf(
    #    r'\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example\report_module\pdf_reports\logs_data.pdf')
    #template_path = "HostData.html"
    #host_data_builder = HostDataBuilder(host_data, template_path, plotter)
    #host_data_builder.save_pdf(
    #    r'\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example\report_module\pdf_reports\host_data.pdf')
    #template_path = "ReferenceData.html"
    #ref_data_builder = ReferenceDataBuilder(ref_data, template_path, plotter)
    #ref_data_builder.save_pdf(
    #    r'\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example\report_module\pdf_reports\ref_data.pdf')
    tc_description = 'report example, compared 2 resim versions - first one without proper aligment angles and second with it'
    test_setup_builder = TestSetupBuilder(host_data, ref_data, log_data, est_data, tc_description, plotter)
    test_setup_builder.save_pdf(
        r'\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example\report_module\pdf_reports\test_setup.pdf')