from aspe.extractors.API.mdf import extract_f360_bmw_mid_from_mf4, extract_f360_bmw_mid_from_mf4_folder, mdf_parser
from aspe.utilities.SupportingFunctions import save_to_pkl
from srr5_dev_tools.mgp_module import load
from pathlib import Path
import numpy as np
import cProfile, pstats
from io import StringIO

#log_path = r"C:\logs\VTV_mf4_logs\A370\DS_01_target_overtaking\A430_ATS+6\BN_FASETH\MID_ECU_3.14.210_S_3.14.106_TRA_DS_01_50_80_R_BN_FASETH_WBATR91070LC63638_20200617_165514_fas_0001.mf4"
#extr = extract_f360_bmw_mid_from_mf4(log_path, raw_signals=True, sw_version='A430', save_to_file=True, force_extract=True)

log_dir = r"C:\logs\A370_logs"
extract_f360_bmw_mid_from_mf4(log_path, raw_signals=True, sw_version='A430', force_parse=True, save_to_file=True)
