from aspe.extractors import extract_gdsr_tracker_bmw_low_from_mf4

p = r"C:\logs\gdsr_from_mf4_extraction_test\BN_CALIFR\A390_LOW_SEN_3_15_111_TRACKER_DS_01_VEGO_120_L_BN_CALIFR__20200827_110722_cal_0000.MF4"
ex = extract_gdsr_tracker_bmw_low_from_mf4(p, 'A410')