from os import path
import glob
import subprocess


def find_logs_after_resim(log_path):
    dir, log_name = path.split(log_path)
    log_name_without_ext, _ = path.splitext(log_name)
    log_list = glob.glob(f'{dir}\\*_exec_time_test_*\\{log_name_without_ext}*.mudp')
    return log_list


def resim_data(log_path, resim_exe_path, sw_signature, bmw_stream=False, ini_file=None, sync_input=True, iter_num=0):
    command = f'{resim_exe_path} {log_path} -osuffix _{sw_signature}_exec_time_test_{iter_num} '

    if bmw_stream:
        command += '-stream BMW'

    if ini_file is not None:
        init_command = f'-ini {ini_file}'
    else:
        init_command = '-init_from_log'

    if sync_input:
        sync_command = '-sync_input'
    else:
        sync_command = ''
    command += f'-f360trkopt {init_command} {sync_command} -endopt'
    subprocess.call(command)
