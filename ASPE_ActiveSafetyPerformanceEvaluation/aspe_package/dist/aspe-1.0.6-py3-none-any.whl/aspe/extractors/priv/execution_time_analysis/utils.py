import pickle
import pandas as pd


def load_multiple_sw_results(input_dict):
    overall_timings = []
    itemized_timings = []
    for sw_signature, pickle_path in input_dict.items():
        with open(pickle_path, 'rb') as f:
            output = pickle.load(f)
            overall_df = output['overall_times']
            itemized_df = output['itemized_times']
        overall_df.loc[:, 'sw_signature'] = sw_signature
        itemized_df.loc[:, 'sw_signature'] = sw_signature

        overall_timings.append(overall_df)
        itemized_timings.append(itemized_df)

    overall_times_df = pd.concat(overall_timings).reset_index(drop=True)
    itemized_time_df = pd.concat(itemized_timings).reset_index(drop=True)
    return overall_times_df, itemized_time_df


def save_to_pickle(median_overall_times, median_itemized_times, log_path, sw_signature):
    pickle_save_path = log_path.replace('.dvl', f'_timing_info{sw_signature}.pickle')
    with open(pickle_save_path, 'wb') as f:
        to_save = {
            'overall_times': median_overall_times,
            'itemized_times': median_itemized_times
        }
        pickle.dump(to_save, f)
    print(f'Saved results to {pickle_save_path}')
