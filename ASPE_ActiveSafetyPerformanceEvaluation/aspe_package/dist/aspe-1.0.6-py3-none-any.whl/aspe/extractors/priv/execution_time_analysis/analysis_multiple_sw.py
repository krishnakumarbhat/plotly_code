from .utils import load_multiple_sw_results
from .plotting import plot_absolute_results, plot_relative_results


def multiple_sw_exec_time_analysis(pickle_path_per_sw: dict, baseline_sw_signature: str, top_n_results: int = None):
    overall_times_df, itemized_time_df = load_multiple_sw_results(pickle_path_per_sw)

    plot_absolute_results(overall_times_df, sw_compare=True, top_n_results=top_n_results,
                          subtitle='Overall execution times')
    plot_relative_results(overall_times_df, baseline_sw_signature=baseline_sw_signature, top_n_results=top_n_results,
                          subtitle='Overall execution times')
    plot_absolute_results(itemized_time_df, sw_compare=True, top_n_results=top_n_results,
                          subtitle='Itemized execution times')
    plot_relative_results(itemized_time_df, baseline_sw_signature=baseline_sw_signature, top_n_results=top_n_results,
                          subtitle='Itemized execution times')


if __name__ == '__main__':
    pickle_path_per_sw = {
        'sw_1': "C:\logs\checkout_logs\F360_HGR770_20200622_A370_02p22p00_5Radar_Checkout_101305_001_timing_infocore_23.pickle",
        'sw_2': "C:\logs\checkout_logs\F360_HGR770_20200622_A370_02p22p00_5Radar_Checkout_101305_001_timing_infocore_23_1.pickle"
    }
    baseline_sw = 'sw_1'
    top_n_results = 10

    multiple_sw_exec_time_analysis(pickle_path_per_sw, baseline_sw, top_n_results=top_n_results)
