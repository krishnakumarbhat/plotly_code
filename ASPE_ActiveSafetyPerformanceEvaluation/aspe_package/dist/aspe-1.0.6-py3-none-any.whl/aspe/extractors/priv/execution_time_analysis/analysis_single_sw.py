from .resim import resim_data, find_logs_after_resim
from .data_providing import parse_and_get_medians
from .utils import save_to_pickle
import tqdm
from .plotting import plot_absolute_results, plot_relative_results


def single_sw_exec_time_analysis(log_path, sw_signature, stream_def_path, resim_exe_path, resim_iterations, bmw_stream=False, ini_file=None, sync_input=True, top_n_results=None):
    print('RE-SIMULATION STARTED ')
    for n in tqdm.tqdm(range(resim_iterations)):
        resim_data(log_path, resim_exe_path, sw_signature, bmw_stream=bmw_stream, ini_file=ini_file, sync_input=sync_input, iter_num=n)
    ressimed_logs = find_logs_after_resim(log_path)
    median_overall_times, median_itemized_times = parse_and_get_medians(ressimed_logs, stream_def_path)

    plot_absolute_results(median_overall_times, top_n_results=top_n_results, subtitle='Overall execution times')
    plot_relative_results(median_overall_times, top_n_results=top_n_results, subtitle='Overall execution times')
    plot_absolute_results(median_itemized_times, top_n_results=top_n_results, subtitle='Itemized execution times')
    plot_relative_results(median_itemized_times, top_n_results=top_n_results, subtitle='Itemized execution times')

    save_to_pickle(median_overall_times, median_itemized_times, log_path, sw_signature)


if __name__ == '__main__':
    # Example call:
    resim_exe_path = r"C:\wkspaces_git\F360Core\sw\output\Debug_Win32\resim_f360.exe"
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable
    log_path = r"C:\logs\checkout_logs\F360_HGR770_20200622_A370_02p22p00_5Radar_Checkout_101305_001.dvl"
    sw_signature = 'core_22'
    resim_iterations = 10
    top_n_results = 10  # could be None if you want all modules results
    single_sw_exec_time_analysis(log_path, sw_signature, mudp_stream_def_path, resim_exe_path, resim_iterations=2, top_n_results=10)
