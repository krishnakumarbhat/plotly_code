import matplotlib.pyplot as plt
import seaborn as sb


def plot_absolute_results(execution_time_df, sw_compare=False, top_n_results=None, subtitle=''):
    core_time_mask = (execution_time_df.module == 'time_taken_core_and_udp_packing') | (execution_time_df.module == 'time_taken_core_tracker')
    core_time_df = execution_time_df.loc[core_time_mask, :].reset_index(drop=True)
    submodules_time_df = execution_time_df.loc[~core_time_mask, :].reset_index(drop=True)

    if top_n_results is not None:
        ''' Gen sum of execution time for each module and get only N largest values'''
        sorted_by_time_sum = submodules_time_df.groupby(by='module').sum().sort_values(by='execution_time', ascending=False).reset_index()
        top_n_modules = sorted_by_time_sum.head(top_n_results).loc[:, 'module']
        submodules_time_df = submodules_time_df[submodules_time_df['module'].isin(top_n_modules)].reset_index(drop=True)

    f, axes = plt.subplots(ncols=2, gridspec_kw={'width_ratios': [1, 3]}, figsize=(15, 9))
    if sw_compare:
        hue = 'sw_signature'
    else:
        hue = None
    sb.boxplot(ax=axes[0], data=core_time_df, x='module', y='execution_time', hue=hue, whis=1)
    sb.boxplot(ax=axes[1], data=submodules_time_df, x='module', y='execution_time', hue=hue, whis=1)

    for ax in axes:
        ax.grid()
        ax.set_ylabel(f'execution time [s]')
        for tick in ax.get_xticklabels():
            tick.set_rotation(60)
            tick.set_fontsize(6)
    if top_n_results is not None:
        sup_title = f'F360 core modules relative execution time, top {top_n_results} results \n {subtitle}'
    else:
        sup_title = f'F360 core modules relative execution time \n {subtitle}'
    f.suptitle(sup_title)
    f.subplots_adjust(bottom=0.2)


def plot_relative_results(execution_time_df, baseline_sw_signature=None, top_n_results=None, subtitle=''):
    rel_time_df = execution_time_df.copy()
    for scan_idx, single_scan in rel_time_df.groupby(by='scan_index'):
        if baseline_sw_signature is None:
            base_time = single_scan.loc[single_scan.module == 'time_taken_core_tracker', 'execution_time']
        else:
            mask = (single_scan.module == 'time_taken_core_tracker') & (single_scan.sw_signature == baseline_sw_signature)
            base_time = single_scan.loc[mask, 'execution_time']
        rel_time_df.loc[single_scan.index, 'execution_time'] = 100 * single_scan.execution_time / base_time.iloc[0]

    core_time_mask = (execution_time_df.module == 'time_taken_core_and_udp_packing') | (execution_time_df.module == 'time_taken_core_tracker')
    df_to_plot = rel_time_df.loc[~core_time_mask, :].reset_index()

    if top_n_results is not None:
        ''' Gen sum of execution time for each module and get only N largest values'''
        if baseline_sw_signature is not None:
            temp_df = df_to_plot.loc[df_to_plot.sw_signature == baseline_sw_signature]
        else:
            temp_df = df_to_plot
        sorted_by_time_sum = temp_df.groupby(by='module').sum().sort_values(by='execution_time', ascending=False).reset_index()
        top_n_modules = sorted_by_time_sum.head(top_n_results).loc[:, 'module']
        df_to_plot = df_to_plot[df_to_plot['module'].isin(top_n_modules)].reset_index(drop=True)

    f, ax = plt.subplots(figsize=(15, 9))
    if baseline_sw_signature is None:
        hue = None
    else:
        hue = 'sw_signature'

    sb.boxplot(ax=ax, data=df_to_plot, x='module', y='execution_time', hue=hue, whis=1)

    if baseline_sw_signature is not None:
        ax.set_ylabel(f'exec. time rel. to {baseline_sw_signature} [%]')
    else:
        ax.set_ylabel(f'relative execution time [%]')
    ax.grid()
    for tick in ax.get_xticklabels():
        tick.set_rotation(60)
        tick.set_fontsize(6)
    if top_n_results is not None:
        sup_title = f'F360 core modules relative execution time, top {top_n_results} results \n {subtitle}'
    else:
        sup_title = f'F360 core modules relative execution time \n  {subtitle}'
    f.suptitle(sup_title)
    f.subplots_adjust(bottom=0.25)
