# coding=utf-8
"""
F360 Radar Sensors Data Set
"""
from typing import Optional

from aspe.extractors.Interfaces.IRadarSensors import IRadarSensors
import pandas as pd


class F360RadarSensors(IRadarSensors):
    """
    F360 Radar Sensors data set class
    """
    def __init__(self):
        super().__init__()
