import pandas as pd
import numpy as np
from aspe.utilities.SupportingFunctions import load_from_pkl, save_to_pkl


def load_perf_eval_results(pe_outputs_paths):
    atrs_to_concat = [
        'kpis_binary_class_aggregated',
        'kpis_pairs_features_aggregated',
        {'pe_results_obj_pairs': ['signals']}
    ]
    dict_of_dfs = {}
    for sw_version, test_cases in pe_outputs_paths.items():
        for test_case, tc_pickle_path in test_cases.items():
            pe_output = load_from_pkl(tc_pickle_path)
            for att_name in atrs_to_concat:
                atr = pe_output.__getattribute__(att_name)
                if isinstance(att_name, str):
                    try:
                        dict_of_dfs[att_name].append(atr)
                    except KeyError:
                        dict_of_dfs[att_name] = [atr]  # if there is no key - create single element list
                elif isinstance(att_name, dict):
                    pass


if __name__ == '__main__':
    # TODO -> create_report_input(logs_main_dir, sw_version_subfolders, test_cases_signatures) -> dict

    report_input = {
        'sw_version_1': {
            'test_case_1': r"C:\logs\bbox_managment\SRR_DEBUG\rRf360t4280309v205p50_resize_fix_B\DS_01_pe_output.pickle",
            'test_case_2': r"C:\logs\bbox_managment\SRR_DEBUG\rRf360t4280309v205p50_resize_fix_B\DS_07_pe_output.pickle",
        },

        'sw_version_2': {
            'test_case_1': r"C:\logs\bbox_managment\SRR_DEBUG\rRf360t4280309v205p50_resize_fix\DS_01_pe_output.pickle",
            'test_case_2': r"C:\logs\bbox_managment\SRR_DEBUG\rRf360t4280309v205p50_resize_fix\DS_07_pe_output.pickle",
        },
    }

    kpis = load_perf_eval_results(report_input)
    # TODO -> load_perf_eval_results(report_input: dict) -> pd.DataFrame
