from aspe.providers.Preprocessing.ScanIndexSynch.nearest_timestamp_synch import \
    NearestTimestampSynch
from aspe.providers.Preprocessing import \
    ShiftSlaveExtractedDataTimestamp


def basic_radar_data_preprocessing(f360_extracted_data, rt_extracted_data, time_offset=-0.035):
    '''
    Basic radar data preprocessing -> with simple time translation and scan index synchronization
    :param f360_extracted_data:
    :param rt_extracted_data:
    :param time_offset:
    :return:
    '''
    time_synchronized = ShiftSlaveExtractedDataTimestamp(offset=time_offset)
    time_synch_f360_data, time_synch_rt_data = time_synchronized.synch(master_extracted_data=f360_extracted_data,
                                                                       slave_extracted_data=rt_extracted_data)

    rt_f360_si_synch = NearestTimestampSynch()
    scan_index_synch_f360_data, scan_index_synch_rt_data = rt_f360_si_synch.synch(time_synch_f360_data,
                                                                                  time_synch_rt_data,
                                                                                  time_synch_f360_data.tracker_info,
                                                                                  time_synch_rt_data.host)
    return scan_index_synch_f360_data, scan_index_synch_rt_data
