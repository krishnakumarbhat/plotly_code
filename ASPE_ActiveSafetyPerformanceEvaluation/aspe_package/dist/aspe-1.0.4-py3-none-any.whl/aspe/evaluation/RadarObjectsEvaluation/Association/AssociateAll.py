import pandas as pd

from aspe.evaluation.RadarObjectsEvaluation.Association import IAssociation


class AssociateAll(IAssociation):
    def associate(self, pe_pairs: pd.DataFrame) -> pd.Series:
        return pd.Series(True, index=pe_pairs.index)
