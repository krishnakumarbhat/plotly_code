from aspe.extractors.API.mdf import extract_f360_bmw_mid_from_mf4

"""
Helper script which uses aspe.extractors API to parse and extract someip data from single mf4 file.
Check extract_f360_bmw_mid_from_mf4 function docstring to see what type of arguments it's take.
"""

mdf_log_file_path = r"PATH\TO\MDF\FILE.mf4"

extracted = extract_f360_bmw_mid_from_mf4(mdf_log_file_path, save_to_file=True, raw_signals=True)

"""Now in log directory there will be 
LOG_NAME_f360_mf4_bmw_mid_extracted.pickle file created. Now it could be loaded to ASPE GUI"""