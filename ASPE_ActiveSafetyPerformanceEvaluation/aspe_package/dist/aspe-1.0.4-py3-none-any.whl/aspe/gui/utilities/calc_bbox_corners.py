import numpy as np
import pandas as pd


def calc_bbox_corners(center_x, center_y, orientation, length, width):
    rot_matrix = np.array([
        [np.cos(orientation), np.sin(orientation)],
        [-np.sin(orientation), np.cos(orientation)]]).transpose((2, 0, 1))

    position_matrix = np.array([
        [-length/2, -width / 2],
        [-length/2, width / 2],
        [length / 2, width / 2],
        [length / 2, - width / 2]
    ]).transpose((2, 0, 1))

    position_rotated = position_matrix @ rot_matrix
    corners_x = position_rotated[:, :, 0] + np.tile(center_x, (4, 1)).T
    corners_y = position_rotated[:, :, 1] + np.tile(center_y, (4, 1)).T

    corners_len = corners_x.shape[0]
    corners_x = np.hstack([corners_x, corners_x[:, 0].reshape(-1, 1), np.full((corners_len, 1), np.nan)]).reshape(-1)
    corners_y = np.hstack([corners_y, corners_y[:, 0].reshape(-1, 1), np.full((corners_len, 1), np.nan)]).reshape(-1)

    return corners_x, corners_y


def flatten_single_scan_corners_data(corners):
    x_corners = corners.loc[:, ['corner_x_RL', 'corner_x_RR', 'corner_x_FR', 'corner_x_FL', 'corner_x_RL_2', 'x_nans']].to_numpy()
    y_corners = corners.loc[:, ['corner_y_RL', 'corner_y_RR', 'corner_y_FR', 'corner_y_FL', 'corner_y_RL_2', 'y_nans']].to_numpy()
    df_indexes = corners.index.to_numpy()
    df_indexes = np.tile(df_indexes, (5, 1)).T
    df_indexes = np.hstack([df_indexes, np.full((df_indexes.shape[0], 1), -1)])

    x_corners_flat = x_corners.reshape(-1)
    y_corners_flat = y_corners.reshape(-1)
    df_indexes_flat = df_indexes.reshape(-1)
    return x_corners_flat, y_corners_flat, df_indexes_flat


def flatten_single_scans_corneres_data_diagonal_only(corners):
    x_corners = corners.loc[:, ['corner_x_RL', 'corner_x_FR', 'x_nans']].to_numpy()
    y_corners = corners.loc[:, ['corner_y_RL', 'corner_y_FR', 'y_nans']].to_numpy()
    df_indexes = corners.index.to_numpy()
    df_indexes = np.tile(df_indexes, (3, 1)).T
    df_indexes = np.hstack([df_indexes, np.full((df_indexes.shape[0], 1), -1)])

    x_corners_flat = x_corners.reshape(-1)
    y_corners_flat = y_corners.reshape(-1)
    df_indexes_flat = df_indexes.reshape(-1)
    return x_corners_flat, y_corners_flat, df_indexes_flat