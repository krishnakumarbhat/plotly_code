# coding=utf-8
"""
Rt Objects dataset interface
"""
import pandas as pd
from typing import Optional
from datetime import datetime
from aspe.extractors.Interfaces.IObjects import IObjects


class RtObjects(IObjects):
    """
    Rt Objects dataset class
    """
    def __init__(self):
        super().__init__()
        signal_names = {
            'f_iscomplete': bool,
            'utc_timestamp': datetime,
            'wcs_bounding_box_orientation': float,
            'acceleration_tcs_x': float,
            'acceleration_tcs_y': float,
            'curvature': float,
            'yaw_acceleration': float,
        }
        signals_info_local = pd.DataFrame({'signal_name': list(signal_names.keys()),
                                           'signal_type': list(signal_names.values())})
        self.signals_info = self.signals_info.append(signals_info_local)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=list(signal_names.keys()))], sort=False)
        self.max_possible_obj_count: Optional[int] = None
        self.coordinate_system: Optional[str] = None
