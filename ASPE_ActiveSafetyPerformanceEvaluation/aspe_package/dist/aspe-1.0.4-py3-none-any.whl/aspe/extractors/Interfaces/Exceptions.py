class WrongCoordinateSystem(Exception):
    """
    Raised when coordinate system is wrong
    """
    pass
