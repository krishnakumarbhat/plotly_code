# coding=utf-8
"""
F360 MUDP objects builder selector
"""
from aspe.extractors.F360.Mudp.Builders.OAL.F360MudpOALObjectsHeaderBuilderV4 import F360MudpOALObjectsHeaderBuilderV4
from aspe.extractors.Mudp.IMudpBuilderSelector import IMudpBuilderSelector


class F360MudpOALObjectsHeaderBuilderSelector(IMudpBuilderSelector):
    """
    Output Adaptation Layer objects builder selector for F360 MUDP data.
    """
    required_stream_numbers = {33}

    available_builders = (
        F360MudpOALObjectsHeaderBuilderV4,
    )
