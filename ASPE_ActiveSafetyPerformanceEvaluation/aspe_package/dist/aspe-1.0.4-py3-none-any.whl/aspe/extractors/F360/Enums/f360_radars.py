# coding=utf-8
"""
F360 Radars Enums (comes from C code)
"""
from enum import Enum


class F360RadarSensorMountingLocation(Enum):
    """
    F360 Mounting location for radar sensors
    """
    UNKNOWN = -1
    LEFT_FORWARD = 0
    LEFT_SIDE1 = 8
    LEFT_SIDE2 = 16
    LEFT_REAR = 24
    CENTER_FORWARD = 1
    CENTER_REAR = 25
    RIGHT_FORWARD = 2
    RIGHT_SIDE1 = 10
    RIGHT_SIDE2 = 18
    RIGHT_REAR = 26
    CENTER2_FORWARD = 3
    CENTER2_REAR = 27


class F360RadarSensorType(Enum):
    """
    F360 Types of Radar sensors
    """
    UNKNOWN = -1
    SRR2_RADAR = 0
    SRR4_RADAR = 1
    SRR4_MM_RADAR = 2
    SRR5_RADAR = 3
    ESR_RADAR = 5
    MRR1_RADAR = 6
    MRR2_RADAR = 7
    MRR3_RADAR = 8
    LIDAR = 9
    VISION = 10
    VEHICLE = 11
