from aspe.parsers.xtrkParser import xtrkParser


def extract_f360_from_xtrk(xtrk_path: str):
    parser = xtrkParser(xtrk_path)
    parsed = parser.parse()
    return parsed


if __name__ == '__main__':
    xtrk_path = r"C:\logs\refactoring_verification\PSA\rRf360t4310309v205p50_debug\PSA_20180613_152933_003_rRf360t4310309v205p50_debug.xtrk"
    parsed = extract_f360_from_xtrk(xtrk_path)
