import matplotlib.pyplot as plt

def plot_fun(pe_output, feature_signature_x, kpi_signature_x, feature_signature_y, kpi_signature_y ):
    kpis = pe_output.kpis_pairs_features_per_log
    x_data = kpis.loc[(kpis['feature_signature'] == feature_signature_x) & (kpis['kpi_signature'] == kpi_signature_x), 'kpi_value'].to_numpy()
    y_data = kpis.loc[(kpis['feature_signature'] == feature_signature_y) & (kpis['kpi_signature'] == kpi_signature_y), 'kpi_value'].to_numpy()

    f, ax = plt.subplots()
    ax.plot(x_data, y_data, 'o')
    ax.grid()
    ax.set_xlabel(f'{feature_signature_x} {kpi_signature_x}')
    ax.set_ylabel(f'{feature_signature_y} {kpi_signature_y}')
    plt.show()
