import pickle
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


def load_pickle(pickle_path):
    with open(pickle_path, 'rb') as handle:
        data = pickle.load(handle)
    return data


def plot_timing_hist(data_list, column_name, title, labels, save_path, rel_column):
    fig, axes = plt.subplots(len(data_list), 1, figsize=(8,8))

    mins = []
    maxes = []
    for n, data in enumerate(data_list):
        curr_data = data[column_name]/data[rel_column]
        mins.append(curr_data.min())
        maxes.append(curr_data.max())
        if len(data_list) == 1:
            curr_data.hist(ax=axes, bins=100)
        else:
            curr_data.hist(ax=axes[n], bins=100)
    min_val = min(mins)
    max_val = max(maxes)
    for n, data in enumerate(data_list):
        if len(data_list) == 1:
            ax = axes
        else:
            ax = axes[n]
        ax.set_xlim([min_val, max_val])
        ax.set_title(labels[n], fontsize=9)
    plt.tight_layout(rect=[0.03, 0.03, 0.95, 0.95])
    fig.suptitle(title, y=0.96, fontsize=12)
    ax.set_xlabel('execution time rel. trk.core execution time [-]')
    plt.savefig(save_path)

def plot_cdf(data_list, signal_name, labels, title_suffix, save_path, rel_column):
    mins = []
    maxs = []
    for idx, sw_data in enumerate(data_list):
        data = sw_data[signal_name]/sw_data[rel_column]
        mins.append(data.min())
        maxs.append(data.max())
    min = np.array(mins).min()
    max = np.array(maxs).max()

    x = np.linspace(min, max, 100)
    data_raw = {'x': x}
    for idx, sw_data in enumerate(data_list):
        xp = np.sort(sw_data[signal_name]/sw_data[rel_column])
        yp = np.array(range(len(xp))) / float(len(xp))
        y_cdf = np.interp(x, xp, yp)
        data_raw[labels[idx]] = y_cdf
    df = pd.DataFrame(data_raw)
    df.set_index('x', inplace=True)
    ax = df.plot(figsize=(8,6))
    ax.set_title('CDF of ' + title_suffix)
    ax.grid()
    ax.set_xlabel('execution time rel. trk.core execution time [-]')
    ax.set_ylabel('quantile')
    plt.savefig(save_path)

baseline_path = r"C:\logs\relevant_logs\base_timing_info.pickle"  # 2.6
gerrit_path = r"C:\logs\relevant_logs\gerrit_timing_info.pickle"
mst_path = r"C:\logs\relevant_logs\newest_mat_timing_info.pickle"
sgu_path = r"C:\logs\relevant_logs\newest_szymtiming_info.pickle"  # 2.7

base_data = load_pickle(baseline_path)
gerrit_data = load_pickle(gerrit_path)
mst_data = load_pickle(mst_path)
sgu_data = load_pickle(sgu_path)

data_list = []
data_list.append(base_data)
#data_list.append(gerrit_data)
#data_list.append(mst_data)
data_list.append(sgu_data)

labels = [
    '2.6',
    #'AIT_824_p13',
    #'clust and obj prio',
    '2.7',
]

rel_column = 'overall_execution_times.time_taken_core_tracker'

#column_name = 'overall_execution_times.time_taken_core_tracker'
#plot_timing_hist(data_list, column_name, 'Tracker core exect time', labels, 'trk_cor_exec_time_hist.png', rel_column)
#plot_cdf(data_list, column_name, labels, 'tracker core exec time', 'trk_cor_exec_time_cdf.png', rel_column)

column_name = 'overall_execution_times.time_update_tracks'
plot_timing_hist(data_list, column_name, 'Tracker time update exect time', labels, 'time_upds_time_hist.png', rel_column)
plot_cdf(data_list, column_name, labels, 'tracker time update exect time', 'time_upds_time_cdf.png', rel_column)

column_name = 'overall_execution_times.clustering'
plot_timing_hist(data_list, column_name, 'Clustering exect time', labels, 'clustering_time_hist.png', rel_column)
plot_cdf(data_list, column_name, labels, 'clustering exect time', 'clustering_cdf.png', rel_column)

column_name = 'overall_execution_times.cluster_grouping'
plot_timing_hist(data_list, column_name, 'Cluster grouping exect time', labels, 'cluster_grouping_time_hist.png', rel_column)
plot_cdf(data_list, column_name, labels, 'cluster grouping time', 'cluster_grouping_time_cdf.png', rel_column)

column_name = 'overall_execution_times.initialize_tracks'
plot_timing_hist(data_list, column_name, 'Tracks init exect time', labels, 'tracks_init_time_hist.png', rel_column)
plot_cdf(data_list, column_name, labels, 'tracks init time', 'tracks_init_time_cdf.png', rel_column)

column_name = 'overall_execution_times.measurement_update_tracks'
plot_timing_hist(data_list, column_name, 'Msmt update exect time', labels, 'msmt_update_time_hist.png', rel_column)
plot_cdf(data_list, column_name, labels, 'msmt update time', 'msmt_update_cdf.png', rel_column)

data_list = []
data_list.append(base_data)
labels = ['2.6']

column_name = 'overall_execution_times.time_update_tracks'
plot_timing_hist(data_list, column_name, 'Tracker time update exect time', labels, 'time_upds_time_hist_2_6.png', rel_column)
plot_cdf(data_list, column_name, labels, 'tracker time update exect time', 'time_upds_time_cdf_2_6.png', rel_column)

column_name = 'overall_execution_times.clustering'
plot_timing_hist(data_list, column_name, 'Clustering exect time', labels, 'clustering_time_hist_2_6.png', rel_column)
plot_cdf(data_list, column_name, labels, 'clustering exect time', 'clustering_cdf_2_6.png', rel_column)

column_name = 'overall_execution_times.cluster_grouping'
plot_timing_hist(data_list, column_name, 'Cluster grouping exect time', labels, 'cluster_grouping_time_hist_2_6.png', rel_column)
plot_cdf(data_list, column_name, labels, 'cluster grouping time', 'cluster_grouping_time_cdf_2_6.png', rel_column)

column_name = 'overall_execution_times.initialize_tracks'
plot_timing_hist(data_list, column_name, 'Tracks init exect time', labels, 'tracks_init_time_hist_2_6.png', rel_column)
plot_cdf(data_list, column_name, labels, 'tracks init time', 'tracks_init_time_cdf_2_6.png', rel_column)

column_name = 'overall_execution_times.measurement_update_tracks'
plot_timing_hist(data_list, column_name, 'Msmt update exect time', labels, 'msmt_update_time_hist_2_6.png', rel_column)
plot_cdf(data_list, column_name, labels, 'msmt update time', 'msmt_update_cdf_2_6.png', rel_column)

data_list = []
data_list.append(sgu_data)
labels = ['2.7']

column_name = 'overall_execution_times.time_update_tracks'
plot_timing_hist(data_list, column_name, 'Tracker time update exect time', labels, 'time_upds_time_hist_2_7.png', rel_column)
plot_cdf(data_list, column_name, labels, 'tracker time update exect time', 'time_upds_time_cdf_2_7.png', rel_column)

column_name = 'overall_execution_times.clustering'
plot_timing_hist(data_list, column_name, 'Clustering exect time', labels, 'clustering_time_hist_2_7.png', rel_column)
plot_cdf(data_list, column_name, labels, 'clustering exect time', 'clustering_cdf_2_7.png', rel_column)

column_name = 'overall_execution_times.cluster_grouping'
plot_timing_hist(data_list, column_name, 'Cluster grouping exect time', labels, 'cluster_grouping_time_hist_2_7.png', rel_column)
plot_cdf(data_list, column_name, labels, 'cluster grouping time', 'cluster_grouping_time_cdf_2_7.png', rel_column)

column_name = 'overall_execution_times.initialize_tracks'
plot_timing_hist(data_list, column_name, 'Tracks init exect time', labels, 'tracks_init_time_hist_2_7.png', rel_column)
plot_cdf(data_list, column_name, labels, 'tracks init time', 'tracks_init_time_cdf_2_7.png', rel_column)

column_name = 'overall_execution_times.measurement_update_tracks'
plot_timing_hist(data_list, column_name, 'Msmt update exect time', labels, 'msmt_update_time_hist_2_7.png', rel_column)
plot_cdf(data_list, column_name, labels, 'msmt update time', 'msmt_update_cdf_2_7.png', rel_column)