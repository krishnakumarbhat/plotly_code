import subprocess
import glob
from tqdm import tqdm

from aspe.extractors import extract_f360_from_mudp_folder

if __name__ == '__main__':
    resim_exe_path = r"C:\wkspaces_git\F360Core\sw\output\Debug_Win32\resim_f360.exe"
    logs_dir = r'C:\logs\VTV_mf4_logs\A370\DS_07_cross_traffic_braking\SRR_DEBUG'

    suffix = '_dim_up_fix_b'
    for log_path in tqdm(glob.glob(logs_dir + r'\*.dvl')):
        command = f'{resim_exe_path} {log_path} -osuffix {suffix} -stream BMW -f360trkopt -sync_input -endopt'
        subprocess.call(command)

    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"

    mudp_dir = glob.glob(logs_dir + f'\\*{suffix}')[0]
    extr = extract_f360_from_mudp_folder(mudp_dir, mudp_stream_def_path=mudp_stream_def_path, raw_signals=True,
                                         detections=True, sensors=True, internal_objects=True, save_to_file=True, force_extract=True)