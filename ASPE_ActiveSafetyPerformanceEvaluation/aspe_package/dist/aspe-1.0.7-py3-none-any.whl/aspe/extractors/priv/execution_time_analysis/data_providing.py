from aspe.parsers.MudpParser.mudp_parser import MudpParser
from aspe.parsers.MudpParser.f360_defaults_configs import unknown_size_per_stream
import tqdm
import pandas as pd


def parse_and_get_medians(logs_path_list, stream_def_path):
    print('DATA PARSING STARTED')
    parser = MudpParser(streams_to_read=[7, 9], mudp_stream_def_path=stream_def_path, unknown_size_per_stream=unknown_size_per_stream)
    overall_times_aggregated = []
    itemized_times_aggregated = []
    for log in tqdm.tqdm(logs_path_list):
        parsed = parser.parse(log)
        overall_times = pd.DataFrame(parsed['parsed_data'][9]['overall_execution_times'])
        itemized_times = pd.DataFrame(parsed['parsed_data'][9]['itemized_execution_times'])
        overall_times = overall_times.melt(ignore_index=False).rename(columns={'variable': 'module', 'value': 'execution_time'})
        itemized_times = itemized_times.melt(ignore_index=False).rename(columns={'variable': 'module', 'value': 'execution_time'})

        overall_times['scan_index'] = overall_times.index
        itemized_times['scan_index'] = itemized_times.index

        overall_times_aggregated.append(overall_times)
        itemized_times_aggregated.append(itemized_times)

    median_overall_times = pd.concat(overall_times_aggregated).groupby(by=['module', 'scan_index']).median().reset_index()
    median_itemized_times = pd.concat(itemized_times_aggregated).groupby(by=['module', 'scan_index']).median().reset_index()

    core_timing = median_overall_times.loc[median_overall_times['module'].isin(['time_taken_core_and_udp_packing', 'time_taken_core_tracker']), :]
    median_itemized_times = median_itemized_times.append(core_timing).reset_index(drop=True)

    return median_overall_times, median_itemized_times
