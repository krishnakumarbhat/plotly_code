from aspe.providers.F360MudpRtRangeMdfDataProvider import F360MudpRtRangeMdfDataProvider
from aspe.utilities.MathFunctions import calc_velocity_in_position, calc_position_in_bounding_box
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Dict, List


def plot_host_signals_in_comparison_to_rt_range(
        mudp_paths: Dict[str, str],
        mudp_stream_def_path: str,
        signals_to_compare: List[str]):

    host_rear_axle_to_f_bumper = 3.7  # distance from ego vehicle rear axle to front bumper - need for CS transform
    host_length = 4.7
    host_width = 1.9
    cs_system = 'VCS'  # coordinate system in which evaluation will be performed
    rt_f360_dt = -0.05  # time delay between RtRange and F360 which must be compensated

    provider = F360MudpRtRangeMdfDataProvider(
        mudp_stream_defs_path=mudp_stream_def_path,
        host_rear_axle_to_front_bumper_dist=host_rear_axle_to_f_bumper,
        host_width=host_width,
        host_length=host_length,
        rt_hunter_target_shift=10,
        reference_time_shift=rt_f360_dt,
        coordinate_system=cs_system,
        save_to_file=True,
        force_extract=True,
        raw_signals=True
    )

    f, axes = plt.subplots(nrows=len(signals_to_compare), sharex=True, figsize=(12, 6))

    for alias, mudp_path in mudp_paths.items():
        est, ref = provider.get_single_log_data(mudp_path)
        host_ref = ref.host.signals

        new_pos_x = host_ref.position_x + (host_rear_axle_to_f_bumper - 1)  # 1 is distance from rear axle to rear seat (aprox)
        new_vel_x, new_vel_y = calc_velocity_in_position(host_ref.position_x, host_ref.position_y, host_ref.velocity_otg_x, host_ref.velocity_otg_y,
                                                         host_ref.yaw_rate, new_pos_x, host_ref.position_y)
        host_ref.velocity_otg_x = new_vel_x
        host_ref.velocity_otg_y = new_vel_y

        host = est.host.signals
        for ax, signal_name in zip(axes, signals_to_compare):
            ax.plot(host.loc[:, 'scan_index'].to_numpy(), host.loc[:, signal_name].to_numpy(), label=f'{alias} host')

    for ax, signal_name in zip(axes, signals_to_compare):
        ax.plot(host_ref.loc[:, 'scan_index'].to_numpy(), host_ref.loc[:, signal_name].to_numpy(), label=f'RtRange host')
        ax.grid()
        ax.set_title(signal_name)
        ax.legend()
    axes[-1].set_xlabel('scan index [-]')

    f.suptitle(Path(list(mudp_paths.values())[0]).name)
    f.tight_layout(rect=[0, 0.03, 1, 0.95])


if __name__ == '__main__':
    mudp_stream_def_path = r"C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"
    mudp_paths = {
        # alias: mudp_path form
        '': r"C:\logs\VTV_mf4_logs\A370\DS_07_cross_traffic_braking\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_07_40_30_R_SRR_DEBUG_WBATR91070LC63638_20200622_141942_deb_0001.mudp",
    }
    signals_to_compare = ['velocity_otg_x', 'acceleration_otg_x']
    plot_host_signals_in_comparison_to_rt_range(mudp_paths, mudp_stream_def_path, signals_to_compare)
