import glob
import subprocess
from tqdm import tqdm
from pathlib import Path

RESIM_PATH = r"C:\wkspaces_git\F360Core\sw\output\Debug_Win32\resim_f360.exe"


def resim_logs(input_logs, suffix):
    if isinstance(input_logs, str):
        logs_path = Path(input_logs)
        if logs_path.is_dir():
            log_list = [str(p) for p in logs_path.glob('*.dvl')]
        elif logs_path.is_file():
            log_list = [input_logs]
    elif isinstance(input_logs, list):
        log_list = input_logs

    for log_path in tqdm(log_list):
        command = resim_command(log_path, suffix)
        subprocess.call(command)


def resim_command(log_path, suffix):
    return f'{RESIM_PATH} {log_path} -osuffix {suffix} -stream BMW -f360trkopt -init_from_log -sync_input -endopt'


if __name__ == '__main__':
    suffix = '_2_36_0'
    log_list = r"C:\logs\SWA_tests_drives"
    resim_logs(log_list, suffix)

