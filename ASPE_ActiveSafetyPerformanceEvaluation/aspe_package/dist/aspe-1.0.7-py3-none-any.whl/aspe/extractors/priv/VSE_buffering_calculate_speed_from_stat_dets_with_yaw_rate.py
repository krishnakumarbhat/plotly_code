from aspe.extractors.API.mudp import extract_f360_from_mudp, extract_f360_from_mudp_folder, parse_mudp
import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import lstsq
import pandas as pd


if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,
    mudp_log_file_path = r"C:\logs\VTV_mf4_logs\A370\DS_19_host_oscillates\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_19_50_50_SRR_DEBUG_WBATR91070LC63638_20200617_191629_deb_0002.mudp"
    signal_to_plot = 'velocity_otg_y'
    speed_cor_factor = 1.0
    host_speed_scan_shift = 0

    extracted = extract_f360_from_mudp(mudp_log_file_path, mudp_stream_def_path=mudp_stream_def_path, raw_signals=True,
                                       detections=True, sensors=True, internal_objects=True, save_to_file=True,
                                       oal_objects=True)
    sensors = extracted.sensors.per_sensor
    dets = extracted.detections.signals

    sensor_bsa = sensors.loc[:, ['sensor_id', 'boresight_az_angle']].set_index('sensor_id', drop=True)
    dets = dets.join(sensor_bsa, on='sensor_id')
    dets['vcs_azimuth'] = dets.loc[:, 'azimuth'] + dets.loc[:, 'boresight_az_angle']

    stat_dets_mask = dets.loc[:, 'motion_status'] == 2
    stat_dets = dets.loc[stat_dets_mask, :]

    output = {
        'scan_index': [],
        'velocity_otg_x': [],
        'velocity_otg_y': [],
        'sensor_id': [],
        'sensor_pos_x': [],
        'sensor_pos_y': [],
    }
    for scan_index, single_scan_dets in stat_dets.groupby('scan_index'):
        for srnsor_id, signle_scan_single_sensor_dets in single_scan_dets.groupby('sensor_id'):
            range_rate = signle_scan_single_sensor_dets.loc[:, 'range_rate_dealiased'].to_numpy()
            vcs_azimuth = signle_scan_single_sensor_dets.loc[:, 'vcs_azimuth'].to_numpy()

            a_mat = np.vstack([np.cos(vcs_azimuth), np.sin(vcs_azimuth)]).T
            b_mat = range_rate

            x, res, rnk, s = lstsq(a=a_mat, b=b_mat)
            output['scan_index'].append(scan_index)
            vx, vy = -x[0], -x[1]
            output['velocity_otg_x'].append(vx)
            output['velocity_otg_y'].append(vy)
            output['sensor_id'].append(srnsor_id)
            output['sensor_pos_x'].append(sensors.set_index('sensor_id', drop=True).loc[srnsor_id, 'position_x'])
            output['sensor_pos_y'].append(sensors.set_index('sensor_id', drop=True).loc[srnsor_id, 'position_y'])

    host_vel_from_dets = pd.DataFrame(output)

    extracted.host.signals.loc[:, signal_to_plot] = speed_cor_factor*extracted.host.signals.loc[:, signal_to_plot]
    extracted.host.signals.loc[:, 'scan_index'] = extracted.host.signals.loc[:, 'scan_index'] + host_speed_scan_shift

    f, axes = plt.subplots(nrows=2, sharex=True)
    axes[0].plot(extracted.host.signals.loc[:, 'scan_index'], extracted.host.signals.loc[:, signal_to_plot], label='host stream')
    for sensor_id, sensor in host_vel_from_dets.groupby('sensor_id'):
        axes[0].plot(sensor.loc[:, 'scan_index'], sensor.loc[:, signal_to_plot], label=f'sensor {sensor_id}')

    for ax in axes:
        ax.grid()
        ax.legend()