from aspe.extractors.API.mdf import extract_f360_bmw_mid_from_mf4
from aspe.utilities.SupportingFunctions import load_from_pkl
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


log_dir = r"C:\logs\A390_endurance_run\BN_FASETH\20200818T124435_20200818T124445_000000_B244952_BN_FASETH.MF4"
extr = extract_f360_bmw_mid_from_mf4(log_dir, raw_signals=True, sw_version='A370', save_to_file=True)
dets = extr.detections.signals
dets = dets.set_index('scan_index')
sensor_id = np.unique(dets.sensor_id)
dets_by_sensors = []
for id in sensor_id:
    sub_df = dets.loc[dets.sensor_id == id, :]
    sub_df.timestamp.plot(marker='.', linestyle='')
    dets_by_sensors.append(sub_df)

