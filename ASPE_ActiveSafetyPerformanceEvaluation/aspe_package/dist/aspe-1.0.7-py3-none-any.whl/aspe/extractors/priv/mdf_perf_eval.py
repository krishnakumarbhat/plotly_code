from aspe.providers import F360MdfRTRangeDataProvider
from aspe.providers.support_functions import get_log_list_from_path
from aspe.evaluation.RadarObjectsEvaluation.PEMultiLogEvaluation import PEMultiLogEvaluation
from aspe.evaluation.RadarObjectsEvaluation.PEPipeline import PEPipeline
from aspe.evaluation.RadarObjectsEvaluation.PairsFeatures import PositionDeviationR2R, VelocityDeviationR2R, OrientationDeviation, SpeedDeviation
from aspe.utilities.SupportingFunctions import save_to_pkl

"""
Run this script as 'Run File in Console'
Example of evaluating performance when several logs should be evaluated.
This class is configured by data provider and PE Pipeline and use log list
Output is then saved to pickle and can be further proceeded 
"""

logs_dir = r'C:\logs\VTV_mf4_logs\A330\CircularFollow\BN_FASETH'
logger_path = 'C:\logs\VTV_mf4_logs\A330\CircularFollow'
sw_version = 'A330'  # A step
host_rear_axle_to_f_bumper = 3.7  # distance from ego vehicle rear axle to front bumper - need for CS transform
cs_system = 'VCS'  # coordinate system in which evaluation will be performed
rt_f360_dt = 0.27  # time delay between RtRange and F360 which must be compensated

mdf_data_provider = F360MdfRTRangeDataProvider(sw_version, host_rear_axle_to_f_bumper, cs_system, shift_offset=rt_f360_dt,
                                               save_to_file=True)

log_list = get_log_list_from_path(logs_dir, required_sub_strings=['TC3'], req_ext='.MF4', level=1)  # filter TestCaseX logs

features_list = [PositionDeviationR2R(), VelocityDeviationR2R(), OrientationDeviation(), SpeedDeviation()]
multi_log_eval = PEMultiLogEvaluation(single_log_pipeline=PEPipeline(pairs_features_list=features_list),
                                      data_provider=mdf_data_provider, logging_file_folder=logger_path)

pe_output = multi_log_eval.process_data(log_list)
save_to_pkl(pe_output, logs_dir + '\\pe_output.pickle')