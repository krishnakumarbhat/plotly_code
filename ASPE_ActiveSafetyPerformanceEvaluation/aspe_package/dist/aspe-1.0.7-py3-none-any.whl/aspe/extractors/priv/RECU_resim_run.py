from pathlib import Path
import json
import subprocess


def prepare_input_json_file(log_folder_path, output_dir):
    json_input_template = {"reprocessingInputFileStreams": [
        {"key": "BN_CALIFR",
         "files": []},
        {"key": "BN_FASETH",
         "files": []},
        {"key": "SRR_DEBUG",
         "files": []}]}

    log_folder_path = Path(log_folder_path)
    califr_dir = log_folder_path / 'BN_CALIFR'
    faseth_dir = log_folder_path / 'BN_FASETH'
    srr_debug_dir = log_folder_path / 'SRR_DEBUG'

    if not califr_dir.exists():
        raise AttributeError('BN_CALIFR folder does not exist')
    if not faseth_dir.exists():
        raise AttributeError('BN_FASETH folder does not exist')
    if not srr_debug_dir.exists():
        raise AttributeError('SRR_DEBUG folder does not exist')

    faseth_paths = faseth_dir.glob('*.MF4')
    for faseth_path in faseth_paths:
        califr_path = str(faseth_path).replace('BN_FASETH', 'BN_CALIFR').replace('fas', 'cal')
        debug_path = str(faseth_path).replace('BN_FASETH', 'SRR_DEBUG').replace('fas', 'deb')
        if Path(califr_path).exists() and Path(debug_path).exists():
            json_input_template["reprocessingInputFileStreams"][0]['files'].append(califr_path)
            json_input_template["reprocessingInputFileStreams"][1]['files'].append(str(faseth_path))
            json_input_template["reprocessingInputFileStreams"][2]['files'].append(debug_path)
        else:
            print(f'Missing califr or debug log file for {faseth_path.name}, log will not be included in input .json file')

    output_path = str(Path(output_dir) / "BMW_SRR5_Input.json")
    with open(output_path, 'w') as fp:
        json.dump(json_input_template, fp)
    return output_path


if __name__ == '__main__':
    temp_files_dir = r"C:\wkspaces\RECU_resim_temp_files"
    resim_exe_path = "C:\\wkspaces\\10032114_01_MY2021_BMW_SRR5_ECU\\RECU_SIL_Library\\CMake\\output\\x64\\Debug\\APT_SRR_RESIM.exe"
    config = r"C:\wkspaces\RECU_resim_temp_files\SRR5_customer_config_v2p5.xml"
    json_input_path = prepare_input_json_file(r"C:\logs\DEX_1260_dim_update_fix\DS_12_far", temp_files_dir)

    resim_output = r"C:\logs\DEX_1260_dim_update_fix\DS_12_far\resim_out"
    Path(resim_output).mkdir(exist_ok=True)

    command = f'{resim_exe_path} {config} {json_input_path} {resim_output}'
    subprocess.call(command)
