import glob
import os


directory = r'C:\logs\VTV_mf4_logs\A370\DS_01_target_overtaking\A430_ATS+6\BN_FASETH'
log_list = glob.glob(f'{directory}\\*.mgp')

renamed = [log.replace('.mgp', '_SRR_Master-mPAD.mgp') for log in log_list]
for old, new in zip(log_list, renamed):
    os.rename(old, new)