from aspe.evaluation.API.resim import f360_resim_comparision, generate_resim_comparison_report

if __name__=='__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,
    log_list = [
        r"C:\logs\refactoring_verification\PSA\PSA_20180613_152933_003.dvl",
        r"C:\logs\refactoring_verification\PSA\PSA_20180613_152933_006.dvl",
        r"C:\logs\refactoring_verification\PSA\PSA_20180613_152933_010.dvl",
    ]
    resim_extension_before = 'rRf360t4300309v205p50_DFT_999_D_base'
    resim_extension_after = 'rRf360t4300309v205p50_DFT_999_D_ef2f'

    results = f360_resim_comparision(log_list, resim_extension_before, resim_extension_after,
                                     mudp_stream_def_path = mudp_stream_def_path,
                                     streams_to_compare={6},
                                     compare_internal_objects=False, optimize_memory_usage=True)

    jira_ticket_signature = 'DFT_999'
    generate_resim_comparison_report(subtitle='jira_ticket_signature',
                                     resim_extension_before=resim_extension_before,
                                     resim_extension_after=resim_extension_after,
                                     commit_id_before='a',
                                     commit_id_after='b',
                                     log_list=log_list,
                                     results=results,
                                     comments='ddd',
                                     output_path=r'C:\logs\refactoring_verification\ASPE_refactoring_verification' + f'{jira_ticket_signature}.pdf')
