import cProfile
from aspe.extractors import parse_mudp
from aspe.gui.AspeGuiRun import run_aspe_gui
import cProfile, pstats
from io import StringIO

def foo():
    #log_path = r"C:\logs\pandora\1k_subset\BN_FASETH\BMW-SRR5_ENDURANCE_WBAUZ35090NE42604_20200727_091843_fas_0045.MF4"
    #extract_f360_bmw_mid_from_mf4(log_path, raw_signals=True, sw_version='A370', save_to_file=True, force_extract=True, force_parse=True)
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,

    mudp_log_file_path = r"C:\logs\liberal_init_eng_drop\vigem\SRR_DEBUG\20201205T130111_20201205T130131_541618_H019172_SRR_DEBUG.mudp"
    parsed = parse_mudp(mudp_log_file_path, mudp_stream_def_path, streams_to_parse=(3,4,5,6,7,10))
    return parsed

pr = cProfile.Profile()
pr.enable()
run_aspe_gui()
pr.disable()
s = StringIO()
sortby = 'cumulative'
ps = pstats.Stats(pr, stream=s).sort_stats(sortby)
ps.print_stats()
print(s.getvalue())