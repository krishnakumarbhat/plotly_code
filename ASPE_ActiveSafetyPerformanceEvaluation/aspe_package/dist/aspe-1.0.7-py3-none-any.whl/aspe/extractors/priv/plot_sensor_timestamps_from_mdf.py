from aspe.extractors.API.mdf import extract_f360_bmw_mid_from_mf4
import matplotlib.pyplot as plt
import numpy as np


def get_sensor_timestamps(extracted, sensor_index: int):
    obj_header_raw = extracted.objects_header.raw_signals
    ts_seconds = obj_header_raw[f'timestamp_detections_{sensor_index}_seconds_value'].to_numpy()
    ts_nanosec = obj_header_raw[f'timestamp_detections_{sensor_index}_fractional_seconds_value'].to_numpy()
    timestmap = ts_seconds + ts_nanosec * 1e-9
    return timestmap

log_path = r"C:\logs\A390_endurance_run\BN_FASETH\20200914T092521_20200914T092531_000000_BP41315_BN_FASETH.MF4"
extr = extract_f360_bmw_mid_from_mf4(log_path, raw_signals=True, sw_version='A410', save_to_file=True)
n_dets = extr.detections_header.raw_signals.loc[:, ['counter', 'number_of_detections']]
n_dets_by_scan = n_dets.groupby(by='counter').sum()

sensor_timestamps = []
fig, ax = plt.subplots(nrows=3, sharex=True)
for sensor_idx in range(0, 4):
    sensor_ts = get_sensor_timestamps(extr, sensor_idx)
    ax[0].plot(sensor_ts, label=f'sensor {sensor_idx + 1}')
    ax[1].plot(np.diff(sensor_ts), '.', label=f'sensor {sensor_idx + 1}')
ax[2].plot(n_dets_by_scan['number_of_detections'].to_numpy())

ax[0].set_title('Sensor timestamps')
ax[0].set_ylabel('time [s]')
ax[1].set_title('Sensor timestamps diff')
ax[1].set_ylabel('time [s]')
ax[1].set_ylim([-0.01, 0.2])
ax[2].set_title('Number of detections - 4 sensors sum')
ax[2].set_ylabel('count [-]')

ax[2].set_xlabel('time instance [-]')

for a in ax:
    a.legend()
    a.grid()

#ts_diff = np.append(np.diff(sensor_ts), [0])
#f2, ax2 = plt.subplots()
#ax2.plot(ts_diff, n_dets_by_scan.number_of_detections, '.')
#ax2.grid()
#ax2.set_xlabel('timestamp diff [s]')
#ax2.set_ylabel('number of detections [-]')
