"""
http://jiraprod1.delphiauto.net:8080/secure/RapidBoard.jspa?rapidView=5780&projectKey=DFT&view=detail&selectedIssue=DFT-353
Write simple extractor which reads .mat files, takie RtRange data structures and convert it to ASPE extracted data format.
Each RtRange signal from .mat is an array with 2 columns - 1st is vigem ts and 2nd is signal values. Reading it within Python should be done without any problems.
Fulfill just basic interface needed for position/velocity evaluation.
"""
from scipy.io import loadmat
from typing import Dict
import pandas as pd
import numpy as np


translate_dict = {
    'Range1Forward__Range1PosForward': 'position_x',
    'Range1Lateral__Range1PosLateral': 'position_y',
    'Range1Forward__Range1TimeToCollisionForward': '',
    'Range1Forward__Range1VelForward': 'rel_velocity_x',
    'Range1Lateral__Range1VelLateral': 'rel_velocity_y',
    'Range1Lateral__Range1TimeToCollisionLateral': '',
    'Range1Local__Range1LocalDeltaX': '',
    'Range1Local__Range1LocalDeltaY': '',
    'Range1TargetPosLocal__Range1TargetPosLocalX': '',
    'Range1TargetPosLocal__Range1TargetPosLocalY': ''
}

def transform_dict_of_arrays_to_df(dict_in: dict) -> tuple:
    data_lens = [v.shape[0] for k, v in dict_in.items()]
    max_len = max(data_lens)

    values_df = pd.DataFrame(index=np.arange(max_len), columns=list(dict_in.keys()))
    timestamp_df = pd.DataFrame(index=np.arange(max_len), columns=list(dict_in.keys()))

    for key, value in dict_in.items():
        timestamp_df.loc[:value.shape[0]-1, key] = value[:, 0]
        values_df.loc[:value.shape[0]-1, key] = value[:, 1]
    return timestamp_df, values_df


def interpolate_values(dict_in, x):
    dict_out = {}
    for key, value in dict_in.items():
        xp = value[:, 0]
        fp = value[:, 1]
        y = np.interp(x, xp, fp)
        dict_out[key] = y
    return dict_out


if __name__ == '__main__':
    mat_path = r"C:\logs\BYK-589_DEX-530\workspace.mat"
    mat_data = loadmat(mat_path)
    data_keys = list(mat_data.keys())

    range_1_data = {key: value for key, value in mat_data.items() if 'Range1' in key and 'Hunter' not in key and 'Status' not in key}
    hunter_data = {key: value for key, value in mat_data.items() if 'Hunter' in key}
    target_1_data = {key: value for key, value in mat_data.items() if 'Target1' in key}

    ts = range_1_data['Range1Forward__Range1PosForward'][:, 0]
    range_1_interp = interpolate_values(range_1_data, ts)
    range_1_df = pd.DataFrame(range_1_interp)
    range_1_df['timestamp'] = ts
    #range_1_ts_df, range_1_values_df = transform_dict_of_arrays_to_df(range_1_data)