from aspe.extractors.API.mudp import extract_f360_from_mudp, extract_f360_from_mudp_folder
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from itertools import product
from sklearn.neighbors import KernelDensity
from matplotlib.gridspec import GridSpec
from matplotlib.backends.backend_pdf import PdfPages
from tqdm import tqdm

KDE_POINTS_NUM = 360


def get_assoc_obj_detections(extracted, unique_obj_id: int):
    object_track = extracted.internal_objects.signals.groupby(by='unique_id').get_group(unique_obj_id)
    object_track_raw = extracted.internal_objects.raw_signals.loc[object_track.index, :]

    object_track.loc[:, 'probability_undet'] = object_track_raw.loc[:, 'probability_undet']
    object_track.loc[:, 'probability_bicycle'] = object_track_raw.loc[:, 'probability_bicycle']

    min_scan_idx, max_scan_idx = object_track.scan_index.min(), object_track.scan_index.max()
    trk_id = object_track.id.iloc[0]

    dets = extracted.detections.signals
    dets_scan_mask = (min_scan_idx <= dets.scan_index) & (dets.scan_index <= max_scan_idx)
    dets_obj_id_mask = dets.assigned_obj_id == trk_id

    object_dets = dets.loc[dets_scan_mask & dets_obj_id_mask, :]
    return object_dets, object_track


def get_range_between_dets(det_A, det_B):
    diff_x = det_B.position_x - det_A.position_x
    diff_y = det_B.position_y - det_A.position_y
    return np.sqrt(diff_x**2 + diff_y**2)


def get_line_slope_for_2_dets(det_A, det_B):
    diff_x = det_B.position_x - det_A.position_x
    diff_y = det_B.position_y - det_A.position_y
    return np.arctan2(diff_y, diff_x)


def wrap_angle_to_90(angle):
    return angle % (np.pi/2)


def get_kde_estimation(line_slopes, bandwidth):
    slopes = np.array(line_slopes).reshape(-1, 1)
    kde = KernelDensity(kernel='linear', bandwidth=bandwidth).fit(slopes)
    X_arr = np.linspace(0, np.pi/2, 100)
    return X_arr.reshape(-1), kde.score_samples(X_arr.reshape(-1, 1))


def get_pairs_indexes(dets_in_scan):
    pairs_indexes = np.array([sorted(p) for p in product(range(len(dets_in_scan)), range(len(dets_in_scan)))])
    pairs_indexes = np.unique(pairs_indexes, axis=0)
    return pairs_indexes


def wrap_kde_index(index_in, kde_len):
    if index_in < 0:
        index_out = kde_len + index_in
    elif kde_len <= index_in:
        index_out = index_in - kde_len
    else:
        index_out = index_in
    return index_out


def my_kde(line_slopes, bandwidth):
    kde_x_array = np.linspace(0, np.pi/2, KDE_POINTS_NUM)
    kde_y_array = np.zeros(KDE_POINTS_NUM)

    index_per_radian = KDE_POINTS_NUM / (np.pi/2)
    kde_len_half = int(bandwidth * index_per_radian)

    for slope in line_slopes:
        slope_angle_index = int(slope * index_per_radian)
        idx_min, idx_max = slope_angle_index - kde_len_half, slope_angle_index + kde_len_half
        for kde_index in range(idx_min, idx_max + 1):
            kde_index = wrap_kde_index(kde_index, KDE_POINTS_NUM)
            kde_angle = kde_x_array[kde_index]
            kde_val = max(1 - abs(slope-kde_angle) / bandwidth, 0.0)
            kde_y_array[kde_index] = kde_y_array[kde_index] + kde_val
    return kde_x_array, kde_y_array


def get_pseudo_heading_in_scan(dets_in_scan):
    pairs_indexes = get_pairs_indexes(dets_in_scan)
    line_slopes = []
    for det_A_index, det_B_index in pairs_indexes:
        det_A, det_B = dets_in_scan.iloc[det_A_index, :], dets_in_scan.iloc[det_B_index, :]
        if get_range_between_dets(det_A, det_B) > 0.5:
            line_slope = get_line_slope_for_2_dets(det_A, det_B)
            line_slopes.append(line_slope)
    line_slopes = [wrap_angle_to_90(s) for s in line_slopes]
    angles, kde_estimation = get_kde_estimation(line_slopes, bandwidth=np.deg2rad(10))
    angles, kde_estimation = my_kde(line_slopes, bandwidth=np.deg2rad(10))

    pseudo_heading = angles[kde_estimation.argmax()]
    return pseudo_heading, angles, kde_estimation, line_slopes, kde_estimation.max()


def rotate_by_angle(pos_x_in, pos_y_in, angle):
    pos_x_rotated = np.cos(angle) * pos_x_in + np.sin(angle) * pos_y_in
    pos_y_rotated = -np.sin(angle) * pos_x_in + np.cos(angle) * pos_y_in
    return pos_x_rotated, pos_y_rotated


def plot_scan_index_results(scan_index, dets_pos, slopes, kde):
    fig = plt.figure(constrained_layout=True)
    gs = GridSpec(2, 2, figure=fig)
    ax1 = fig.add_subplot(gs[:, 0])
    ax2 = fig.add_subplot(gs[0, 1])
    ax3 = fig.add_subplot(gs[1, 1])

    angles = np.linspace(0, 90, KDE_POINTS_NUM)
    ax1.plot(dets_pos[scan_index][1], dets_pos[scan_index][0], '.')
    ax1.set_aspect(1)
    ax2.plot(angles, kde[scan_index])
    ax3.plot(slopes[scan_index], -0.1*np.ones(len(slopes[scan_index])), '+')
    ax3.hist(slopes[scan_index], density=True)


def analyze_unique_obj_within_log(mudp_stream_def_path, mudp_log_path, unique_obj_id):
    extracted = extract_f360_from_mudp(mudp_log_path, mudp_stream_def_path=mudp_stream_def_path,
                                       internal_objects=True,
                                       detections=True,
                                       raw_signals=True,
                                       force_extract=True,
                                       save_to_file=True)
    out = {
        'scan_index': [],
        'pseudo_heading': [],
        'kde_score': [],
    }
    kdes = {}
    slopes = {}
    dets_pos = {}

    object_dets, object_track = get_assoc_obj_detections(extracted, unique_obj_id)
    for scan_index, dets_in_scan in object_dets.groupby(by='scan_index'):
        if len(dets_in_scan) > 10:
            pseudo_heading, angles, kde_estimation, line_slopes, max_score = get_pseudo_heading_in_scan(dets_in_scan)
        else:
            pseudo_heading, angles, kde_estimation, line_slopes, max_score = np.nan, np.nan, np.nan, np.nan, np.nan

        kdes[scan_index] = kde_estimation
        slopes[scan_index] = line_slopes
        dets_pos[scan_index] = (dets_in_scan.position_x.to_numpy(), dets_in_scan.position_y.to_numpy())

        out['scan_index'].append(scan_index)
        out['pseudo_heading'].append(pseudo_heading)
        out['kde_score'].append(max_score)

    out_df = pd.DataFrame(out)
    object_track = object_track.join(out_df.set_index('scan_index'), on='scan_index')
    return object_track, kdes, slopes, dets_pos


def plot_objects_results(object_track, title):
    object_track.set_index('scan_index', inplace=True)
    f, axes = plt.subplots(nrows=3, sharex=True, figsize=(12, 9))
    x = object_track.index.to_numpy()
    axes[0].plot(x, np.rad2deg(object_track.bounding_box_orientation), label='heading_from_log')
    axes[0].plot(x, np.rad2deg(object_track.pseudo_heading), 'o', label='psuedo heading - gbo',)
    axes[0].axhline(y=0.0, label='expected', linestyle="--")
    axes[0].axhline(y=90.0, label='90 deg', linestyle="--")

    axes[1].plot(object_track.n_dets, label='ndets')
    object_track.loc[:, 'kde_score_per_n_dets'] = object_track.kde_score / object_track.n_dets
    axes[2].plot(object_track.kde_score_per_n_dets, '.', label='kde max score/n_dets')

    object_track.pseudo_heading = np.rad2deg(object_track.pseudo_heading)
    f.tight_layout(rect=[0, 0.03, 1, 0.95])
    f.suptitle(title)
    for ax in axes:
        ax.grid()
        ax.legend()
    return f


if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,

    logs = [
        (r"C:\logs\COT_2_36_0\TPC2p36_Special1\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario1_10kph_3_105733_001.mudp", 91),
        (r"C:\logs\COT_2_36_0\TPC2p36_Special1\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario1_30kph_1_111133_001.mudp", 820),
        (r"C:\logs\COT_2_36_0\TPC2p36_Special1\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario1_50kph_1_112027_001.mudp", 264),
        (r"C:\logs\COT_2_36_0\TPC2p36_Special1\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario1_50kph_2_112338_001.mudp", 817),
        (r"C:\logs\COT_2_36_0\TPC2p36_Special3\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario3_10kph_1_144659_001.mudp", 268),
        (r"C:\logs\COT_2_36_0\TPC2p36_Special3\F360_HGR770_20210316_TrackerPC_02p36_00_8226c7101_SpScenario3_2kph_1_150051_001.mudp", 387),
        (r"C:/logs/BYK_542_events_trucks_lateraly_close/20210309_G07_mid_A480_ATS1_Susan_Luu_BYK_542/Vigem/20210309T163243_543078_SRR_DEBUG/20210309T163252_20210309T163312_543078_LB36408_SRR_DEBUG.mudp", 333),
    ]

    pp = PdfPages('gbo_results.pdf')
    for mudp_log_file_path, unique_obj_id in tqdm(logs):
        object_track, kdes, slopes, dets_pos = analyze_unique_obj_within_log(mudp_stream_def_path, mudp_log_file_path, unique_obj_id)
        fig = plot_objects_results(object_track, f'{mudp_log_file_path}, \n unique_obj_id: {unique_obj_id}')
        pp.savefig(fig)
        plt.close(fig)
    pp.close()
    #plot_scan_index_results(36489, dets_pos, slopes, kdes)