from mdf_parser_pkg.mdf_parser import parse_file
from srr5_dev_tools.mgp_module import load as load_mgp

if __name__ == '__main__':
    f_load_from_mgp = True  # choose whether you want to parse mf4 file directly or load parsed data from .mgp file

    if f_load_from_mgp:
        data_path = r"C:\logs\mdf_with_rt_range\parse_result\A350_ECU3_12_4_SENS_3_12_5_SCW_DS1_V30_D1M_L_SRR_REFERENCE_WBATR91070LC63638_20200309_165033_ref_0012_RT_Range.mgp"
        parsed_data = load_mgp(data_path)
    else:
        data_path = r"\\10.224.186.68\AD-Shared\ASPE\Logs\F360\mf4_example_files\20200128T155757_20200128T155817_543078_LB36408_BN_FASETH.MF4"
        parsed_data = parse_file(data_path, 'mid')