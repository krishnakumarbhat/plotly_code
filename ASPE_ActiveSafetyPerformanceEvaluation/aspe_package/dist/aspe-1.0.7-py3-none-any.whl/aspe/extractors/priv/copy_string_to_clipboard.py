from pathlib import Path
import pyperclip

log_dir = Path(r"C:\logs\COT_2_36_0")
logs = [str(p) for p in log_dir.rglob('*.mudp')]
log_str = '\n'.join(logs)
pyperclip.copy(log_str)