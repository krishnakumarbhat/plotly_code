import os
import pickle
import pandas as pd
from aspe.parsers.MudpParser.mudp_parser import MudpHandler
path = r'C:\logs\relevant_logs\logs_saturated\rRf360t3060304v202r1_baseline'
mudp_parser_conf_path = 'C:\wkspaces\ASPE0000_00_Common\.private\configs\ParsersConfig\mudp_data_parser_config.json'
out_file_name = 'timing_info.pickle'

data_list = []
log_idx = 0

for file_names in os.listdir(path):
    _, file_extension = os.path.splitext(file_names)
    if file_extension == '.mudp':
        a = MudpHandler(path + '\\' + file_names, mudp_parser_conf_path)
        a.parse()
        data = a.output_data[9]
        data['log_idx'] = log_idx
        data_list.append(data)
        log_idx += 0

out_df = pd.concat(data_list)
out_file_name = 'timing_info.pickle'
with open(os.path.join(path, out_file_name), 'wb') as handle:
    pickle.dump(out_df)


