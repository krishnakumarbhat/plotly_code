import subprocess
import glob
import os
import tqdm

CONVERTER_PATH = r'C:\wkspaces_git\AGFS_Tools\mdf2dvl_mudp\output\Debug_x64\mdf2dvl_mudp.exe'

if __name__ == '__main__':
    logs_list = glob.glob(r"C:\logs\SWA_tests_drives\part_3\\*.MF4")
    for log_path in tqdm.tqdm(logs_list):
        dvl_path = log_path.replace('.MF4', '.dvl')
        if not os.path.exists(dvl_path):
            print(f'\nProcessing log: {log_path}')
            command = f'{CONVERTER_PATH} {log_path}'
            subprocess.call(command)
        else:
            print(f'\nSkipping conversion. DVL log: {dvl_path} already exists.  ... ')

