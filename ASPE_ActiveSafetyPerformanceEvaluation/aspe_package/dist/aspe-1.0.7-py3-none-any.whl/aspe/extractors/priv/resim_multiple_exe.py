import subprocess
from multiprocessing import Process, Value
from time import time
from pathlib import Path
from typing import Union, List, Optional


def split_list_to_chunks(input_list, n_chunks):
    for i in range(0, n_chunks):
        yield input_list[i::n_chunks]


def find_logs_in_dir(dir_path, log_ext):
    if Path(dir_path).is_dir():
        log_paths = [str(p) for p in Path(dir_path).glob(f'*{log_ext}')]
    else:
        raise AttributeError('Given string is not directory path')
    return log_paths


class F360CoreResimRunner:
    def __init__(self, resim_exe_path: str,
                 osuffix: str = '',
                 ini_file: Optional[str] = None,
                 init_from_log: bool = True,
                 sync_input: bool = True,
                 bmw_stream: bool = False,
                 xtrk_log: bool = False):
        """
        Class responsible for running F360 Core Resim which takes as input dvl/mudp file and produces dvl/mudp/xtrk type
        output. Class handles running N parallel resims in same tame, which improves time performance.

        :param resim_exe_path: path to resim executable file
        :param osuffix: suffix which will be added to resim extension
        :param ini_file: optional path to ini file
        :param init_from_log: initialize tracker state from logged state
        :param sync_input: if True -sync_input argument added
        :param bmw_stream: if True -stream BMW argument added
        :param xtrk_log: if True .xtrk files will be generated
        """
        self.resim_exe_path = resim_exe_path
        self.osuffix = osuffix
        self.ini_file = ini_file
        self.init_from_log = init_from_log
        self.sync_input = sync_input
        self.bmw_stream = bmw_stream
        self.xtrk_log = xtrk_log

        self.resim_args = None
        self.total_logs_count = None
        self.counter = None

    def resimulate(self, log_paths: Union[str, List[str]], n_parallel_resims: int = 1):
        """
        Run resim for given log files.
        :param log_paths: can be list of paths to logs or path to logs directory
        :param n_parallel_resims: how many resim executables in parallel will be run. WARNING this can heavily increase
        CPU usage, suggested value - 3
        :return:
        """
        if not isinstance(log_paths, list):
            log_paths = find_logs_in_dir(log_paths, '.dvl')

        self._build_resim_args()
        self._reset_counter(len(log_paths))

        workers = []
        t_start = time()
        for log_paths_chunk in split_list_to_chunks(log_paths, n_chunks=n_parallel_resims):
            p = Process(target=self._resim_log_list, args=(log_paths_chunk, ))
            workers.append(p)
            p.start()

        for p in workers:
            p.join()

        t_end = time()
        print(f'Finished. Total time {t_end - t_start}')

    def _resim_log_list(self, logs_list):
        for log_path in logs_list:
            command = f'{self.resim_exe_path} {log_path} {self.resim_args}'
            subprocess.call(command)

            self.counter.value += 1
            print(f'Processed logs {self.counter.value} / {self.total_logs_count}')

    def _build_resim_args(self):
        self.resim_args = f'-osuffix {self.osuffix} '
        if self.bmw_stream:
            self.resim_args += '-stream BMW '

        f360trkopts = ''
        if self.ini_file is not None:
            f360trkopts += f'-ini {self.ini_file} '

        if self.init_from_log:
            f360trkopts += '-init_from_log '

        if self.sync_input:
            f360trkopts += '-sync_input '

        if self.xtrk_log:
            f360trkopts += '-xtrklog '
        self.resim_args += f' -f360trkopt {f360trkopts} -endopt'

    def _reset_counter(self, logs_count):
        self.total_logs_count = logs_count
        self.counter = Value('i', 0)  # must be shared by different processes


if __name__ == '__main__':
    resim_exe_path = r"C:\wkspaces_git\F360Core\sw\output\Debug_Win32\resim_f360.exe"
    logs_dir = r"C:\logs\liberal_init_eng_drop_testing_07122020\delta_60_combined\rRf360t4270309v205p50_parallel_resim_test"
    n_resims = 1
    suffix = '_resim_runner_test'

    resim_runner = F360CoreResimRunner(resim_exe_path, suffix, sync_input=True)
    resim_runner.resimulate(logs_dir, n_parallel_resims=n_resims)
