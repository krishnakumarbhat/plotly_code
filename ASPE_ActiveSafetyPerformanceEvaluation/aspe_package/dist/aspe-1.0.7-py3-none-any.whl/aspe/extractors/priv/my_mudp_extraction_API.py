from aspe.extractors.API.mudp import extract_f360_from_mudp, extract_f360_from_mudp_folder

if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,
    mudp_log_file_path = r"C:/logs/SWA_tests_drives/rRf360t4310309v205p50_2_36_0/20210421T120510_20210421T120530_541610_H019173_SRR_DEBUG_rRf360t4310309v205p50_2_36_0.mudp"
    mudp_dir = r"C:\Users\zj2hns\Downloads\Special_Requests\TPC2p36_Special1"

    extracted = extract_f360_from_mudp(mudp_log_file_path, mudp_stream_def_path=mudp_stream_def_path,
                                       streams_to_parse=(3,4,5,6, 7),
                                              internal_objects=True,
                                              detections=True,
                                              sensors=True,
                                              raw_signals=True,
                                              force_extract=True,
                                              save_to_file=True)

