from aspe.extractors.Interfaces.ExtractedData import ExtractedData
from aspe.extractors.ReferenceExtractor.RtRange.DataSets.RtObjects import RtObjects
from aspe.utilities.MathFunctions import calc_position_in_bounding_box, calc_velocity_in_position
from aspe.utilities.SupportingFunctions import load_from_pkl, save_to_pkl
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

from aspe.utilities.synchronize_rt_2_tracker import synchronize_rt_2_tracker
from aspe.utilities.transform_rt_data_mat2data_frame import transform_rt_range_data_mat2data_frame

# DEX-690
PLOT_SAVE_PATH = r'C:\logs\BYK-627_DEX-690\analysis_DFT_363'
RT_DATA_PATH = r"C:\logs\BYK-627_DEX-690\rt_range_data.mat"


def get_ref_point_pos_for_rt_range(rt_data, old_ref_x, old_ref_y, new_ref_x, new_ref_y):
    in_pos_x, in_pos_y = rt_data.position_x.to_numpy(), rt_data.position_y.to_numpy()

    new_x, new_y = calc_position_in_bounding_box(in_pos_x, in_pos_y,
                                                 rt_data.bounding_box_dimensions_x.to_numpy(), rt_data.bounding_box_dimensions_y.to_numpy(),
                                                 rt_data.bounding_box_orientation.to_numpy(),
                                                 np.array([old_ref_x] * rt_data.shape[0]), np.array([old_ref_y] * rt_data.shape[0]),
                                                 np.array([new_ref_x] * rt_data.shape[0]), np.array([new_ref_y] * rt_data.shape[0]))
    new_vel_x, new_vel_y = calc_velocity_in_position(in_pos_x, in_pos_y, rt_data.velocity_otg_x.to_numpy(),
                                                     rt_data.velocity_otg_y.to_numpy(), rt_data.yaw_rate.to_numpy(),
                                                     new_x, new_y)
    rt_data['position_x'] = new_x
    rt_data['position_y'] = new_y
    rt_data['velocity_otg_x'] = new_vel_x
    rt_data['velocity_otg_y'] = new_vel_y
    rt_data['speed'] = np.sqrt(np.square(new_vel_x) + np.square(new_vel_y))


def get_ref_point_pos_for_target(target, new_ref_x, new_ref_y):
    in_pos_x, in_pos_y = target.position_x.to_numpy(), target.position_y.to_numpy()
    out_pos_x, out_pos_y = np.array([new_ref_x] * target.shape[0]), np.array([new_ref_y] * target.shape[0])

    new_x, new_y = calc_position_in_bounding_box(in_pos_x, in_pos_y,
                                                 target.bounding_box_dimensions_x.to_numpy(), target.bounding_box_dimensions_y.to_numpy(),
                                                 target.bounding_box_orientation.to_numpy(),
                                                 target.bounding_box_refpoint_long_offset_ratio.to_numpy(), target.bounding_box_refpoint_lat_offset_ratio.to_numpy(),
                                                 out_pos_x, out_pos_y)
    target.bounding_box_refpoint_long_offset_ratio = new_ref_x
    target.bounding_box_refpoint_lat_offset_ratio = new_ref_y
    new_vel_x, new_vel_y = calc_velocity_in_position(in_pos_x, in_pos_y, target.velocity_otg_x.to_numpy(),
                                                     target.velocity_otg_y.to_numpy(), target.yaw_rate.to_numpy(),
                                                     new_x, new_y)
    target['position_x'] = new_x
    target['position_y'] = new_y
    target['velocity_otg_x'] = new_vel_x
    target['velocity_otg_y'] = new_vel_y

def plot_rt_traces(rt_data):
    host_x = rt_data.Range1HunterPosLocal__Range1HunterPosLocalX
    host_y = rt_data.Range1HunterPosLocal__Range1HunterPosLocalY
    target_x = rt_data.Range1TargetPosLocal__Range1TargetPosLocalX
    target_y = rt_data.Range1TargetPosLocal__Range1TargetPosLocalY

    f, axes = plt.subplots(figsize=(10, 10))
    axes.plot(host_y, host_x, label='host trace')
    axes.plot(target_y, target_x, label='target trace')

    axes.grid()
    axes.set_xlabel('position y [m]')
    axes.set_ylabel('position x [m]')

    axes.set_title('Host/Target traces')
    axes.axis('equal')
    axes.legend()
    f.tight_layout()
    f.savefig(f'{PLOT_SAVE_PATH}\\rt_traces.png')
    plt.close(f)


def plot_signal_compare(df_list, label_list, plot_title, signal_to_compare, unit, x_label):
    fig, axes = plt.subplots(figsize=(12, 6))
    for df, label in zip(df_list, label_list):
        x = df.index.to_numpy()
        y = df.loc[:, signal_to_compare]
        axes.plot(x, y, label=label)
    axes.set_title(plot_title)
    axes.set_xlabel(x_label)
    axes.set_ylabel(f'{signal_to_compare} {unit}')
    axes.legend()
    axes.grid()
    file_title = plot_title.lower().replace(' ', '_')
    fig.savefig(f'{PLOT_SAVE_PATH}\\{file_title}')
    plt.close(fig)


def load_and_concat_data(pickle_paths_list, ids):
    targets = []
    dets = []
    dets_all = []
    for id, pickle_path in zip(ids, pickle_paths_list):
        extracted = load_from_pkl(pickle_path)
        obj_signals = extracted.objects.signals.join(extracted.objects.raw_signals, rsuffix='_raw')
        obj_signals = obj_signals.loc[obj_signals.tracker_id == id, :]
        det_signals = extracted.detections.signals.join(extracted.detections.raw_signals, rsuffix='_raw')
        dets_all.append(det_signals)
        det_signals = det_signals.loc[det_signals.assigned_obj_id == id, :]
        dets.append(det_signals)
        targets.append(obj_signals)

    out_targets = pd.concat(targets)
    out_targets.set_index('timestamp', inplace=True, drop=False)
    out_targets.sort_index(inplace=True)
    out_targets['bounding_box_orientation_deg'] = np.rad2deg(out_targets['bounding_box_orientation'])
    assoc_dets = pd.concat(dets)
    assoc_dets.set_index('timestamp', inplace=True, drop=False)
    assoc_dets.sort_index(inplace=True)
    dets_all = pd.concat(dets_all).set_index('timestamp', drop=False)
    dets_all.sort_index(inplace=True)
    sensors = extracted.sensors.per_sensor
    return out_targets, assoc_dets, sensors, dets_all


def put_nans_in_scan_index_jumps(dataframe, time_jump = 0.5):
    scan_index_jumps =dataframe.index[np.where(np.diff(dataframe.index) > time_jump)[0]]
    for jump_ts in scan_index_jumps:
        dataframe.loc[jump_ts + 0.05, :] = np.nan
    dataframe.sort_index(inplace=True)


logs_pickle_paths_2_14 =[
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T101426_20200131T101446_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T101446_20200131T101506_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T101506_20200131T101526_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T101526_20200131T101546_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T101546_20200131T101606_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T101606_20200131T101626_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T101626_20200131T101629_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle"
]
logs_pickle_paths_2_20 = [
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T101426_20200131T101446_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T101446_20200131T101506_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T101506_20200131T101526_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T101526_20200131T101546_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T101546_20200131T101606_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T101606_20200131T101626_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T101626_20200131T101629_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle"
]
logs_pickle_paths_2_20_fix = [
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20_dim_up_fix\20200131T101506_20200131T101526_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_dim_up_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20_dim_up_fix\20200131T101526_20200131T101546_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_dim_up_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20_dim_up_fix\20200131T101546_20200131T101606_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_dim_up_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20_dim_up_fix\20200131T101606_20200131T101626_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_dim_up_fix_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-627_DEX-690\SRR_DEBUG\rRf360t4150309v205p50_core_2_20_dim_up_fix\20200131T101626_20200131T101629_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_dim_up_fix_f360_mudp_extracted.pickle"
]

obj_id_2_14 = [101] * 7
obj_id_2_20 = [101] * 7
obj_id_2_20_fix = [101] * 5

out_targets_2_14, *_ = load_and_concat_data(logs_pickle_paths_2_14, obj_id_2_14)
out_targets_2_20, *_ = load_and_concat_data(logs_pickle_paths_2_20, obj_id_2_20)
out_targets_2_20_fix, assoc_dets, sensors, *_ = load_and_concat_data(logs_pickle_paths_2_20_fix, obj_id_2_20_fix)

put_nans_in_scan_index_jumps(out_targets_2_14)
put_nans_in_scan_index_jumps(out_targets_2_20)
put_nans_in_scan_index_jumps(out_targets_2_20_fix)

rt_data = transform_rt_range_data_mat2data_frame(RT_DATA_PATH, rt_ref_x=0.0, rt_ref_y=0.5, ref_length=4.9, ref_width=1.9)
rt_data.set_index('time', inplace=True)
rt_data['bounding_box_orientation_deg'] = np.rad2deg(rt_data['bounding_box_orientation'])

rt_data = rt_data.loc[rt_data.index > 7032, :]

rt_data.index = rt_data.index + 0.3

get_ref_point_pos_for_rt_range(rt_data, 0.0, 0.5, 0.0, 0.0)
get_ref_point_pos_for_target(out_targets_2_14, 0.0, 0.0)
get_ref_point_pos_for_target(out_targets_2_20, 0.0, 0.0)
get_ref_point_pos_for_target(out_targets_2_20_fix, 0.0, 0.0)

plots_info = [
    # plot name                                 signal_to_compare               # unit
    ('Reference point longitudinal position',   'position_x',                   '[m]'),
    ('Reference point lateral position',        'position_y',                   '[m]'),
    ('Bounding box center longitudinal position', 'center_x',                   '[m]'),
    ('Bounding box center lateral position',     'center_y',                    '[m]'),
    ('Absolute velocity longitudinal',          'velocity_otg_x',               '[m/s]'),
    ('Absolute velocity lateral',               'velocity_otg_y',               '[m/s]'),
    ('Speed',                                   'speed',                        '[m/s]'),
    ('Bounding box longitudinal dimension',     'bounding_box_dimensions_x',    '[m]'),
    ('Bounding box lateral dimension',          'bounding_box_dimensions_y',    '[m]'),
    ('Bounding box orientation',                'bounding_box_orientation_deg', '[deg]')
]

df_list = [out_targets_2_14, out_targets_2_20, rt_data, out_targets_2_20_fix]
labels = ['tracker core 2.14', 'tracker core 2.20', 'rt range', 'proposed change']
for plot_info in plots_info:
    plot_title, signal_to_compare, unit = plot_info
    plot_signal_compare(df_list, labels, plot_title, signal_to_compare, unit, 'time [s]')


f, ax = plt.subplots()
ax.plot(rt_data.host_vel_abs_y, label='host abs vel lat.')
ax.plot(rt_data.host_yaw_infl_y, label='host yawing influence lat.')
ax.plot(rt_data.target_vel_rel_y, label='target rel vel lat.')
ax.plot(rt_data.velocity_otg_y, label='target abs. velocity lat')
ax.legend()
ax.grid()
ax.set_title('Target absolute velocity lateral components')
ax.set_xlabel('time [s]')
ax.set_ylabel('velocity [m/s]')

f, ax = plt.subplots()
ax.plot(rt_data.host_vel_abs_x, label='host abs vel long.')
ax.plot(rt_data.host_yaw_infl_x, label='host yawing influence long.')
ax.plot(rt_data.target_vel_rel_x, label='target rel vel long.')
ax.plot(rt_data.velocity_otg_x, label='target abs. velocity long')
ax.legend()
ax.grid()
ax.set_title('Target absolute velocity longitudinal components')
ax.set_xlabel('time [s]')
ax.set_ylabel('velocity [m/s]')

rt_data = synchronize_rt_2_tracker(rt_data, out_targets_2_20)
rt_extracted = ExtractedData()
rt_extracted.objects = RtObjects()
rt_extracted.objects.signals = rt_data
pickle_save_path = r'C:\logs\BYK-627_DEX-690\DEX_690_rt_range_3000_dvl_extracted.pickle'
save_to_pkl(rt_extracted, pickle_save_path)


