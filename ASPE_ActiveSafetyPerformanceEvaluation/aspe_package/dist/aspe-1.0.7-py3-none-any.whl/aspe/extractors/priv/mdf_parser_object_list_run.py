import glob
from mdf_parser_pkg.mdf_parser import parse_file


def parse_log_list(log_list, config='mid', f_save_file=True):
    for log_path in log_list:
        parse_file(log_path, config, save_file=f_save_file)


if __name__ == '__main__':
    log_list = glob.glob(r'C:\logs\BYK-589_DEX-530\BN_FASETH\*.MF4')
    parse_log_list(log_list)

    #object_list_data = parsed_data['RecogSideRadarObjectlist']['Objectlist']
    #transformed, metadata = flatten_someip_object_list_data(object_list_data)
