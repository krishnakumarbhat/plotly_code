import os

path = r'P:\Logs\F360\OXTS_RT-Range\RNA_SRR5\Opole_CW19\TRACKER360_FTP_900'
files = []
file_save_name = 'log_list_to_resim.txt'

for r, d, f in os.walk(path):
    for file in f:
        if '.dvl' in file:
            files.append(os.path.join(r, file))

with open(os.path.join(path, file_save_name), 'w') as file:
    file.write("\n".join(files))




