from aspe.report_generator.ReportGenerator import ReportGenerator
from aspe.report_generator.Plotter import Plotter

"""
Reporting example.
Update report_temp_figs_path within ExampleData (or juts update Plotter_config dict directly) with some folder for 
storing temporary figures created for report. This folder must exists on your disk.
To generate example data which is needed run first 04_F360_multi_log_evaluation.py.
"""

sw_1_load_path = r"C:\logs\VTV_mf4_logs\A370\BN_FASETH\DS_14_pe_output.pickle"
report_save_path = r"C:\logs\VTV_mf4_logs\A370\BN_FASETH\DS_14_aspe_report.pdf"

# Create plotter object
plotter_config = {'plot_style': 'default',
                  'default_plot_size': (10, 3.75),
                  'figures_save_path': r"C:\logs\VTV_mf4_logs\A370\aspe_figures",
                  'host_size': (2, 5),
                  'trace_plots_lims': (-75, 75)}
plotter = Plotter(plotter_config)

# set main report configuration
report_gen_config = {'title': 'Active Safety Performance Evaluation report',
                     'subtitle': 'F360 radar tracker',
                     'tc_description': 'this is test scenario description'}

# prepare data
sw_names = ['sw_1']  # if soft_names is empty list, default names are used: sw_1, sw_2, ... sw_N
sw_descriptions = ['this is sw_1 description']
data_paths = [sw_1_load_path]

# generate report and save it
report_input_data = ReportGenerator.prepare_input_data(data_paths, sw_names, sw_descriptions)
rep_gen = ReportGenerator(report_input_data, report_gen_config, plotter)
rep_gen.save_pdf(report_save_path)