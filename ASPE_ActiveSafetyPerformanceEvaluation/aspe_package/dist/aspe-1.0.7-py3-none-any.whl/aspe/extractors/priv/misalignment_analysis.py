from aspe.extractors.API.mudp import extract_f360_from_mudp
import numpy as np
from scipy.optimize import curve_fit
from tqdm import tqdm
import pandas as pd


def analyse_log_detections(mudp_log_file_path: str, mudp_stream_def_path: str, minimum_dets_in_scan: int = 10):
    """
    Analyse stationary detections within given log to estimate boresight angles and true host speed for each radar.
    For each scan try to fit cosine function to detections in range_rate(azimuth) domain. For straight line host
    movement cosine function min. argument should be equal to -BSA and amplitude of it should be equal to host
    true speed.
    :param mudp_log_file_path: path to .mudp log file
    :param mudp_stream_def_path: path to .mudp stream definitions
    :param minimum_dets_in_scan: consider only scans where number of sensor detections is above this value
    :return: data frame with columns:
        'sensor_id' - id of sensor
        'scan_index' - scan index
        'n_dets' - number of sensor detections in give scan
        'speed_from_dets' - speed taken from detections analysis (amplitude of cosine fit)
        'host_raw_speed' - raw host speed taken from log
        'bsa_from_dets' - boresight angle taken from detections analysis (-min arg of cosine fit)
        'bsa_from_log' - boresight angle taken from log
    """
    extracted = extract_f360_from_mudp(mudp_log_file_path, mudp_stream_def_path=mudp_stream_def_path,
                                       sensors=True,
                                       detections=True,
                                       force_extract=True,
                                       raw_signals=True,
                                       save_to_file=True)

    all_dets = extracted.detections.signals
    stat_dets = all_dets.loc[all_dets.motion_status == 2, :]

    host_raw_speed = pd.DataFrame({'raw_speed': extracted.host.raw_signals.loc[:, 'raw_speed'].to_numpy()},
                                  index=extracted.host.signals.loc[:, 'scan_index'])

    results = pd.DataFrame(columns=['sensor_id', 'scan_index', 'n_dets', 'speed_from_dets', 'host_raw_speed', 'bsa_from_dets', 'bsa_from_log'])

    for sensor_id in (1, 2, 3, 4):
        sensor_dets = stat_dets.loc[stat_dets.sensor_id == sensor_id, :]
        sensor_df = extracted.sensors.per_sensor.loc[extracted.sensors.per_sensor.sensor_id == sensor_id, :]

        for scan_idx, dets_in_scan in tqdm(sensor_dets.groupby(by='scan_index')):
            if len(dets_in_scan) < minimum_dets_in_scan:
                continue
            azimuth, rrate = dets_in_scan.azimuth.to_numpy(), dets_in_scan.range_rate_dealiased.to_numpy()

            (amplitude, phase), covariance = curve_fit(form, azimuth, rrate)
            amplitude, phase = handle_cos_negative_amplitude(amplitude, phase)

            phase = normalize_angle(phase)
            # phase is equal to -maximum arg of cosine. To get minimum arg add pi to phase. bsa = -minimum_arg, thus:
            bsa = normalize_angle(phase - np.pi)

            record = {
                'sensor_id': sensor_id,
                'scan_index': scan_idx,
                'n_dets': len(dets_in_scan),
                'speed_from_dets': amplitude,
                'host_raw_speed': host_raw_speed.loc[scan_idx, 'raw_speed'],
                'bsa_from_dets': bsa,
                'bsa_from_log': sensor_df.boresight_az_angle.iloc[0]
            }
            results = results.append(record, ignore_index=True)
    return results


def get_misalignment_angle_and_speed_corr_factor(det_analysis_results: pd.DataFrame):
    """
    Get misalignment angle and speed correction factors for each sensor. Correction factors are calculated for each
    scan separately - outputs are median of all values.
    :param det_analysis_results: output of analyse_log_detections function
    :return: pd.DataFrame with columns:
        'sensor_id': id of sensor
        'misalign_angle_deg': misalignment correction angle in degree
        'misalign_angle_std_deg': misalignment correction angle std degree
        'speed_corr_factor': speed correction factor
        'speed_corr_factor_std': speed correction factor std
    """
    out = {
        'sensor_id': [],
        'misalign_angle_deg': [],
        'misalign_angle_std_deg': [],
        'speed_corr_factor': [],
        'speed_corr_factor_std': []
    }

    for sensor_id, sensor_df in det_analysis_results.groupby(by='sensor_id'):
        bsa_diff_deg = np.rad2deg(sensor_df.bsa_from_dets - sensor_df.bsa_from_log)
        misalign_angle_deg = np.median(bsa_diff_deg)
        misalign_angle_std_deg = np.std(bsa_diff_deg)

        speed_corr_factor_vec = sensor_df.speed_from_dets / sensor_df.host_raw_speed
        speed_corr_factor = np.median(speed_corr_factor_vec)
        speed_corr_factor_std = np.std(speed_corr_factor_vec)

        out['sensor_id'].append(sensor_id)
        out['misalign_angle_deg'].append(misalign_angle_deg)
        out['misalign_angle_std_deg'].append(misalign_angle_std_deg)
        out['speed_corr_factor'].append(speed_corr_factor)
        out['speed_corr_factor_std'].append(speed_corr_factor_std)

    return pd.DataFrame(out)


def normalize_angle(angle):
    """
    Normalize angle to be in (-PI, PI) range
    :param angle: input angle
    :return: normalized angle
    """
    return (angle + np.pi) % (2 * np.pi) - np.pi


def form(azimuth: float, amplitude: float, phase: float):
    """
    Form of fit function used by scipy.optimize.curve_fit function
    :param azimuth: detection azimuth
    :param amplitude: cosine amplitude - this value is being estimated
    :param phase: cosine phase shift - this value is being estimated
    :return: value of cosine function
    """
    return amplitude * np.cos(azimuth + phase)


def handle_cos_negative_amplitude(amplitude: float, phase: float):
    if amplitude < 0:
        amplitude = -amplitude
        phase = phase - np.pi
    return amplitude, phase


if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"
    mudp_log_file_path = r"C:\logs\VTV_mf4_logs\A370\DS_04_oncomming_traffic\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_04_50_60_R_SRR_DEBUG_WBATR91070LC63638_20200617_174018_deb_0001.mudp"
    mudp_files = [
        r"C:\logs\VTV_mf4_logs\A370\DS_04_oncomming_traffic\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_04_50_60_R_SRR_DEBUG_WBATR91070LC63638_20200617_174018_deb_0000.mudp",
        r"C:\logs\VTV_mf4_logs\A370\DS_04_oncomming_traffic\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_04_50_60_R_SRR_DEBUG_WBATR91070LC63638_20200617_174018_deb_0001.mudp",
        r"C:\logs\VTV_mf4_logs\A370\DS_04_oncomming_traffic\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_04_50_80_L_SRR_DEBUG_WBATR91070LC63638_20200617_174643_deb_0001.mudp",
        r"C:\logs\VTV_mf4_logs\A370\DS_04_oncomming_traffic\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_04_50_80_R_SRR_DEBUG_WBATR91070LC63638_20200617_174536_deb_0001.mudp",
        r"C:\logs\VTV_mf4_logs\A370\DS_04_oncomming_traffic\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_04_80_50_L_SRR_DEBUG_WBATR91070LC63638_20200617_174418_deb_0001.mudp",
        ]

    results_list = []
    for log_index, mudp_log_file_path in tqdm(enumerate(mudp_files)):
        det_analysis_results = analyse_log_detections(mudp_log_file_path, mudp_stream_def_path)
        results_list.append(det_analysis_results)
    multi_results = pd.concat(results_list)

    output = get_misalignment_angle_and_speed_corr_factor(multi_results)
    print(output.to_string())
