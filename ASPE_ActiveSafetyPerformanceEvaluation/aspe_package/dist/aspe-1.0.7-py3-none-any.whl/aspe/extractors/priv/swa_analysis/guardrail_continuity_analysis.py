from aspe.utilities.SupportingFunctions import load_from_pkl
from aspe.utilities.MathFunctions import calc_position_in_bounding_box
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from itertools import groupby


if __name__ == '__main__':
    events_data_path = 'C:\\logs\\SWA_tests_drives\\rRf360t4310309v205p50_2_36_0\\events_290420211248.pickle'
    events = load_from_pkl(events_data_path)

    gr_present = events.guard_rails_f_present_left
    grouped = groupby(list(gr_present))
    gr_drops = [len(list(v)) for k, v in grouped if k == 0]

    for ev_type, ev in events.groupby(by='event_type'):
        gr_present = ev.guard_rails_f_present_left

        gr_present_count = np.sum(gr_present)
        total_samples = len(ev)
        ratio = gr_present_count / total_samples
        print(f"Event {ev_type} - guardrail present: {gr_present_count} scans, total scans: {total_samples}, ratio: {ratio}")

    f, axes = plt.subplots()
    axes.set_title('Guardrail drops histogram - SWA workshop data')
    axes.hist(gr_drops, bins=100)
    axes.set_xlabel('guardrail not available consecutive scans [-]')
    axes.set_ylabel('count [-]')
    axes.grid()
