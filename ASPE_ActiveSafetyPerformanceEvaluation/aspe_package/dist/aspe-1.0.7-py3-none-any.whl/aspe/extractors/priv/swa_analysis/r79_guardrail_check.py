from aspe.extractors.priv.swa_analysis.create_log_pointer import get_guardrail_info

if __name__ == '__main__':
    log_p = r"C:\logs\homologation_motorbike_issues\20201215T122251_20201215T122311_541610_H019173_SRR_DEBUG_rRf360t4300309v205p50_dev_73fb91.mudp"
    g_info = get_guardrail_info(log_path=log_p)