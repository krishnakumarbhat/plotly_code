from aspe.extractors.API.mudp import extract_f360_from_mudp, extract_f360_from_mudp_folder, parse_mudp
from pathlib import Path
import numpy as np
import pandas as pd
from tqdm import tqdm
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages


def check_if_large_rel_vel_obj_are_in_log(obj_signals, rel_vel_thr):
    return np.any(obj_signals.velocity_rel_x > rel_vel_thr)


def get_relevant_objs_unique_id(obj_signals, rel_vel_thr):
    high_rel_speed_mask = obj_signals.velocity_rel_x > rel_vel_thr
    in_rear_of_host_mask = obj_signals.position_x < 0
    heading_mask = np.abs(obj_signals.bounding_box_orientation) < np.deg2rad(30)
    lateral_mask = (-10 < obj_signals.position_y) & (obj_signals.position_y < -2)
    lateral_vel_mask = np.abs(obj_signals.velocity_otg_y) < 2
    summary_mask = high_rel_speed_mask & in_rear_of_host_mask & heading_mask & lateral_mask & lateral_vel_mask
    if np.any(summary_mask):
        return np.unique(obj_signals.loc[summary_mask, 'unique_id'])
    else:
        return []


def plot_obj_trace_plot(obj_signals, ax):
    ax.plot(obj_signals.position_y, obj_signals.position_x, '.', label=f'unique_id - {obj_signals.unique_id.iloc[0]}')


if __name__ == '__main__':
    mudp_stream_def_path = "C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"  # if None parser looks for MUDP_STREAM_DEFINITIONS_PATH environmental variable,
    mudp_log_file_path = r"C:\logs\SWA_tests_drives\event_1\20210421T115910_20210421T115930_541610_H019173_SRR_DEBUG.mudp"

    logs_dir = Path(r"C:\logs\SWA_tests_drives\rRf360t4310309v205p50_2_36_0")
    log_list = logs_dir.glob("*.mudp")
    results = []

    pp = PdfPages(str(logs_dir / 'swa_rel_objs_finding.pdf'))
    for log_path in tqdm(log_list):
        extracted = extract_f360_from_mudp(str(log_path), mudp_stream_def_path=mudp_stream_def_path,
                                           internal_objects=True,
                                           detections=True,
                                           raw_signals=True,
                                           save_to_file=True)
        if extracted.internal_objects is not None:
            rel_obj_exists = check_if_large_rel_vel_obj_are_in_log(extracted.internal_objects.signals, 10.0)
            unique_ids = get_relevant_objs_unique_id(extracted.internal_objects.signals, 10.0)

            objs_grouped = extracted.internal_objects.signals.groupby(by='unique_id')
            fig, ax = plt.subplots()
            for unique_id in unique_ids:
                rel_obj_signals = objs_grouped.get_group(unique_id)
                plot_obj_trace_plot(rel_obj_signals, ax)
            ax.set_title(log_path.name)
            ax.grid()
            pp.savefig(fig)
            plt.close(fig)

            results.append((str(log_path), rel_obj_exists))
    pp.close()

    out_df = pd.DataFrame({
        'log_path': [log_path for log_path, rel_obj_exists in results],
        'rel_obj_exists': [rel_obj_exists for log_path, rel_obj_exists in results]
    })