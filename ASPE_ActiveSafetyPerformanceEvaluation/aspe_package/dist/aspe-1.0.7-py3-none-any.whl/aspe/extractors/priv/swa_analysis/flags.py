from copy import copy

import pandas as pd
import numpy as np

from aspe.evaluation.RadarObjectsEvaluation.Flags import IFlag
from aspe.extractors.Interfaces.Enums.Object import MovementStatus
from aspe.utilities.MathFunctions import normalize_angle_vector
from shapely.geometry import Point, Polygon


class IsInPolygon(IFlag):
    """ Class for configurable flag calculation: check if object is defined polygon """
    def __init__(self, polygon: Polygon, flag_signature='is_in_polygon',  pos_x_name='center_x', pos_y_name='center_y',
                 *args, **kwargs):
        """
        Setting initial parameters
        :param polygon: polygon in which points should be checked
        :type polygon: shapely.geometry.Polygon
        :param flag_signature:
        :param pos_x_name:
        :param pos_y_name:
        :param args:
        :param kwargs:
        """
        super().__init__(flag_signature, *args, **kwargs)
        self.polygon = polygon
        self.pos_x_name = pos_x_name
        self.pos_y_name = pos_y_name

    def calc_flag(self, data_frame: pd.DataFrame, *args, **kwargs) -> pd.Series:
        """
        :param data_frame: DataFrame for which flag should be calculated
        :type data_frame: pandas.DataFrame

        :param args:
        :param kwargs:
        :return: pandas.Series: - series with the same length as data frame with flag (boolean)
        """
        if data_frame.empty:
            is_in_polygon = pd.Series([])  # For empty
        else:
            is_in_polygon = data_frame.apply(self._is_single_point_inside_polygon, axis=1,
                                             args=(self.polygon, self.pos_x_name, self.pos_y_name))
        return is_in_polygon

    @staticmethod
    def _is_single_point_inside_polygon(single_row: pd.Series, region: Polygon,
                                        pos_x_name='center_x', pos_y_name='center_y'):
        """
        Determine if selected object track location is inside polygon
        :param pos_x_name:
        :param pos_y_name:
        :param single_row: object track properties for single scan index from which center position is extracted
        :param region: polygon against which the point is checked
        :return: boolean value indicating if object track center position is inside region
        """
        point = Point(single_row[pos_x_name], single_row[pos_y_name])
        return region.contains(point)


class IsInCoarseZone(IFlag):
    """ Class for configurable flag calculation: check if object is defined polygon """
    def __init__(self, heading_thr=np.deg2rad(30.0), expected_heading=np.deg2rad(0.0),
                 rel_vel_thr=4.0,   flag_signature='is_in_coarse_zone', *args, **kwargs):
        """
        Setting initial parameters
        :param expected_heading:
        :param heading_thr:
        :param rel_vel_thr:
        :param flag_signature:
        :param args:
        :param kwargs:
        """
        super().__init__(flag_signature, *args, **kwargs)
        self.heading_thr = heading_thr
        self.expected_heading = expected_heading
        self.rel_vel_thr = rel_vel_thr

    def calc_flag(self, data_frame: pd.DataFrame, *args, **kwargs) -> pd.Series:
        """
        :param data_frame: DataFrame for which flag should be calculated
        :type data_frame: pandas.DataFrame
        :param event: event definition
        :type event: pandas.Series
        :param args:
        :param kwargs:
        :return: pandas.Series: - series with the same length as data frame with flag (boolean)
        """
        f_reduced_id_ok = data_frame['reduced_id'] != 0
        f_moving_ok = data_frame['movement_status'] == MovementStatus.MOVING
        heading = np.arctan2(data_frame['velocity_otg_y'], data_frame['velocity_otg_x'])
        f_heading_ok = np.abs(normalize_angle_vector(heading - self.expected_heading)) < self.heading_thr
        f_rel_vel_ok = data_frame['velocity_rel_x'] > self.rel_vel_thr

        f_in_coarse_gate = f_reduced_id_ok & f_moving_ok & f_heading_ok & f_rel_vel_ok

        return f_in_coarse_gate


class IsInLCDAZones(IFlag):
    """ Class for configurable flag calculation: check if object is defined polygon """
    def __init__(self, left_zone: Polygon, left_zone_hist: Polygon, right_zone: Polygon, right_zone_hist: Polygon,
                 flag_signature='in_swa_zone', heading_thr=np.deg2rad(30.0), ep_thr=-1.0, debouncing=0,
                 *args, **kwargs):
        """
        Setting initial parameters
        :param polygon: polygon in which points should be checked
        :type polygon: shapely.geometry.Polygon
        :param flag_signature:
        :param pos_x_name:
        :param pos_y_name:
        :param args:
        :param kwargs:
        """
        super().__init__(flag_signature, *args, **kwargs)
        self.left_zone_flag = IsInPolygon(left_zone, pos_x_name='position_x', pos_y_name='position_y')
        self.left_zone_hist_flag = IsInPolygon(left_zone_hist, pos_x_name='position_x', pos_y_name='position_y')
        self.right_zone_flag = IsInPolygon(right_zone, pos_x_name='position_x', pos_y_name='position_y')
        self.right_zone_hist_flag = IsInPolygon(right_zone_hist, pos_x_name='position_x', pos_y_name='position_y')
        self.heading_thr = heading_thr
        self.ep_thr = ep_thr
        self.debouncing = debouncing

    def calc_flag(self, data_frame: pd.DataFrame, *args, **kwargs) -> pd.Series:
        """
        :param data_frame: DataFrame for which flag should be calculated
        :type data_frame: pandas.DataFrame

        :param args:
        :param kwargs:
        :return: pandas.Series: - series with the same length as data frame with flag (boolean)
        """
        is_in_left_zone = self.left_zone_flag.calc_flag(data_frame)
        is_in_left_hist_zone = self.left_zone_hist_flag.calc_flag(data_frame)

        is_in_right_zone = self.right_zone_flag.calc_flag(data_frame)
        is_in_right_hist_zone = self.right_zone_hist_flag.calc_flag(data_frame)

        heading = np.arctan2(data_frame['velocity_otg_y'], data_frame['velocity_otg_x'])
        is_heading_ok = np.abs(normalize_angle_vector(heading)) < self.heading_thr

        is_ep_ok = data_frame['existence_indicator'] > self.ep_thr

        # Apply additional filters to each zone
        is_in_left_zone = is_in_left_zone & is_heading_ok & is_ep_ok
        is_in_left_hist_zone = is_in_left_hist_zone & is_heading_ok & is_ep_ok
        is_in_right_zone = is_in_right_zone & is_heading_ok & is_ep_ok
        is_in_right_hist_zone = is_in_right_hist_zone & is_heading_ok & is_ep_ok

        # Apply debouncing to main filter
        # TODO: Groupby to do it for each objects
        is_in_left_zone = debouncing_binary_array(is_in_left_zone, self.debouncing)
        is_in_right_zone = debouncing_binary_array(is_in_right_zone, self.debouncing)

        # Aply hysteresis
        is_in_left_zone_with_hysteresis = self.hysteresis(is_in_left_zone, is_in_left_hist_zone)
        is_in_right_zone_with_hysteresis = self.hysteresis(is_in_right_zone, is_in_right_hist_zone)

        is_valid = is_in_left_zone_with_hysteresis | is_in_right_zone_with_hysteresis
        return is_valid

    @staticmethod
    def hysteresis(main_signal, signal_to_keep_true):
        """
        Simple 'local' hysteresis implementation to keep signal high based on another signal
        :param main_signal:
        :param signal_to_keep_true:
        :return:
        """
        output = main_signal.to_numpy()
        signal_to_keep_true_np = signal_to_keep_true.to_numpy()
        for i, _ in enumerate(output):
            if i == 0:
                continue
            if not output[i]:
                output[i] = output[i-1] & signal_to_keep_true_np[i]
        return output


def debouncing_binary_array(array: np.array, n_times=1) -> np.array:
    output_array = array.copy()
    if array.size > 0:  # handle empty array
        shifted_array = array.copy()
        for i in range(n_times):
            shifted_array = np.roll(shifted_array, 1)
            shifted_array[0] = False
            output_array = output_array & shifted_array

    return output_array
