from aspe.extractors import extract_f360_from_mudp
from aspe.providers.F360MudpRtRangeMdfDataProvider import F360MudpRtRangeMdfDataProvider

import matplotlib.pyplot as plt
from numbers import Number
from pathlib import Path
from typing import Tuple, Dict


def plot_range_rates_within_roi(
        mudp_paths: Dict[str, str],
        mudp_stream_def_path: str,
        roi_x_min_max: Tuple[Number, Number],
        roi_y_min_max: Tuple[Number, Number],
        extract_rt_range: bool):

    host_rear_axle_to_f_bumper = 3.7  # distance from ego vehicle rear axle to front bumper - need for CS transform
    host_length = 4.7
    host_width = 1.9
    cs_system = 'VCS'  # coordinate system in which evaluation will be performed
    rt_f360_dt = -0.05  # time delay between RtRange and F360 which must be compensated

    f, axes = plt.subplots(nrows=4, sharex=True, figsize=(12, 6))
    for alias, mudp_path in mudp_paths.items():
        if extract_rt_range:
            provider = F360MudpRtRangeMdfDataProvider(
                mudp_stream_defs_path=mudp_stream_def_path,
                host_rear_axle_to_front_bumper_dist=host_rear_axle_to_f_bumper,
                host_width=host_width,
                host_length=host_length,
                rt_hunter_target_shift=10,
                reference_time_shift=rt_f360_dt,
                coordinate_system=cs_system,
                save_to_file=True,
                force_extract=True,
                raw_signals=True
            )
            est, ref = provider.get_single_log_data(mudp_path)
        else:
            est = extract_f360_from_mudp(mudp_path, mudp_stream_def_path=mudp_stream_def_path, detections=True,
                                         raw_signals=True, save_to_file=True)

        host = est.host.signals
        host['speed'] = est.host.raw_signals['speed']
        dets = est.detections.raw_signals

        dets['scan_index'] = est.detections.signals.loc[:, 'scan_index']

        dets_pos_x_mask = (roi_x_min_max[0] < dets.loc[:, 'vcs_x']).to_numpy() & (dets.loc[:, 'vcs_x'] < roi_x_min_max[1]).to_numpy()
        dets_pos_y_mask = (roi_y_min_max[0] < dets.loc[:, 'vcs_y']).to_numpy() & (dets.loc[:, 'vcs_y'] < roi_y_min_max[1]).to_numpy()

        dets_roi = dets.loc[dets_pos_x_mask & dets_pos_y_mask, :]
        host = host.loc[host.loc[:, 'scan_index'].isin(dets_roi.loc[:, 'scan_index']), :]

        axes[0].plot(dets_roi.loc[:, 'scan_index'].to_numpy(), dets_roi.loc[:, 'rngrate_dealiased'].to_numpy(), '.', label=f'{alias}')
        axes[1].plot(dets_roi.loc[:, 'scan_index'].to_numpy(), dets_roi.loc[:, 'rngrate_comp'].to_numpy(), '.', label=f'{alias}')
        axes[2].plot(host.loc[:, 'scan_index'], host.loc[:, 'velocity_otg_x'], label=f'{alias} host')
        axes[3].plot(host.loc[:, 'scan_index'], host.loc[:, 'acceleration_otg_x'], label=f'{alias} host')

    if extract_rt_range:
        host_ref = ref.host.signals
        host_ref = host_ref.loc[host_ref.loc[:, 'scan_index'].isin(dets_roi.loc[:, 'scan_index']), :]
        axes[2].plot(host_ref.loc[:, 'scan_index'], host_ref.loc[:, 'velocity_otg_x'], label='RtRange')
        axes[3].plot(host_ref.loc[:, 'scan_index'], host_ref.loc[:, 'acceleration_otg_x'], label='RtRange')

    signal_names = ['Range rate', 'Range rate comp', 'Host velocity long.', 'Host acceleration long.']
    for ax, signal in zip(axes, signal_names):
        ax.set_title(signal)
        ax.grid()
        ax.legend()
    f.suptitle(Path(list(mudp_paths.values())[0]).name)
    f.tight_layout(rect=[0, 0.03, 1, 0.95])


if __name__ == '__main__':
    mudp_stream_def_path = r"C:\wkspaces_git\F360Core\sw\zResimSupport\stream_definitions"

    # stage tests with RtRange case
    mudp_paths = {'sw_1': r"C:\logs\VTV_mf4_logs\A370\DS_07_cross_traffic_braking\SRR_DEBUG\MID_ECU_3.14.210_S_3.14.106_TRA_DS_07_40_30_L_SRR_DEBUG_WBATR91070LC63638_20200622_142130_deb_0002.mudp"}
    plot_range_rates_within_roi(mudp_paths, mudp_stream_def_path, roi_x_min_max=(30, 40), roi_y_min_max=(0, 10), extract_rt_range=True)

    # data without RtRange case
    mudp_paths = {'sw_1': r"C:\logs\DEX_1030\20200630T114316_20200630T114336_541611_H019203_SRR_DEBUG.mudp"}
    plot_range_rates_within_roi(mudp_paths, mudp_stream_def_path, roi_x_min_max=(0, 100), roi_y_min_max=(-2, 2), extract_rt_range=False)
