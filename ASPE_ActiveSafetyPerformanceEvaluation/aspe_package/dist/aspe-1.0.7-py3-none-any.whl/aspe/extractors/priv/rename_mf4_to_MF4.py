import os
from pathlib import Path


log_dir = Path(r"C:\logs\VTV_mf4_logs\A370\DS_07_cross_traffic_braking\A430_ATS+6\BN_FASETH")

logs = log_dir.glob("*mf4")

for log in logs:

    os.rename(str(log), str(log).replace('.mf4', '.MF4'))

