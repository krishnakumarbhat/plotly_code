import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from aspe.utilities.synchronize_rt_2_tracker import synchronize_rt_2_tracker
from aspe.utilities.transform_rt_data_mat2data_frame import transform_rt_range_data_mat2data_frame
from aspe.utilities.SupportingFunctions import load_from_pkl, save_to_pkl
from aspe.utilities.MathFunctions import calc_position_in_bounding_box, calc_velocity_in_position

def get_ref_point_pos_for_rt_range(rt_data, old_ref_x, old_ref_y, new_ref_x, new_ref_y):
    in_pos_x, in_pos_y = rt_data.position_x.to_numpy(), rt_data.position_y.to_numpy()

    new_x, new_y = calc_position_in_bounding_box(in_pos_x, in_pos_y,
                                                 rt_data.bounding_box_dimensions_x.to_numpy(), rt_data.bounding_box_dimensions_y.to_numpy(),
                                                 rt_data.bounding_box_orientation.to_numpy(),
                                                 np.array([old_ref_x] * rt_data.shape[0]), np.array([old_ref_y] * rt_data.shape[0]),
                                                 np.array([new_ref_x] * rt_data.shape[0]), np.array([new_ref_y] * rt_data.shape[0]))
    new_vel_x, new_vel_y = calc_velocity_in_position(in_pos_x, in_pos_y, rt_data.velocity_otg_x.to_numpy(),
                                                     rt_data.velocity_otg_y.to_numpy(), rt_data.yaw_rate.to_numpy(),
                                                     new_x, new_y)
    rt_data['position_x'] = new_x
    rt_data['position_y'] = new_y
    rt_data['velocity_otg_x'] = new_vel_x
    rt_data['velocity_otg_y'] = new_vel_y
    rt_data['speed'] = np.sqrt(np.square(new_vel_x) + np.square(new_vel_y))


def get_ref_point_pos_for_target(target, new_ref_x, new_ref_y):
    in_pos_x, in_pos_y = target.position_x.to_numpy(), target.position_y.to_numpy()
    out_pos_x, out_pos_y = np.array([new_ref_x] * target.shape[0]), np.array([new_ref_y] * target.shape[0])

    new_x, new_y = calc_position_in_bounding_box(in_pos_x, in_pos_y,
                                                 target.bounding_box_dimensions_x.to_numpy(), target.bounding_box_dimensions_y.to_numpy(),
                                                 target.bounding_box_orientation.to_numpy(),
                                                 target.bounding_box_refpoint_long_offset_ratio.to_numpy(), target.bounding_box_refpoint_lat_offset_ratio.to_numpy(),
                                                 out_pos_x, out_pos_y)
    target.bounding_box_refpoint_long_offset_ratio = new_ref_x
    target.bounding_box_refpoint_lat_offset_ratio = new_ref_y
    new_vel_x, new_vel_y = calc_velocity_in_position(in_pos_x, in_pos_y, target.velocity_otg_x.to_numpy(),
                                                     target.velocity_otg_y.to_numpy(), target.yaw_rate.to_numpy(),
                                                     new_x, new_y)
    target['position_x'] = new_x
    target['position_y'] = new_y
    target['velocity_otg_x'] = new_vel_x
    target['velocity_otg_y'] = new_vel_y


def load_and_concat_data(pickle_paths_list, ids):
    targets = []
    dets = []
    dets_all = []
    host_data = []
    for id, pickle_path in zip(ids, pickle_paths_list):
        extracted = load_from_pkl(pickle_path)
        obj_signals = extracted.internal_objects.signals.join(extracted.internal_objects.raw_signals, rsuffix='_raw')
        obj_signals = obj_signals.loc[obj_signals.id == id, :]
        det_signals = extracted.detections.signals.join(extracted.detections.raw_signals, rsuffix='_raw')
        host_signals = extracted.host.signals
        dets_all.append(det_signals)
        det_signals = det_signals.loc[det_signals.assigned_obj_id == id, :]
        dets.append(det_signals)
        host_data.append(host_signals)
        targets.append(obj_signals)
    host_data = pd.concat(host_data)
    out_targets = pd.concat(targets)
    host_data.set_index('timestamp', inplace=True, drop=False)
    out_targets.set_index('timestamp', inplace=True, drop=False)
    host_data.sort_index(inplace=True)
    out_targets.sort_index(inplace=True)
    out_targets['bounding_box_orientation_deg'] = np.rad2deg(out_targets['bounding_box_orientation'])
    assoc_dets = pd.concat(dets)
    assoc_dets.set_index('timestamp', inplace=True, drop=False)
    assoc_dets.sort_index(inplace=True)
    dets_all = pd.concat(dets_all).set_index('timestamp', drop=False)
    dets_all.sort_index(inplace=True)
    sensors = extracted.sensors.per_sensor
    return out_targets, assoc_dets, sensors, dets_all, host_data


def put_nans_in_scan_index_jumps(dataframe, time_jump = 0.5):
    scan_index_jumps =dataframe.index[np.where(np.diff(dataframe.index) > time_jump)[0]]
    for jump_ts in scan_index_jumps:
        dataframe.loc[jump_ts + 0.05, :] = np.nan
    dataframe.sort_index(inplace=True)



#######################
#TAKE DATA FROM TRACKER
#######################
obj_id_2_21 = [101] * 7

logs_pickle_paths_2_21 = [
    r'C:\F360\DFT-404\rRf360t4160309v205p50base_63808\20200131T101426_20200131T101446_543078_LB36408_SRR_DEBUG_rRf360t4160309v205p50base_63808_f360_mudp_extracted.pickle',
    r'C:\F360\DFT-404\rRf360t4160309v205p50base_63808\20200131T101446_20200131T101506_543078_LB36408_SRR_DEBUG_rRf360t4160309v205p50base_63808_f360_mudp_extracted.pickle',
    r'C:\F360\DFT-404\rRf360t4160309v205p50base_63808\20200131T101506_20200131T101526_543078_LB36408_SRR_DEBUG_rRf360t4160309v205p50base_63808_f360_mudp_extracted.pickle',
    r'C:\F360\DFT-404\rRf360t4160309v205p50base_63808\20200131T101526_20200131T101546_543078_LB36408_SRR_DEBUG_rRf360t4160309v205p50base_63808_f360_mudp_extracted.pickle',
    r'C:\F360\DFT-404\rRf360t4160309v205p50base_63808\20200131T101546_20200131T101606_543078_LB36408_SRR_DEBUG_rRf360t4160309v205p50base_63808_f360_mudp_extracted.pickle',
    r'C:\F360\DFT-404\rRf360t4160309v205p50base_63808\20200131T101606_20200131T101626_543078_LB36408_SRR_DEBUG_rRf360t4160309v205p50base_63808_f360_mudp_extracted.pickle',
    r'C:\F360\DFT-404\rRf360t4160309v205p50base_63808\20200131T101626_20200131T101629_543078_LB36408_SRR_DEBUG_rRf360t4160309v205p50base_63808_f360_mudp_extracted.pickle'
]

out_targets_2_21, assoc_dets, sensors, dets_all, host_data = load_and_concat_data(logs_pickle_paths_2_21, obj_id_2_21)

put_nans_in_scan_index_jumps(out_targets_2_21)

#############################
### TAKE RT RTANGE DATA #####
#############################
# DEX-690
PLOT_SAVE_PATH = r'C:\F360\DFT-404\plots'
RT_DATA_PATH = r'C:\F360\DFT-404\rt_range_data.mat'

rt_data = transform_rt_range_data_mat2data_frame(RT_DATA_PATH, rt_ref_x=0.0, rt_ref_y=0.5, ref_length=4.9, ref_width=1.9)
rt_data.set_index('time', inplace=True)
rt_data['bounding_box_orientation_deg'] = np.rad2deg(rt_data['bounding_box_orientation'])

rt_data = synchronize_rt_2_tracker(rt_data, out_targets_2_21)

#############################
get_ref_point_pos_for_rt_range(rt_data, 0.0, 0.5, 0.0, 0.0)
get_ref_point_pos_for_target(out_targets_2_21, 0.0, 0.0)


## take only important parameters from rt range data

## it wasn't recalculted for correct position x y

rt_data['host_yaw_infl_y'] = rt_data.position_x.to_numpy() * rt_data.host_yaw_rate.to_numpy()
rt_data['host_yaw_infl_x'] = -rt_data.position_y.to_numpy() * rt_data.host_yaw_rate.to_numpy()




rt_columns = ['scan_index','host_yaw_rate','host_vel_abs_x','host_vel_abs_y','host_yaw_infl_x','host_yaw_infl_y','position_x','position_y','target_vel_rel_x','target_vel_rel_y']#'target_vel_rel_x','target_rel_vel_y']
rt_data = rt_data.loc[:,rt_columns]

# take important data from targets
obj_columns = ['scan_index','velocity_otg_x','velocity_otg_y']
out_targets_2_21 = out_targets_2_21.loc[:,obj_columns]

#take important data from host
host_columns = ['scan_index','velocity_otg_x','velocity_otg_y','yaw_rate']
host_data = host_data.loc[:,host_columns]

object_host_data = pd.merge(host_data, out_targets_2_21, on='scan_index',suffixes=('_host','_obj'))

all_data = pd.merge(object_host_data,rt_data, on='scan_index',suffixes=('','_rt'))

#calculate yaw rate influence from tracker data
#rt_data['velocity_otg_x'] = host_vel_abs_x + target_vel_rel_x + host_yaw_infl_x
#rt_data['velocity_otg_y'] = host_vel_abs_y + target_vel_rel_y + host_yaw_infl_y

host_out = pd.DataFrame()
host_out['host_yaw_infl_y'] = all_data.position_x.to_numpy() * all_data.yaw_rate.to_numpy()
host_out['host_yaw_infl_x'] = -all_data.position_y.to_numpy() * all_data.yaw_rate.to_numpy()
host_out['host_vel_abs_x'] = all_data['velocity_otg_x_host']
host_out['host_vel_abs_y'] = abs(all_data['velocity_otg_y_host'])

rt_out = pd.DataFrame()
rt_out['host_yaw_infl_y'] = all_data['host_yaw_infl_y']
rt_out['host_yaw_infl_x'] = all_data['host_yaw_infl_x']
rt_out['host_vel_abs_x'] = all_data['host_vel_abs_x']
rt_out['host_vel_abs_y'] = all_data['host_vel_abs_y']

target_vel_rel_x = all_data['target_vel_rel_x']
target_vel_rel_y = all_data['target_vel_rel_y']


host_out['velocity_otg_x'] = host_out['host_vel_abs_x'] + target_vel_rel_x + host_out['host_yaw_infl_x']
host_out['velocity_otg_y'] = -host_out['host_vel_abs_y'] + target_vel_rel_y + host_out['host_yaw_infl_y']

rt_out['velocity_otg_x'] = rt_out['host_vel_abs_x'] + target_vel_rel_x + rt_out['host_yaw_infl_x']
rt_out['velocity_otg_y'] = -rt_out['host_vel_abs_y'] + target_vel_rel_y + rt_out['host_yaw_infl_y']

########






f, ax = plt.subplots()
ax.plot(all_data.host_yaw_rate, label='rt data')
ax.plot(all_data.yaw_rate, label='tracker data')
#ax.plot(all_data.velocity_otg_x_obj, label='obj')

ax.legend()
ax.grid()
ax.set_title('')
ax.set_xlabel('time [s]')
ax.set_ylabel('velocity [m/s]')
f.show()


#############################
a = 1

