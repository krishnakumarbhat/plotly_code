from aspe.parsers.MudpParser.mudp_parser import MudpHandler

path = r"C:\logs\CITYLOGS_091634_001.mudp"
# path = r"\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example"
config_path = r"\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\pe_example\configs\ParsersConfig\mudp_data_parser_config.json"
import time

t1 = time.time()
a = MudpHandler(path, config_path)
a.decode()
t2 = time.time()
print(str(t2 - t1))