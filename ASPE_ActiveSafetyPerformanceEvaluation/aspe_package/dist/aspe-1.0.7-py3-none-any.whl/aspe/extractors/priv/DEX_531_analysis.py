from aspe.extractors.F360.Mudp.example_f360_mudp_extractor import example_from_mudp
import matplotlib.pyplot as plt
import numpy as np

if __name__ == '__main__':
    mudp_log_path = r"C:\logs\BMW_SRR5_MID_G31_20200217_NA_NA_NA_094230_001.mudp"
    f360_extracted_data = example_from_mudp(mudp_log_path)
    
    tracker_info = f360_extracted_data.data.tracker_info
    sensors = f360_extracted_data.data.sensors.signals
    
    tracker_index = tracker_info.signals.tracker_index
    exec_ts = tracker_info.signals.execution_timestamp

    tracker_index_ref = np.arange(tracker_index.shape[0]) + tracker_index[0]
    exec_ts_ref = np.arange(exec_ts.shape[0]) * 0.05 + exec_ts[0]

    sensor_1 = sensors.loc[sensors.sensor_id == 1, :]
    sensor_2 = sensors.loc[sensors.sensor_id == 2, :]
    sensor_3 = sensors.loc[sensors.sensor_id == 3, :]
    sensor_4 = sensors.loc[sensors.sensor_id == 4, :]
    sensor_ts_start = (sensor_1.timestamp.to_numpy()[0] + sensor_2.timestamp.to_numpy()[1]) / 2
    sensor_ts_ref = np.arange(sensor_1.timestamp.shape[0]) * 0.05 + sensor_ts_start

    fig, axes = plt.subplots(nrows=3, sharex=True)

    axes[0].plot(tracker_index.to_numpy())
    axes[0].plot(tracker_index_ref)

    axes[1].plot(exec_ts.to_numpy())
    axes[1].plot(exec_ts_ref)

    axes[2].plot(sensor_1.timestamp.to_numpy())
    axes[2].plot(sensor_2.timestamp.to_numpy())
    axes[2].plot(sensor_3.timestamp.to_numpy(), '--')
    axes[2].plot(sensor_4.timestamp.to_numpy(), '--')
    axes[2].plot(sensor_ts_ref)

    titles = ['tracker index', 'tracker timestamp', 'sensors timestamp']
    for n, ax in enumerate(axes):
        ax.grid()
        ax.set_title(titles[n])
        
    axes[0].legend(['observed', 'expected'])
    axes[1].legend(['observed', 'expected'])
    axes[2].legend(['sensor 1', 'sensor 2', 'sensor 3', 'sensor 4', 'expected'])

    fig.suptitle(mudp_log_path.replace('.mudp', ''))
