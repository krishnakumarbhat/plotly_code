from aspe.extractors.Interfaces.ExtractedData import ExtractedData
from aspe.extractors.ReferenceExtractor.RtRange.DataSets.RtObjects import RtObjects
from aspe.utilities.SupportingFunctions import load_from_pkl, save_to_pkl
from aspe.extractors.Interfaces.Enums.Object import MovementStatus
import pandas as pd
import numpy as np
import matplotlib
from matplotlib import pyplot as plt
from scipy.io import loadmat
from aspe.utilities.transform_rt_data_mat2data_frame import transform_rt_range_data_mat2data_frame
from aspe.utilities.MathFunctions import calc_position_in_bounding_box
from aspe.utilities.synchronize_rt_2_tracker import synchronize_rt_2_tracker

PLOT_SAVE_PATH = r'C:\logs\BYK-632_DEX-696\DFT_361_analysis'
RT_DATA_PATH = r"C:\logs\BYK-632_DEX-696\rt_range_data.mat"


def get_ref_point_pos_for_rt_range(rt_data, old_ref_x, old_ref_y, new_ref_x, new_ref_y):
    new_x, new_y = calc_position_in_bounding_box(rt_data.position_x.to_numpy(), rt_data.position_y.to_numpy(),
                                                 rt_data.bounding_box_dimensions_x.to_numpy(), rt_data.bounding_box_dimensions_y.to_numpy(),
                                                 rt_data.bounding_box_orientation.to_numpy(),
                                                 np.array([old_ref_x] * rt_data.shape[0]), np.array([old_ref_y] * rt_data.shape[0]),
                                                 np.array([new_ref_x] * rt_data.shape[0]), np.array([new_ref_y] * rt_data.shape[0]))
    rt_data['position_x'] = new_x
    rt_data['position_y'] = new_y


def get_ref_point_pos_for_target(target, new_ref_x, new_ref_y):
    new_x, new_y = calc_position_in_bounding_box(target.position_x.to_numpy(), target.position_y.to_numpy(),
                                                 target.bounding_box_dimensions_x.to_numpy(), target.bounding_box_dimensions_y.to_numpy(),
                                                 target.bounding_box_orientation.to_numpy(),
                                                 target.bounding_box_refpoint_long_offset_ratio.to_numpy(), target.bounding_box_refpoint_lat_offset_ratio.to_numpy(),
                                                 np.array([new_ref_x] * target.shape[0]), np.array([new_ref_y] * target.shape[0]))
    target.bounding_box_refpoint_long_offset_ratio = new_ref_x
    target.bounding_box_refpoint_lat_offset_ratio = new_ref_y
    target['position_x'] = new_x
    target['position_y'] = new_y


def plot_rt_traces(rt_data):
    host_x = rt_data.Range1HunterPosLocal__Range1HunterPosLocalX
    host_y = rt_data.Range1HunterPosLocal__Range1HunterPosLocalY
    target_x = rt_data.Range1TargetPosLocal__Range1TargetPosLocalX
    target_y = rt_data.Range1TargetPosLocal__Range1TargetPosLocalY

    f, axes = plt.subplots(figsize=(10, 10))
    axes.plot(host_y, host_x, label='host trace')
    axes.plot(target_y, target_x, label='target trace')

    axes.grid()
    axes.set_xlabel('position y [m]')
    axes.set_ylabel('position x [m]')

    axes.set_title('Host/Target traces')
    axes.axis('equal')
    axes.legend()
    f.tight_layout()
    f.savefig(f'{PLOT_SAVE_PATH}\\rt_traces.png')
    plt.close(f)


def plot_signal_compare(df_1, df_2, df_3, label_1, label_2, label_3, plot_title, signal_to_compare, unit, x_label):
    fig, axes = plt.subplots(figsize=(15, 6), ncols=4)
    df_1_split_idxs = list(np.where(np.isnan(df_1.position_x))[0])
    df_2_split_idxs = list(np.where(np.isnan(df_2.position_x))[0])

    df_1_split_idxs.append(df_1.shape[0] - 1)
    df_2_split_idxs.append(df_2.shape[0] - 1)

    plot_idx = 0
    start_idx_1 = 0
    start_idx_2 = 0
    plot_row_col = [
        (0,0),
        (0, 1),
        (1, 0),
        (1, 1)
    ]
    min_df_1 = df_1.loc[:, signal_to_compare].min()
    min_df_2 = df_2.loc[:, signal_to_compare].min()
    min_val = min([min_df_1, min_df_2])

    max_df_1 = df_1.loc[:, signal_to_compare].max()
    max_df_2 = df_2.loc[:, signal_to_compare].max()
    max_val = max([max_df_1, max_df_2])

    for split_idx_df_1, split_idx_df_2 in zip(df_1_split_idxs, df_2_split_idxs):
        sub_df_1 = df_1.iloc[start_idx_1: split_idx_df_1, :]
        sub_df_2 = df_2.iloc[start_idx_2: split_idx_df_2, :]

        x_1 = sub_df_1.index.to_numpy()
        x_2 = sub_df_2.index.to_numpy()
        y_1 = sub_df_1.loc[:, signal_to_compare]
        y_2 = sub_df_2.loc[:, signal_to_compare]

        axes[plot_idx].plot(x_1, y_1, label=label_1)
        axes[plot_idx].plot(x_2, y_2, label=label_2)

        start_idx_1 = split_idx_df_1 + 1
        start_idx_2 = split_idx_df_2 + 1
        plot_idx += 1

    if signal_to_compare in df_3:
        plot_idx = 0
        start_idx_3 = 0
        df_3_split_idxs = list(np.where(np.isnan(df_3.position_x))[0])
        df_3_split_idxs.append(df_3.shape[0] - 1)
        for split_idx_df_3 in df_3_split_idxs:
            sub_df_3 = df_3.iloc[start_idx_3: split_idx_df_3, :]

            x_3 = sub_df_3.index.to_numpy()
            y_3 = sub_df_3.loc[:, signal_to_compare]

            axes[plot_idx].plot(x_3, y_3, label=label_3)
            start_idx_3 = split_idx_df_3 + 1
            plot_idx += 1

    fig.suptitle(plot_title)
    for i in range(0, 4):
        axes[i].grid()
        axes[i].get_xaxis().get_major_formatter().set_useOffset(False)
        axes[i].set_ylim([min_val, max_val])
        plt.setp(axes[i].xaxis.get_majorticklabels(), rotation=45)
    axes[3].legend()
    file_title = plot_title.lower().replace(' ', '_')
    fig.text(0.04, 0.4, signal_to_compare + unit, ha='center', rotation='vertical')
    fig.text(0.5, 0.04, x_label, ha='center')
    fig.savefig(f'{PLOT_SAVE_PATH}\\{file_title}')
    #plt.close(fig)


logs_pickle_paths_2_14 =[
    r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T124627_20200131T124647_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    #r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T124647_20200131T124707_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T124707_20200131T124727_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    #r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T124727_20200131T124747_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T124747_20200131T124807_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    #r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T124807_20200131T124827_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T124827_20200131T124847_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle",
    #r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4080309v205p50_core_2_14\20200131T124847_20200131T124859_543078_LB36408_SRR_DEBUG_rRf360t4080309v205p50_core_2_14_f360_mudp_extracted.pickle"
]
logs_pickle_paths_2_20 = [
    r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124627_20200131T124647_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    #r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124647_20200131T124707_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124707_20200131T124727_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    #r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124727_20200131T124747_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124747_20200131T124807_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    #r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124807_20200131T124827_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124827_20200131T124847_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle",
    #r"C:\logs\BYK-632_DEX-696\SRR_DEBUG\rRf360t4150309v205p50_core_2_20\20200131T124847_20200131T124859_543078_LB36408_SRR_DEBUG_rRf360t4150309v205p50_core_2_20_f360_mudp_extracted.pickle"
]

obj_id_2_14 = [41,
               #104,
               9,
               #83,
               8,
               #36,
               54]
               #18]

obj_id_2_20 = [47,
               #3,
               114,
               #83,
               110,
               #36,
               97]
               #83]

targets_2_14 = []
targets_2_20 = []
min_max_ts = []

for log_index in range(0, len(logs_pickle_paths_2_20)):
    print(f'Processing log {log_index}...')
    pickle_file_2_14 = logs_pickle_paths_2_14[log_index]
    pickle_file_2_20 = logs_pickle_paths_2_20[log_index]

    extracted_2_14 = load_from_pkl(pickle_file_2_14)
    extracted_2_20 = load_from_pkl(pickle_file_2_20)

    id_2_14 = obj_id_2_14[log_index]
    id_2_20 = obj_id_2_20[log_index]

    obj_2_14 = extracted_2_14.objects.signals
    obj_2_20 = extracted_2_20.objects.signals

    moving_mask_2_14 = obj_2_14.movement_status != MovementStatus.STATIONARY
    moving_mask_2_20 = obj_2_20.movement_status != MovementStatus.STATIONARY

    obj_2_14 = obj_2_14.loc[moving_mask_2_14, :].reset_index(drop=True)
    obj_2_20 = obj_2_20.loc[moving_mask_2_20, :].reset_index(drop=True)

    id_mask_2_14 = obj_2_14.tracker_id == id_2_14
    id_mask_2_20 = obj_2_20.tracker_id == id_2_20

    obj_2_14 = obj_2_14.loc[id_mask_2_14, :]
    obj_2_20 = obj_2_20.loc[id_mask_2_20, :]

    targets_2_14.append(obj_2_14)
    targets_2_20.append(obj_2_20)

    min_ts = np.min([np.min(obj_2_14.timestamp), np.min(obj_2_20.timestamp)])
    max_ts = np.max([np.max(obj_2_14.timestamp), np.max(obj_2_20.timestamp)])
    min_max_ts.append((min_ts, max_ts))

for t_2_14, t_2_20 in zip(targets_2_14, targets_2_20):
    t_2_14.set_index('timestamp', inplace=True, drop=True)
    t_2_20.set_index('timestamp', inplace=True, drop=True)

out_targets_2_14 = pd.concat(targets_2_14)
out_targets_2_20 = pd.concat(targets_2_20)

out_targets_2_14.sort_index(inplace=True)
out_targets_2_20.sort_index(inplace=True)

out_targets_2_14['bounding_box_orientation_deg'] = np.rad2deg(out_targets_2_14['bounding_box_orientation'])
out_targets_2_20['bounding_box_orientation_deg'] = np.rad2deg(out_targets_2_20['bounding_box_orientation'])


rt_data = transform_rt_range_data_mat2data_frame(RT_DATA_PATH, rt_ref_x=0.0, rt_ref_y=0.5, ref_length=4.9, ref_width=1.9, include_host_yawing=False)
rt_data.set_index('time', inplace=True)
rt_data['bounding_box_orientation_deg'] = np.rad2deg(rt_data['bounding_box_orientation'])


out_targets_2_14 = out_targets_2_14.loc[out_targets_2_14.index > 12660, :]
out_targets_2_20 = out_targets_2_20.loc[out_targets_2_20.index > 12660, :]

scan_index_jumps_2_14 = out_targets_2_14.index[np.where(np.diff(out_targets_2_14.index) > 5)[0]]
scan_index_jumps_2_20 = out_targets_2_20.index[np.where(np.diff(out_targets_2_20.index) > 5)[0]]


for jump_ts in scan_index_jumps_2_14:
    out_targets_2_14.loc[jump_ts + 0.05, :] = np.nan

for jump_ts in scan_index_jumps_2_20:
    out_targets_2_20.loc[jump_ts + 0.05, :] = np.nan

out_targets_2_14.sort_index(inplace=True)
out_targets_2_20.sort_index(inplace=True)

rt_data = rt_data.loc[rt_data.index > 12660, :]

rt_ts_mask = np.full(rt_data.shape[0], False)
rt_ts = rt_data.index.to_numpy()

for (min_ts, max_ts) in min_max_ts:
    within_ts = (min_ts < rt_ts) & (rt_ts < max_ts)
    rt_ts_mask[within_ts] = True

rt_data = rt_data.loc[rt_ts_mask, :]
scan_index_jumps_rt = rt_data.index[np.where(np.diff(rt_data.index) > 5)[0]]
for jump_ts in scan_index_jumps_rt:
    rt_data.loc[jump_ts + 0.05, :] = np.nan
rt_data.sort_index(inplace=True)

get_ref_point_pos_for_rt_range(rt_data, 0.0, 0.5, 1.0, 0.0)
get_ref_point_pos_for_target(out_targets_2_14, 1.0, 0.0)
get_ref_point_pos_for_target(out_targets_2_20, 1.0, 0.0)

index_sync = rt_data.index.to_numpy() + 0.3
rt_sync = rt_data.copy()
rt_sync.index = index_sync

plots_info = [
    # plot name                                 signal_to_compare               # unit
    ('Reference point longitudinal position',   'position_x',                   '[m]'),
    ('Reference point lateral position',        'position_y',                   '[m]'),
    ('Bounding box center longitudinal position', 'center_x',                   '[m]'),
    ('Bounding box center lateral position',     'center_y',                    '[m]'),
    ('Absolute velocity longitudinal',          'velocity_otg_x',               '[m/s]'),
    ('Absolute velocity lateral',               'velocity_otg_y',               '[m/s]'),
    ('Speed',                                   'speed',                        '[m/s]'),
    ('Bounding box longitudinal dimension',     'bounding_box_dimensions_x',    '[m]'),
    ('Bounding box lateral dimension',          'bounding_box_dimensions_y',    '[m]'),
    ('Bounding box orientation',                'bounding_box_orientation_deg', '[deg]'),
    ('Absolute velocity lateral variance',     'velocity_otg_variance_y',      '[(m/s)^2]')
]

for plot_info in plots_info:
    plot_title, signal_to_compare, unit = plot_info
    plot_signal_compare(out_targets_2_14, out_targets_2_20, rt_sync, 'tracker core 2.14', 'tracker core 2.20', 'rt range',
                        plot_title, signal_to_compare, unit, 'time [s]')

#plot_rt_traces(rt_data)

rt_data = synchronize_rt_2_tracker(rt_data, out_targets_2_20)
rt_extracted = ExtractedData()
rt_extracted.objects = RtObjects()
rt_extracted.objects.signals = rt_data
pickle_save_path = r'C:\logs\BYK-632_DEX-696\DEX_969_rt_range_3000_dvl_extracted.pickle'
save_to_pkl(rt_extracted, pickle_save_path)
