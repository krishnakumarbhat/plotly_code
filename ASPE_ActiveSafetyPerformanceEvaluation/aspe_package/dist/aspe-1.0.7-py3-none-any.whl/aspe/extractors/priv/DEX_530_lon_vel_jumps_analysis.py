from aspe.utilities.SupportingFunctions import load_from_pkl, save_to_pkl
import matplotlib.pyplot as plt

if __name__ == '__main__':
    data_path = "C:\logs\BYK-589_DEX-530\SRR_DEBUG\DEX_530_analysis_data.pickle"
    data = load_from_pkl(data_path)

    out_targets_2_14 = data['out_targets_2_14']
    out_targets_2_20 = data['out_targets_2_20']
    rt_data = data['rt_data']

    ts = out_targets_2_20.index.to_numpy()
    vx = out_targets_2_20.velocity_otg_x.to_numpy()
    n_dets = out_targets_2_20.n_dets.to_numpy()
    f, ax = plt.subplots(nrows=2, sharex=True)

    ax[0].plot(ts, vx)
    ax[1].plot(ts, n_dets)

    ax[0].grid()
    ax[1].grid()

    ax[0].set_title('absolute velocity longitudinal')
    ax[1].set_title('number of associated detections')