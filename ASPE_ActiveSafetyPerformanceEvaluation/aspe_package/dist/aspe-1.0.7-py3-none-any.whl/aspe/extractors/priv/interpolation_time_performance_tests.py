from aspe.extractors.API.mdf import extract_f360_bmw_mid_from_mf4, extract_f360_bmw_mid_from_mf4_folder, mdf_parser
from aspe.utilities.SupportingFunctions import save_to_pkl
from srr5_dev_tools.mgp_module import load
from pathlib import Path
import numpy as np
import cProfile, pstats
from io import StringIO

log_path = r"C:\logs\BMW_A410_ATS_3\BN_FASETH\A410_MID_ECU_5_0_6_SENS_3_16_5_check_BN_FASETH_WBAUZ35090N005943_20200727_141836_fas_0000.MF4"

extr = extract_f360_bmw_mid_from_mf4(log_path, raw_signals=True, sw_version='A410', save_to_file=True)

obj = extr.objects
ts = obj.signals.timestamp.to_numpy()
ts_sorted = np.sort(np.unique(ts))
beg_ts, end_ts = ts_sorted[0], ts_sorted[-1]
ts_to_interp = np.linspace(beg_ts, end_ts, 500)
new_scan_indexes = np.arange(500)


pr = cProfile.Profile()
pr.enable()

obj.interpolate_values(ts_to_interp, new_scan_indexes)

pr.disable()
s = StringIO()
ps = pstats.Stats(pr, stream=s).sort_stats('cumulative')
ps.print_stats()
print(s.getvalue())
