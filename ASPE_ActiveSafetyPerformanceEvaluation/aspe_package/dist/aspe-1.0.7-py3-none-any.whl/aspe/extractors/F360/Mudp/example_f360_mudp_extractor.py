# coding=utf-8
"""
File with examples for F360 mudp files.
"""
from aspe.extractors.F360.Mudp.F360MUDPExtractor import F360MUDPExtractor
from aspe.utilities.SupportingFunctions import save_to_pkl
from aspe.parsers import MudpParser
from time import time


def example_from_mudp(mudp_log_path):
    """
    Basic example with direct mudp input file.
    Getting raw mudp file, parsing and generating extracted data
    :param mudp_log_path: path to mudp file
    :return: Extracted Data
    """
    mudp_parser_config_path = r'\\10.224.186.68\AD-Shared\F360\Logs\AIT-646_RNA_Basic_KPI_report\2_FTP\full_loop\SW201_SUV_V1\LSS\aspe.extractors_refactoring\parsers_config\mudp_data_parser_config.json'
    mudp_stream_def_path = r'\\10.224.186.68\AD-Shared\ASPE\configurations\F360\MUDP_Stream_Definitions\stream_definitions'

    save_path = mudp_log_path.replace('.mudp', '_MUDP_Extracted.pickle')

    # Parsing
    parser = MudpParser.MudpHandler(mudp_log_path, mudp_parser_config_path, mudp_stream_def_path)
    parsed_data = parser.decode()
    parser.save_to_pickle()

    # Extracting
    t1 = time()
    f360_extractor_object = F360MUDPExtractor()
    f360_extracted_data = f360_extractor_object.extract_data(parsed_data)
    t2 = time()
    print('Extraction: ', t2 - t1)
    save_to_pkl(f360_extracted_data, save_path)

    return f360_extracted_data


if __name__ == "__main__":
    mudp_log_path = r'\\10.224.186.68\AD-Shared\F360\Logs\Golden_Set_For_Refactoring\PSA\rRf360t4000304v202r1p50_AIT_1057_B\PSA_20180613_152933_003_rRf360t4000304v202r1p50_AIT_1057_B.mudp'
    extracted_data = example_from_mudp(mudp_log_path)
