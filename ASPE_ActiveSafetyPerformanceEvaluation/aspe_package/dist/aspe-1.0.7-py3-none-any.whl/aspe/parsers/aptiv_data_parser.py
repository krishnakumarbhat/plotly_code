"""
aptiv_data_parsers.py
====================================
"""


from abc import ABC, abstractmethod


class DataParser(ABC):
    """
    Initialize parser with parameters needed for file decode.
    (All parsers has same high level interface.)

    :param path: path to file: r''.
    :type path: str.
    :param configuration: path to configuration file: r''.
    :type configuration: str.
    """

    @abstractmethod
    def __init__(self, *args, **kwargs):
        """
        Initialize parser with parameters needed for file decode.
        """
        pass

    @abstractmethod
    def parse(self, log_file_path: str):
        """
        This is main data parser function; it converts data to basic human readable form; fills self.decoded
        """
        pass
