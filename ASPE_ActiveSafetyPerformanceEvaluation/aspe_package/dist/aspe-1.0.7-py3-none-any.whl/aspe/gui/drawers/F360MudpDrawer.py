from aspe.gui.drawers.DrawersFactory import DrawersFactory
from aspe.gui.drawers.abstract_drawers.DrawerExtractedData import DrawerExtractedData
import numpy as np


class F360MudpDrawer(DrawerExtractedData):
    def __init__(self, name, drawers_controller, data_model):
        calc_dets_azimuth_vcs(data_model.extracted)
        super().__init__(name, drawers_controller, data_model)

    def create_drawers(self):
        drawers = []
        if self.data_model.extracted.objects is not None and self.data_model.extracted.detections is not None:
            det_to_objs = get_det_associated_to_objs(self.data_model)
            drawers.append(DrawersFactory.create_det_to_obj_association_drawer(self, det_to_objs, 'DetToObjAssoc'))
        if self.data_model.extracted.host is not None:
            drawers.append(DrawersFactory.create_host_drawer(self, self.data_model.extracted.host, 'Host'))
        if self.data_model.extracted.objects is not None:
            drawers.append(DrawersFactory.create_objects_drawer(self, self.data_model.extracted.objects, 'ReducedObjects'))
        if self.data_model.extracted.internal_objects is not None:
            drawers.append(DrawersFactory.create_internal_objects_drawer(self, self.data_model.extracted.internal_objects, 'AllObjects'))
        if self.data_model.extracted.detections is not None:
            drawers.append(DrawersFactory.create_detection_drawer(self, self.data_model.extracted.detections, 'Detections',
                                                                  'range_rate_comp', 'azimuth_vcs'))
        if self.data_model.extracted.oal_objects is not None:
            drawers.append(DrawersFactory.create_objects_drawer(self, self.data_model.extracted.oal_objects, 'OALObjects'))
        if hasattr(self.data_model.extracted, 'gdsr_output') and self.data_model.extracted.gdsr_output is not None:
            drawers.append(DrawersFactory.create_objects_drawer(self, self.data_model.extracted.gdsr_output, 'GdsrOutput'))
        #if self.data_model.extracted.sensors is not None:
        #    drawers.append(DrawersFactory.create_sensors_fov_drawer(self, self.data_model.extracted.sensors, 'SensorsFov'))
        return drawers


def get_det_associated_to_objs(data_model):
    det_signals = data_model.extracted.detections.signals.set_index(['scan_index', 'assigned_obj_id']).loc[:, ['position_x', 'position_y']]
    obj_signals = data_model.extracted.objects.signals.set_index(['scan_index', 'tracker_id']).loc[:, ['position_x', 'position_y']]

    det_signals.index.names = [None, None]
    obj_signals.index.names = [None, None]

    merged = obj_signals.join(det_signals, how='inner', lsuffix='_obj', rsuffix='_det')
    return merged


def calc_dets_azimuth_vcs(extracted_data):
    if extracted_data.detections is not None:
        dets = extracted_data.detections.signals
        if extracted_data.sensors is not None:
            sensors = extracted_data.sensors.per_sensor
            dets_w_sensors = dets.join(sensors.set_index('sensor_id'), on='sensor_id', rsuffix='_sensor')
            dets['azimuth_vcs'] = dets_w_sensors.azimuth + dets_w_sensors.boresight_az_angle
        else:
            dets['azimuth_vcs'] = np.arctan2(dets['position_y'], dets['position_x'])