# coding=utf-8
"""
Rt Host Data Set interface
"""
from typing import Optional

import pandas as pd
from aspe.extractors.Interfaces.IHost import IHost


class RtHost(IHost):
    """
    Rt Host dataset interface class
    """
    def __init__(self):
        super().__init__()
        signal_names = [
            'utc_timestamp',
            'host_wcs_pointing_angle',
        ]
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=signal_names)], sort=False)
        self.bounding_box_dimensions_y: Optional[float] = None
        self.bounding_box_dimensions_x: Optional[float] = None
