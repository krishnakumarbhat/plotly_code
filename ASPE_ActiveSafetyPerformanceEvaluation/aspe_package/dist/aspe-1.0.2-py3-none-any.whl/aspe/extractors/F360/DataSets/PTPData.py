# coding=utf-8
"""
F360 Tracker Info Data Set
"""
import pandas as pd
from aspe.extractors.Interfaces.IDataSet import IDataSet


class PTPData(IDataSet):
    """
    F360 Tracker Info data set class
    """
    def __init__(self):
        super().__init__()
        signal_names = {
            'vigem_timestamp': float,
            'ethernet_timestamp': float,
            'vigem_to_global_time_diff': float
        }
        signals_info_local = pd.DataFrame({'signal_name': list(signal_names.keys()),
                                           'signal_type': list(signal_names.values())})
        self.signals_info = self.signals_info.append(signals_info_local)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=list(signal_names.keys()))], sort=False)

        self.vigem_to_global_time_diff_median = None
        self.vigem_to_global_time_diff_spread = None

    def interpolate_values(self, new_timestamp_vals, new_scan_index_vals, timestamp_signal_name='timestamp'):
        pass

    def get_base_name(self):
        """
        TODO: consider instance.__class__.__name__? should we overload str() function to get this? CEA-243
        Get Tracker Info base name
        :return: tracker info base name
        """
        return 'PTPData'
