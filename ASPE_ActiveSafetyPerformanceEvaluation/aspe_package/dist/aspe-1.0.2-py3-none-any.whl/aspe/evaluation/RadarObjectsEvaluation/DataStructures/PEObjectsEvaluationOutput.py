import pickle
import pandas as pd
import numpy as np
from aspe.extractors.Interfaces.IHost import IHost
from aspe.extractors.Interfaces.IObjects import IObjects
from aspe.extractors.Interfaces.IRadarSensors import IRadarSensors
from aspe.evaluation.RadarObjectsEvaluation.DataStructures.PEPairedObjects import PEPairedObjects
from aspe.evaluation.RadarObjectsEvaluation.DataStructures.PESingleObjects import PESingleObjects


class PEObjectsEvaluationOutputSingleLog:
    def __init__(self,
                 extr_est_objs=IObjects(),
                 extr_ref_objs=IObjects(),
                 extr_ref_host=IHost(),
                 extr_radar_sensors=IRadarSensors(),
                 paired_objs=PEPairedObjects(),
                 est_objs_results=PESingleObjects(),
                 ref_objs_results=PESingleObjects(),
                 pairs_lifetime_features=pd.DataFrame(),
                 objects_kpis_per_log=pd.DataFrame(),
                 pairs_kpis_per_log=pd.DataFrame(),
                 pairs_lifetime_kpis_per_log=pd.DataFrame(),
                 logs_features=pd.DataFrame()):
        self.extracted_estimated_objects = extr_est_objs
        self.extracted_reference_objects = extr_ref_objs
        self.extracted_reference_host = extr_ref_host
        self.extracted_radar_sensors = extr_radar_sensors

        self.pe_results_obj_pairs = paired_objs
        self.pe_results_obj_est = est_objs_results
        self.pe_results_obj_ref = ref_objs_results
        self.pe_results_pairs_lifetime_features = pairs_lifetime_features

        self.kpis_binary_class_per_log = objects_kpis_per_log
        self.kpis_pairs_features_per_log = pairs_kpis_per_log
        self.kpis_pairs_lifetime_per_log = pairs_lifetime_kpis_per_log

        self.logs_features_per_log = logs_features

    def print_kpis_and_log_features(self):
        print('\nSingle log results:')
        print('\nAssociated pairs KPIs:')
        print(self.kpis_pairs_features_per_log.to_string())
        print('\n')
        print(self.kpis_pairs_lifetime_per_log.to_string())
        print('\nObjects features KPIs:')
        print(self.kpis_binary_class_per_log.to_string())
        print('\nLog features:')
        print(self.logs_features_per_log.to_string())

    def save_to_pickle(self, pickle_path):
        with open(pickle_path, 'wb') as f:
            pickle.dump(self, f)


class PEObjectsEvaluationOutputMultiLog(PEObjectsEvaluationOutputSingleLog):
    def __init__(self):
        super().__init__(extr_est_objs=IObjects(),
                         extr_ref_objs=IObjects(),
                         extr_ref_host=IHost(),
                         extr_radar_sensors=IRadarSensors(),
                         paired_objs=PEPairedObjects(),
                         est_objs_results=PESingleObjects(),
                         ref_objs_results=PESingleObjects(),
                         objects_kpis_per_log=pd.DataFrame(),
                         pairs_kpis_per_log=pd.DataFrame(),
                         logs_features=pd.DataFrame())

        self.logs_paths = pd.DataFrame()
        self.kpis_binary_class_aggregated = pd.DataFrame()
        self.kpis_pairs_features_aggregated = pd.DataFrame()
        self.kpis_pairs_lifetime_aggregated = pd.DataFrame()
        self.logs_features_aggregated = pd.DataFrame()
        self.logs_count = 0

    def update(self, log_path: str, single_log_results: PEObjectsEvaluationOutputSingleLog):
        # TODO handle sensor properties aggregation - DFT-94
        self.logs_paths = self.logs_paths.append({'log_index': self.logs_count, 'log_path': log_path}, ignore_index=True, sort=False)

        self._increment_log_index_for_single_results(single_log_results)
        self.extracted_estimated_objects.signals = self.extracted_estimated_objects.signals.append(single_log_results.extracted_estimated_objects.signals, sort=False)
        self.extracted_reference_objects.signals = self.extracted_reference_objects.signals.append(single_log_results.extracted_reference_objects.signals, sort=False)
        if single_log_results.extracted_reference_host is not None:
            self.extracted_reference_host.signals = self.extracted_reference_host.signals.append(single_log_results.extracted_reference_host.signals, sort=False)
        if single_log_results.extracted_radar_sensors is not None:
            self.extracted_radar_sensors.signals = self.extracted_radar_sensors.signals.append(single_log_results.extracted_radar_sensors.signals, sort=False)

        obj_est_len = len(self.pe_results_obj_est.signals)
        obj_ref_len = len(self.pe_results_obj_ref.signals)
        single_log_results.pe_results_obj_pairs.signals.loc[:, 'index_est'] += obj_est_len
        single_log_results.pe_results_obj_pairs.signals.loc[:, 'index_ref'] += obj_ref_len

        self.pe_results_obj_pairs.signals = self.pe_results_obj_pairs.signals.append(single_log_results.pe_results_obj_pairs.signals, sort=False)
        self.pe_results_obj_est.signals = self.pe_results_obj_est.signals.append(single_log_results.pe_results_obj_est.signals, sort=False)
        self.pe_results_obj_ref.signals = self.pe_results_obj_ref.signals.append(single_log_results.pe_results_obj_ref.signals, sort=False)

        self.pe_results_pairs_lifetime_features = self.pe_results_pairs_lifetime_features.append(single_log_results.pe_results_pairs_lifetime_features, sort=False)
        self.kpis_binary_class_per_log = self.kpis_binary_class_per_log.append(single_log_results.kpis_binary_class_per_log, sort=False)
        self.kpis_pairs_features_per_log = self.kpis_pairs_features_per_log.append(single_log_results.kpis_pairs_features_per_log, sort=False)
        self.kpis_pairs_lifetime_per_log = self.kpis_pairs_lifetime_per_log.append(single_log_results.kpis_pairs_lifetime_per_log, sort=False)
        self.logs_features_per_log = self.logs_features_per_log.append(single_log_results.logs_features_per_log, sort=False)
        self._reset_indexes()

    def _reset_indexes(self):
        self.logs_paths.reset_index(drop=True)
        self.extracted_estimated_objects.signals.reset_index(inplace=True, drop=True)
        self.extracted_reference_objects.signals.reset_index(inplace=True, drop=True)
        self.extracted_reference_host.signals.reset_index(inplace=True, drop=True)
        self.extracted_radar_sensors.signals.reset_index(inplace=True, drop=True)
        self.pe_results_obj_pairs.signals.reset_index(inplace=True, drop=True)
        self.pe_results_obj_est.signals.reset_index(inplace=True, drop=True)
        self.pe_results_obj_ref.signals.reset_index(inplace=True, drop=True)
        self.pe_results_pairs_lifetime_features.reset_index(inplace=True, drop=True)
        self.kpis_binary_class_per_log.reset_index(inplace=True, drop=True)
        self.kpis_pairs_features_per_log.reset_index(inplace=True, drop=True)
        self.kpis_pairs_lifetime_per_log.reset_index(inplace=True, drop=True)
        self.logs_features_per_log.reset_index(inplace=True, drop=True)

    def _increment_log_index_for_single_results(self, single_log_results):
        single_log_results.extracted_estimated_objects.signals['log_index'] = self.logs_count
        single_log_results.extracted_reference_objects.signals['log_index'] = self.logs_count
        if single_log_results.extracted_reference_host is not None:
            single_log_results.extracted_reference_host.signals['log_index'] = self.logs_count
        if single_log_results.extracted_radar_sensors is not None:
            single_log_results.extracted_radar_sensors.signals['log_index'] = self.logs_count

        single_log_results.pe_results_obj_pairs.signals['log_index'] = self.logs_count
        single_log_results.pe_results_obj_est.signals['log_index'] = self.logs_count
        single_log_results.pe_results_obj_ref.signals['log_index'] = self.logs_count
        single_log_results.pe_results_pairs_lifetime_features['log_index'] = self.logs_count

        single_log_results.kpis_binary_class_per_log['log_index'] = self.logs_count
        single_log_results.kpis_pairs_features_per_log['log_index'] = self.logs_count
        single_log_results.kpis_pairs_lifetime_per_log['log_index'] = self.logs_count

        single_log_results.logs_features_per_log['log_index'] = self.logs_count
        self.logs_count = self.logs_count + 1

    def print_kpis_and_log_features(self):
        print(f'\nAggregated KPIs from {self.logs_count} logs:\n')
        print('Associated pairs KPIs:')
        print(self.kpis_pairs_features_aggregated.to_string())
        print('\n')
        print(self.kpis_pairs_lifetime_aggregated.to_string())
        print('\nObjects features KPIs:')
        print(self.kpis_binary_class_aggregated.to_string())
        print('\nLogs features:')
        print(self.logs_features_aggregated.to_string())
