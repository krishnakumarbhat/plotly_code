from aspe.extractors.Interfaces.IDataSet import IDataSet
import pandas as pd


class PEPairedObjects(IDataSet):
    '''
    Class which stores tracker objects evaluation results for associated tracks. Each row contains information about
    associated objects pair - reference object to estimated objects - signals and deviations between them.
    '''

    def __init__(self):
        super().__init__()
        signal_names = ['index_ref',
                        'index_est',

                        'unique_id_ref',
                        'unique_id_est',

                        'relevancy_flag_ref',
                        'relevancy_flag_est',

                        'association_distance',
                        'is_associated',

                        'binary_classification',
                        ]
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=signal_names)], sort=False)

    def get_base_name(self):
        return 'PEObjectPairs'
