from .deviation import *
from .nees import *

DEFAULT_PAIRS_FEATURES_LIST = [
    PositionDeviationR2R(),
    SpeedDeviation(),
    OrientationDeviation(),
    VelocityDeviationR2R(),
    VelocityRelativeDeviationR2R(),
    AccelerationDeviationR2R(),
    AccelerationRelativeDeviationR2R(),
    DimensionsDeviation(),
    YawRateDeviation()
    ]

EXTENDED_PAIRS_FEATURES_LIST = [
    *DEFAULT_PAIRS_FEATURES_LIST,
    PositionNeesValuesR2R(),
    VelocityNeesValuesR2R(),
]

C2C_DEVIATION_METHOD_LIST = [
    PositionDeviationC2C(),
    ]

R2R_DEVIATION_METHOD_LIST = [
    PositionDeviationR2R(),
    VelocityDeviationR2R(),
    ]
