from PyQt5.QtGui import QColor
from aspe.gui.drawers.DrawerLabels import DrawerLabels
from aspe.gui.drawers.abstract_drawers.DrawerComposite import DrawerComposite
from aspe.gui.drawers.DrawerBBoxes import DrawerBBoxes
from aspe.gui.drawers.DrawerPoints import DrawerPoints
from aspe.gui.drawers.DrawerVelocity import DrawerVelocity


class DrawerObjects(DrawerComposite):
    def __init__(self, parent, extracted_data_set, plot_item, name):
        super().__init__(parent, extracted_data_set, plot_item, name)

    def create_selection_drawer(self, plot_item):
        return DrawerBBoxes(self, 'ObjectSelection', plot_item, color=QColor(255, 0, 0), line_style='--', line_width=2)

    def create_drawers(self, plot_item):
        reference_points_drawer = DrawerPoints(self, 'Centroid', plot_item, symbol='d', color=QColor(128, 128, 128), symbol_size=8)
        bounding_boxes_drawer = DrawerBBoxes(self, 'BBox', plot_item, color=QColor(0, 128, 128), line_style='-', line_width=3)
        velocities_drawer = DrawerVelocity(self, 'Velocity', plot_item, color=QColor(50, 100, 200), line_style='-', line_width=1)
        label_drawer = DrawerLabels(self, 'Labels', plot_item, color=QColor(100, 100, 200))

        bounding_boxes_drawer.set_data(self.data_set.signals, 'center_x', 'center_y', 'bounding_box_orientation', 'bounding_box_dimensions_x', 'bounding_box_dimensions_y')
        reference_points_drawer.set_data(self.data_set.signals, 'position_x', 'position_y')
        velocities_drawer.set_data(self.data_set.signals, 'position_x', 'position_y', 'velocity_otg_x', 'velocity_otg_y')
        label_drawer.set_data(self.data_set.signals, self.data_set.raw_signals, 'position_x', 'position_y')

        return [bounding_boxes_drawer, reference_points_drawer, velocities_drawer, label_drawer]

    def select(self, df_index):
        selected_row = self.data_set.signals.loc[df_index, :]
        if not self.selected_unique_id == selected_row.unique_id:
            self.selected_unique_id = selected_row.unique_id
            selected_df = self.data_set.signals.loc[self.data_set.signals.loc[:, 'unique_id'] == self.selected_unique_id, :]
            if self.data_set.raw_signals is not None:
                raw_df = self.data_set.raw_signals.loc[selected_df.index, :]
                selected_df = selected_df.join(raw_df, rsuffix='_raw')
            self.selected_data = selected_df
            self.selection_drawer.set_data(selected_df, 'center_x', 'center_y', 'bounding_box_orientation',
                                           'bounding_box_dimensions_x', 'bounding_box_dimensions_y')
            self.selection_drawer.plot_scan_index(self.current_scan_index)
            self.parent.on_select(self)
        else:
            self.deselect()

