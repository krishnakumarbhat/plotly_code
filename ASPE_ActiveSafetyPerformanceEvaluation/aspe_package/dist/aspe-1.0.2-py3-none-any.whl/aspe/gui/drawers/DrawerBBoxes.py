from aspe.gui.drawers.DrawerLines import DrawerLines
import pyqtgraph as pg
import numpy as np
from aspe.gui.utilities.calc_bbox_corners import calc_bbox_corners, flatten_single_scan_corners_data


class DrawerBBoxes(DrawerLines):
    def __init__(self, parent, name: str, plot_item: pg.PlotItem, color: tuple, line_style: str, line_width: float):
        super().__init__(parent, name, plot_item, color, line_style, line_width)
        self.line_points = 5

    def set_data(self, data_df, center_x_signature, center_y_signature, orientation_signature, length_signature, width_signature):
        corners = calc_bbox_corners(data_df.loc[:, center_x_signature], data_df.loc[:, center_y_signature],
                                    data_df.loc[:, orientation_signature],
                                    data_df.loc[:, length_signature], data_df.loc[:, width_signature])
        corners['scan_index'] = data_df.loc[:, 'scan_index']
        for scan_index, scan_df in corners.groupby(by='scan_index'):
            x_corners, y_corners, df_indexes_flat = flatten_single_scan_corners_data(scan_df)
            self.x_data[scan_index] = x_corners.astype(np.float32)
            self.y_data[scan_index] = y_corners.astype(np.float32)
            nan_mask = np.isnan(x_corners.astype(np.float32))
            connect_mask = ~(nan_mask | np.roll(nan_mask, -1))
            self.is_visible[scan_index] = connect_mask
            self.df_indexes[scan_index] = df_indexes_flat
