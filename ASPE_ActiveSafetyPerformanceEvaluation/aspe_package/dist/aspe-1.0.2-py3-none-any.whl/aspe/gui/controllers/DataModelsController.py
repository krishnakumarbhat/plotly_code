from aspe.utilities.SupportingFunctions import load_from_pkl
from aspe.gui.models.DataModel import DataModel


class DataModelsManager:
    def __init__(self):
        self.data_models = []

    def load_data_using_source_info(self, source_info):
        extracted = load_from_pkl(source_info.pickle_path)
        data_model = DataModel(extracted, source_info)
        self.data_models.append(data_model)
        return data_model

    def get_model_using_source_info(self, source_info):
        for data_model in self.data_models:
            if data_model.source_info == source_info:
                return data_model
