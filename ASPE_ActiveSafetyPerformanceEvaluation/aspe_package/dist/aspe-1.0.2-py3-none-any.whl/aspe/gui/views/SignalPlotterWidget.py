from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.Qt import QColor, QBrush
import pyqtgraph as pg
import math
import numpy as np

COLOR_PALETTE = [
    '#1f77b4',
    '#ff7f0e',
    '#2ca02c',
    '#d62728',
    '#9467bd',
    '#8c564b',
    '#e377c2',
    '#7f7f7f',
    '#bcbd22',
    '#17becf'
     ]


class SignalPlotterWidget(QtWidgets.QWidget):
    def __init__(self, controller, *args, **kwargs):
        super().__init__()
        self.controller = controller
        self.setupUi()
        self.graphic_win = pg.GraphicsWindow(parent=self)
        self.graphic_win.setBackground(pg.mkBrush(color=(255, 255, 255)))
        self.axes_vlayout.addWidget(self.graphic_win)
        self.axes = []
        self.scan_index_markers = []
        self.lines_count = 0
        self.default_lines_width = 2

    def setupUi(self):
        self.setObjectName("SignalPloterWidget")
        self.resize(1200, 400)
        self.horizontalLayout = QtWidgets.QHBoxLayout(self)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.axes_widget = QtWidgets.QWidget(self)
        self.axes_widget.setObjectName("axes_widget")
        self.axes_vlayout = QtWidgets.QVBoxLayout(self.axes_widget)
        self.axes_vlayout.setObjectName("axes_vlayout")
        self.horizontalLayout.addWidget(self.axes_widget)
        self.right_panel_widget = QtWidgets.QWidget(self)
        self.right_panel_widget.setObjectName("right_panel_widget")
        self.righ_panel_vlayout = QtWidgets.QVBoxLayout(self.right_panel_widget)
        self.righ_panel_vlayout.setObjectName("righ_panel_vlayout")
        self.signal_info_table = QtWidgets.QTableWidget(self.right_panel_widget)
        self.signal_info_table.setObjectName("signal_info_table")
        self.signal_info_table.setColumnCount(4)
        self.signal_info_table.setRowCount(0)
        item = QtWidgets.QTableWidgetItem()
        self.signal_info_table.setHorizontalHeaderItem(0, item)
        item = QtWidgets.QTableWidgetItem()
        self.signal_info_table.setHorizontalHeaderItem(1, item)
        item = QtWidgets.QTableWidgetItem()
        self.signal_info_table.setHorizontalHeaderItem(2, item)
        item = QtWidgets.QTableWidgetItem()
        self.signal_info_table.setHorizontalHeaderItem(3, item)
        self.signal_info_table.horizontalHeader().setDefaultSectionSize(100)
        self.signal_info_table.horizontalHeader().setMinimumSectionSize(10)
        self.signal_info_table.horizontalHeader().setStretchLastSection(True)
        self.righ_panel_vlayout.addWidget(self.signal_info_table)
        self.horizontalLayout.addWidget(self.right_panel_widget)
        self.horizontalLayout.setStretch(0, 8)
        self.horizontalLayout.setStretch(1, 5)

        self.retranslateUi()
        QtCore.QMetaObject.connectSlotsByName(self)

    def retranslateUi(self):
        _translate = QtCore.QCoreApplication.translate
        self.setWindowTitle("SignalPloter")
        item = self.signal_info_table.horizontalHeaderItem(0)
        item.setText("source")
        item = self.signal_info_table.horizontalHeaderItem(1)
        item.setText("data set")
        item = self.signal_info_table.horizontalHeaderItem(2)
        item.setText("signal signature")
        item = self.signal_info_table.horizontalHeaderItem(3)
        item.setText("value")

    def create_new_plot(self):
        current_axes_count = len(self.axes)
        ax = self.graphic_win.addPlot(row=current_axes_count, col=0)
        ax.showGrid(x=True, y=True, alpha=0.5)
        if len(self.axes) > 0:
            ax.setXLink(self.axes[0])
        infinity_line = pg.InfiniteLine(pen=pg.mkPen(color=(255, 0, 0), width=self.default_lines_width))
        ax.addItem(infinity_line)
        self.axes.append(ax)
        self.scan_index_markers.append(infinity_line)

    def plot_signal(self, source_signature, data_set_signature, selected_data, signal_to_plot_signature, axes_index):
        sorted_data = selected_data.sort_values(by='scan_index')
        x_signal = sorted_data.loc[:, 'scan_index'].to_numpy().copy()
        y_signal = sorted_data.loc[:, signal_to_plot_signature].to_numpy().copy()

        line_color = QColor(COLOR_PALETTE[self.lines_count % len(COLOR_PALETTE)])
        line_pen = pg.mkPen(color=line_color, width=self.default_lines_width)

        x_dif = np.diff(x_signal)
        x_jumps = np.append((x_dif != 1), [0])  # append cause diff returns n-1 shape

        nan_mask = np.isnan(y_signal.astype('float32'))
        y_signal[nan_mask] = 0.0

        self.axes[axes_index].plot(x=x_signal, y=y_signal, pen=line_pen, connect=~nan_mask & ~x_jumps)
        self.add_signal_legend_to_table(source_signature, data_set_signature, signal_to_plot_signature, line_color)
        self.lines_count += 1

    def update_scan_index_markers(self, scan_index):
        for inf_line in self.scan_index_markers:
            inf_line.setValue(scan_index)

    def add_signal_legend_to_table(self, source_signature, data_set_signature, signal_to_plot_signature, line_color):
        row_position = self.signal_info_table.rowCount()
        self.signal_info_table.insertRow(row_position)

        item_source = QtGui.QTableWidgetItem(source_signature)
        item_data_set = QtGui.QTableWidgetItem(data_set_signature)
        item_signal = QtGui.QTableWidgetItem(signal_to_plot_signature)

        item_source.setForeground(QBrush(line_color))
        item_signal.setForeground(QBrush(line_color))
        item_data_set.setForeground(QBrush(line_color))

        self.signal_info_table.setItem(row_position, 0, item_source)
        self.signal_info_table.setItem(row_position, 1, item_data_set)
        self.signal_info_table.setItem(row_position, 2, item_signal)

    def closeEvent(self, close_event):
        self.clear()
        self.close()
        self.controller.on_signal_plotter_widget_close()

    def clear(self):
        self.graphic_win.close()
        self.axes = []
        self.scan_index_markers = []
        self.lines_count = 0



