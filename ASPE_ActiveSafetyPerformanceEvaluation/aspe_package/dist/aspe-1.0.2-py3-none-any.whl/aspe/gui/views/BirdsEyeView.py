from pyqtgraph import GraphicsWindow, PlotWidget


class BirdsEyeView(PlotWidget):
    def __init__(self):
        super().__init__()
        self.disableAutoRange()
        self.showGrid(x=True, y=True, alpha=0.5)
        self.scene().sigMouseClicked.connect(self.on_sigMouseReleased)
        self.scene().setClickRadius(0.5)
        self.setXRange(-50, 50, padding=0)
        self.setYRange(-50, 50, padding=0)
        self.resizeEvent = self.resize_event

    def resize_event(self, ev):
        '''
        Handle fixed ratio of bird eye view
        :param ev:
        :return:
        '''
        super().resizeEvent(ev)  # call all stuff which is normally done while resizing
        width = self.size().width()
        height = self.size().height()

        size_ratio = width / height

        x_min, x_max = self.getAxis('bottom').range
        x_len = x_max - x_min

        expected_y_len = x_len / size_ratio
        y_min, y_max = self.getAxis('left').range
        y_center = y_min + (y_max - y_min)/2
        new_y_min, new_y_max = y_center - expected_y_len / 2, y_center + expected_y_len / 2
        self.setYRange(new_y_min, new_y_max)

    def on_sigMouseReleased(self, mouse_click_event):
        if hasattr(mouse_click_event.currentItem, 'drawer'):  # trick for handling clicking events, LinesDrawer and PointsDrawer classes
            mouse_click_event.currentItem.drawer.on_click(mouse_click_event)
