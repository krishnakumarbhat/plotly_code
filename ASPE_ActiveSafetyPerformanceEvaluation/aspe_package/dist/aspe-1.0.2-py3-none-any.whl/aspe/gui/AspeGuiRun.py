import sys
from PyQt5.QtWidgets import QApplication
from aspe.gui.views.AspeGuiMainWindowView import AspeGuiMainWindowView


def run_aspe_gui():
    app = QApplication(sys.argv)
    ui = AspeGuiMainWindowView()
    ui.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    run_aspe_gui()
