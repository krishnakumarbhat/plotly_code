from .IPairsFeature import IPairsFeature
from .default_pairs_features_lists import *
