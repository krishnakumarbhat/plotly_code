import numpy as np
import pandas as pd
import pyqtgraph as pg
import pyqtgraph.exporters
import imageio, os
from PyQt5.Qt import QFileDialog
from PIL import Image, ImageFont, ImageDraw
from aspe.utilities.SupportingFunctions import remove_suffix, get_dec_rgb

class GifCreator():
    def __init__(self, scan_exporter: pg.exporters):
        self.drawers_controller = None
        self.max_legend_font_size = 17
        self.max_title_font_size = 17
        self.legend_df = pd.DataFrame()
        self.temp_images_path = 'tmp_gif_images'
        self.scan_exporter = scan_exporter # ImageExporter from pyqtgraph.exporters
        self.scan_names = []
        self.clear_overdue_images()

    def save_plot_current_scan_index(self, scan_index, size):
        # Set images size as bird eye view dimensions
        width = size.width()
        height = size.height()
        self.scan_exporter.parameters()['width'] = width
        self.scan_exporter.parameters()['height'] = height
        # Set scan name as a image name
        scan_name = f'{self.temp_images_path}\\GIF_scan_{scan_index}.png'
        self.scan_exporter.export(scan_name)
        self.scan_names.append(scan_name)

    def create_gif(self, last_dir):
        self.legend_df, self.title_log_name = self.drawers_controller.get_legend()
        # Get path to the system fonts
        system_drive = os.getenv("SystemDrive")
        self.font_type = system_drive + '\Windows\Fonts\Arial.ttf'
        # Prepare legend parameters
        is_legend = self.legend_df.shape[0] != 0
        width = self.scan_exporter.parameters()['width']
        self.title_font_size = self.max_title_font_size
        self.legend_font_size = self.max_legend_font_size
        if is_legend:
            # Calculate legend font size
            row_pixels_to_use = width - 50  # gap between left end of the image and legend test is 25
            longest_log_name = max(self.legend_df['characters_per_legend_line'])
            character_width = row_pixels_to_use / longest_log_name
            legend_font_size = int(character_width * 1.5)  # height of the font is 1,5 times bigger than width
            if legend_font_size < self.max_legend_font_size:
                self.legend_font_size = legend_font_size
            legend_rows = self.legend_df.shape[0]
            # Calculate title font size
            if self.title_log_name: # check if string is empty
                name_length = len(self.title_log_name)
                character_width = row_pixels_to_use / name_length
                title_font_size = int(character_width * 1.5)
                if title_font_size < self.max_title_font_size:
                    self.title_font_size = title_font_size
        else:
            legend_rows = 0

        # Create image as 3D array | pixel as [0, 0, 0, 255] (r, g, b, alpha), 255 means fully opaque
        # This image is just a black background, it is additional space for legend which is added to scan image
        legend_additional_img_space = np.array([[[0 for i in range(4)] for j in range(width)] for k in range((legend_rows + 1) * (self.legend_font_size + 6))], dtype=np.uint8)
        legend_additional_img_space[:, :, 3] = 255
        title_additional_img_space = np.array([[[0 for i in range(4)] for j in range(width)] for k in range(2 * (self.title_font_size + 6))], dtype=np.uint8)
        title_additional_img_space[:, :, 3] = 255

        # Increase scan image size for legend placing
        for scan_name in self.scan_names:
            img = imageio.imread(scan_name)
            img = np.vstack([title_additional_img_space, img, legend_additional_img_space])
            imageio.imwrite(scan_name, img)
        self.add_title() # Adding title to each scan image
        if is_legend:
            self.add_legend() # Adding legend to each scan image
        # Connect scan images into one list
        gif_frames = []
        for scan_name in self.scan_names:
            img = imageio.imread(scan_name)
            gif_frames.append(img)
        save_path, filter = QFileDialog.getSaveFileName(directory=last_dir, filter='Gif files (*.gif)')
        if save_path:
            imageio.mimsave(save_path, gif_frames)
        # Clear used images
        for scan_name in self.scan_names:
            os.remove(scan_name)
        self.scan_names = []

    def add_title(self):
        # Displaying plo title and current scan index
        title_position = [25, 0]  # 25 is distance from the left end of image
        position_y_increase_value = self.title_font_size + 5
        title_font = ImageFont.truetype(self.font_type, self.title_font_size)
        for scan_name in self.scan_names:
            # add plot title
            title_position_buff = title_position.copy()
            img = Image.open(scan_name)
            draw = ImageDraw.Draw(img)
            text = self.title_log_name
            title_position_buff[0] = int((self.scan_exporter.parameters()['width'] - len(text) * (self.title_font_size / 1.5)) / 2)
            draw.text(title_position_buff, text, (255, 255, 255), font=title_font)
            # add current scan index under plot title
            current_scan_index = remove_suffix(scan_name.split('_')[-1])
            text = 'scan index: ' + current_scan_index
            title_position_buff[0] = int((self.scan_exporter.parameters()['width'] - len(text) * (self.title_font_size / 1.5)) / 2)
            title_position_buff[1] = title_position_buff[1] + position_y_increase_value
            draw.text(title_position_buff, text, (255, 255, 255), font=title_font)
            img.save(scan_name)

    def add_legend(self):
        # Displaying plot legend
        position_x_legend = 25  # 25 is distance from the left end of image
        position_y_increase_value = self.legend_font_size + 5 # 5 is pixels amount to create a gap between rows
        position_y_legend = self.scan_exporter.parameters()['height'] + (self.title_font_size + 5) * 2 # increase at the start due to legend title
        legend_position = [position_x_legend, position_y_legend]
        title_font = ImageFont.truetype(self.font_type, self.legend_font_size)
        for scan_name in self.scan_names:
            img = Image.open(scan_name)
            draw = ImageDraw.Draw(img)
            legend_position_buff = legend_position.copy()
            for idx, row in self.legend_df.iterrows():
                # add colored object symbol
                text = self.legend_df.loc[idx, 'style']
                r, g, b = get_dec_rgb(self.legend_df.loc[idx, 'color'])
                draw.text(legend_position_buff, text, (r, g, b), font=title_font)
                # add object description
                legend_position_buff[0] = legend_position_buff[0] + int(self.legend_font_size) * 2
                text = self.legend_df.loc[idx, 'log_nick_name'] + ' - ' + self.legend_df.loc[idx, 'drawer_name'] + ' - ' + self.legend_df.loc[idx, 'subdrawer_name']
                draw.text(legend_position_buff, text, (255, 255, 255), font=title_font)
                # change legend position for next row
                legend_position_buff[0] = position_x_legend
                legend_position_buff[1] = legend_position_buff[1] + position_y_increase_value
            img.save(scan_name)

    def clear_overdue_images(self):
        if os.path.isdir(self.temp_images_path):
            overdue_images = os.listdir(self.temp_images_path)
            for overdue_image in overdue_images:
                os.remove(f'{self.temp_images_path}\\{overdue_image}')