from aspe.gui.drawers.DrawerBinaryClassification import DrawerBinaryClassification
from aspe.gui.drawers.DrawerDetToObjAssociation import DrawerDetToObjAssociation
from aspe.gui.drawers.DrawerInternalObjects import DrawerInternalObjects
from aspe.gui.drawers.DrawerRefToEstAssociation import DrawerRefToEstAssociation
from aspe.gui.drawers.DrawerRelevancy import DrawerRelevancy
from aspe.gui.drawers.DrawerSensors import DrawerSensors
from aspe.gui.drawers.DrawerDetections import DrawerDetections
from aspe.gui.drawers.DrawerObjects import DrawerObjects
from aspe.gui.drawers.DrawerHost import DrawerHost
from aspe.gui.drawers.DrawerStaticEnvironment import DrawerStaticEnvironment
from aspe.gui.drawers.DrawerXtrkObjects import DrawerXtrkObjects
from aspe.gui.drawers.DrawerDetectionsClusters import DrawerDetectionsClusters
from aspe.gui.drawers.DrawerDetToClustersAssociation import DrawerDetToClustersAssociation


class DrawersFactory:
    birds_eye_view = None

    @staticmethod
    def create_objects_drawer(data_source, extracted_objects, name):
        drawer = DrawerObjects(data_source, extracted_objects, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_internal_objects_drawer(data_source, extracted_objects, name):
        drawer = DrawerInternalObjects(data_source, extracted_objects, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_xtrk_objects_drawer(data_source, extracted_objects, name):
        drawer = DrawerXtrkObjects(data_source, extracted_objects, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_detection_drawer(data_source, extracted_detections, name, rrate_signal_name, azimuth_signal_name):
        drawer = DrawerDetections(data_source, extracted_detections, DrawersFactory.birds_eye_view, name,
                                  rrate_signal_name, azimuth_signal_name)
        return drawer

    @staticmethod
    def create_host_drawer(data_source, extracted_host, name):
        drawer = DrawerHost(data_source, extracted_host, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_sensors_drawer(parent_drawer, extracted_sensors, name):
        drawer = DrawerSensors(parent_drawer, extracted_sensors, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_det_to_obj_association_drawer(parent_drawer, associations, name):
        drawer = DrawerDetToObjAssociation(parent_drawer, name, DrawersFactory.birds_eye_view, associations)
        return drawer

    @staticmethod
    def create_est_to_ref_association_drawer(parent_drawer, associations, name):
        drawer = DrawerRefToEstAssociation(parent_drawer, name, DrawersFactory.birds_eye_view, associations)
        return drawer

    @staticmethod
    def create_not_relevant_objs_drawer(parent_drawer, not_relevant_objs, name):
        drawer = DrawerRelevancy(parent_drawer, name, DrawersFactory.birds_eye_view, not_relevant_objs)
        return drawer

    @staticmethod
    def create_binary_classification_drawer(parent_drawer, binary_classification, name):
        drawer = DrawerBinaryClassification(parent_drawer, binary_classification, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_cluster_drawer(data_source, extracted_clusters, name, rrate_signal_name, azimuth_signal_name):
        drawer = DrawerDetectionsClusters(data_source, extracted_clusters, DrawersFactory.birds_eye_view, name, rrate_signal_name, azimuth_signal_name)
        return drawer

    @staticmethod
    def create_det_to_clusters_association_drawer(parent_drawer, associations, name):
        drawer = DrawerDetToClustersAssociation(parent_drawer, name, DrawersFactory.birds_eye_view, associations)
        return drawer

    @staticmethod
    def create_stat_env_drawer(parent_drawer, stat_env, name):
        drawer = DrawerStaticEnvironment(parent_drawer, stat_env, DrawersFactory.birds_eye_view, name)
        return drawer


