# coding=utf-8
"""
Interface for F360 MUDP sensors builders
"""
from abc import abstractmethod
import pandas as pd
from aspe.extractors.Mudp.IMudpBuilder import IMudpBuilder
from aspe.extractors.F360.DataSets.F360RadarSensors import F360RadarSensors


class IF360MudpSensorsBuilder(IMudpBuilder):
    """
    Sensors builder for F360 MUDP data.
    Version-specific builders should inherit from this class (e.g F360MudpSensorsBuilderV14).
    """
    def __init__(self, parsed_data, f_extract_raw_signals=False, f_reduced_sensor_stream=False):
        super().__init__(parsed_data, f_extract_raw_signals=f_extract_raw_signals)
        self.data_set = F360RadarSensors(f_reduced_sensor_stream)

    @abstractmethod
    def build(self):
        """
        Extracts signals and properties from parsed data into dataset.
        Version-specific builders (e.g F360MudpSensorsBuilderV14) should override this method.
        :return: filled (extracted) data set
        """
        return super().build()
