# coding=utf-8
"""
F360 Meta Data
"""
from aspe.extractors.Interfaces.IMetaData import IMetaData


class F360MetaData(IMetaData):
    """
    F360 Meta Data class
    """
    def __init__(self):
        super().__init__()
