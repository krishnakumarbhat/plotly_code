from aspe.extractors.Interfaces.IRadarSensors import IRadarSensors


class F360BmwRadarSensors(IRadarSensors):
    """
    BMW someIP radar sensors representation.
    """
    def __init__(self):
        super().__init__()

