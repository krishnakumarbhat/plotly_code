from aspe.extractors.Interfaces.IObjects import IObjects


class DspaceObjects(IObjects):
    def __init__(self):
        super().__init__()
