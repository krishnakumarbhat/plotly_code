from aspe.extractors.Interfaces.IMetaData import IMetaData


class DspaceMetadata(IMetaData):
    def __init__(self):
        super().__init__()
