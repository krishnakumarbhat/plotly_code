# coding=utf-8
"""
Rt MetaData interface
"""
from aspe.extractors.Interfaces.IMetaData import IMetaData


class RtMetaData(IMetaData):
    """
    Rt MetaData Class
    """
    def __init__(self):
        super().__init__()
