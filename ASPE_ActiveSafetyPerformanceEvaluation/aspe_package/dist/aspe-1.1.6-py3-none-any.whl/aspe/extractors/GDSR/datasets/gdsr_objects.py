from aspe.extractors.Interfaces.IObjects import IObjects


class GdsrObjects(IObjects):
    def __init__(self):
        super().__init__()
