from aspe.extractors.Interfaces.IMetaData import IMetaData


class GdsrMetadata(IMetaData):
    def __init__(self):
        super().__init__()
