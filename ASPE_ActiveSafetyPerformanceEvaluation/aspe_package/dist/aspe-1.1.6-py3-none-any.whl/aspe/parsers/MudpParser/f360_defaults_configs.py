from collections import defaultdict

streams_to_read = (3, 4, 5, 6, 7, 17, 19, 70, 71, 72, 99)

unknown_size_per_stream = defaultdict(lambda: 4)

source_to_parse = 35
