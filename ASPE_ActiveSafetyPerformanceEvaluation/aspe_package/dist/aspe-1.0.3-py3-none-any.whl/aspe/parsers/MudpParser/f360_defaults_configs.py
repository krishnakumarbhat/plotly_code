streams_to_read = (3, 4, 5, 6, 7, 33)

unknown_size_per_stream = {
    3: 4,
    4: 4,
    5: 4,
    6: 4,
    7: 4,
    8: 4,
    9: 4,
    10: 4,
    18: 4,
    21: 4,
    22: 4,
    23: 4,
    30: 4,
    33: 4
}

source_to_parse = 35
