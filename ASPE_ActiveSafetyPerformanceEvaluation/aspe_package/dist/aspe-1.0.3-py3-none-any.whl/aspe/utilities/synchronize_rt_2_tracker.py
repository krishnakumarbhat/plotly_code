import numpy as np
import pandas as pd


def synchronize_rt_2_tracker(rt_data, objects_data):
    rt_ts = rt_data.index.to_numpy() + 0.3
    tracker_ts = objects_data.index.to_numpy()

    corresponding_rt_indexes = []
    for scan_ts in tracker_ts:
        min_idx = np.abs(rt_ts - scan_ts).argmin()
        corresponding_rt_indexes.append(min_idx)

    rt_data_synch = rt_data.iloc[corresponding_rt_indexes, :]
    tracker_index = objects_data.scan_index.to_numpy()
    rt_data_synch.loc[:, 'scan_index'] = tracker_index
    return rt_data_synch