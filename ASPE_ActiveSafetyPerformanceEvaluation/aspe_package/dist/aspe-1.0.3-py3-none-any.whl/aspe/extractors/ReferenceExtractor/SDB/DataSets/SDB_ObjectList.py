from aspe.extractors.Interfaces.IObjects import IObjects
import pandas as pd


class SDB_ObjectList(IObjects):
    occlusion_signals = {
        'SRR5-FL_total_area':   float,
        'SRR5-FL_visible_area': float,
        'SRR5-FR_total_area':   float,
        'SRR5-FR_visible_area': float,
        'SRR5-RL_total_area':   float,
        'SRR5-RL_visible_area': float,
        'SRR5-RR_total_area':   float,
        'SRR5-RR_visible_area': float,
        'SRR5-CL_total_area':   float,
        'SRR5-CL_visible_area': float,
        'SRR5-CR_total_area':   float,
        'SRR5-CR_visible_area': float,
    }

    def __init__(self):
        super().__init__()

        signal_names = {
            'position_z':                float,
            'bounding_box_dimensions_z': float,
            'center_z':                  float,
            'velocity_otg_z':            float,
            'vigem_timestamp':           float,
        }
        signal_names.update(self.occlusion_signals)
        signals_info_local = pd.DataFrame({'signal_name': list(signal_names.keys()),
                                           'signal_type': list(signal_names.values())})
        self.signals_info = self.signals_info.append(signals_info_local)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=list(signal_names.keys()))], sort=False)
        self.signals_info.loc[self.signals_info.signal_name == 'id', 'signal_type'] = str

    def get_base_name(self):
        return 'object_list'
