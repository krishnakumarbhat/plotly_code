from aspe.extractors.Interfaces.IDataSet import IDataSet
import pandas as pd


class F360BmwObjectListHeader(IDataSet):
    def __init__(self):
        super().__init__()
        self.raw_signals = None
        signal_names = {
            'vigem_timestamp': float,
            'publish_time_in_global_domain': float,
            'system_latency': float
        }
        signals_info_local = pd.DataFrame({'signal_name': list(signal_names.keys()),
                                           'signal_type': list(signal_names.values())})
        self.signals_info = self.signals_info.append(signals_info_local)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=list(signal_names.keys()))], sort=False)

    def get_base_name(self):
        return 'object_list_header'
