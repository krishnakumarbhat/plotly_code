# coding=utf-8
"""
F360 Internal Objects Data Set
"""
from aspe.extractors.Interfaces.IObjects import IObjects
import pandas as pd
from enum import Enum


class F360InternalObjects(IObjects):
    """
    Class which represents f360 internal objects data. It extends basic objects data structure.
    """
    def __init__(self):
        super().__init__()
        signal_names = {
            'filter_type': Enum,
            'reduced_id': int,
            'status': Enum,
            'curvature': float,
            'confidence_level': float,
            'n_dets': int,
            'f_moving': bool,
            'f_moveable': bool
        }
            # TODO: CEA-148; due to disagreement of handling - skip this
            #'supplemental_state_covariance',
            #'state_variance'

        signals_info_local = pd.DataFrame({'signal_name': list(signal_names.keys()),
                                           'signal_type': list(signal_names.values())})
        self.signals_info = self.signals_info.append(signals_info_local)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=list(signal_names.keys()))], sort=False)

    def get_base_name(self):
        """
        Get base name of internal objects
        :return: str
        """
        return 'internal_objects'
