from aspe.extractors.Interfaces.ExtractedData import ExtractedData


class F360ExcelExtractedData(ExtractedData):
    def __init__(self):
        super().__init__()
