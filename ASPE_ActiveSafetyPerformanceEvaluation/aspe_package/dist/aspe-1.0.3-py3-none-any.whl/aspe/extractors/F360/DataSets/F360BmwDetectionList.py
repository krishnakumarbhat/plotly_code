from aspe.extractors.Interfaces.IRadarDetections import IRadarDetections
import pandas as pd


class F360BmwDetectionList(IRadarDetections):
    """
    BMW someIP detection list representation.
    """
    def __init__(self):
        super().__init__()
        signal_names = {
            'vigem_timestamp': bool
        }

        signals_info_local = pd.DataFrame({'signal_name': list(signal_names.keys()),
                                           'signal_type': list(signal_names.values())})
        self.signals_info = self.signals_info.append(signals_info_local)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=list(signal_names.keys()))], sort=False)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=signal_names)], sort=False)

    def get_base_name(self):
        return 'detection_list'
