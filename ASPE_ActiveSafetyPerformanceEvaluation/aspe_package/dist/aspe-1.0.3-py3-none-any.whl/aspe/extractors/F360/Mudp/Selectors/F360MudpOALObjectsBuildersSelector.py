# coding=utf-8
"""
F360 MUDP objects builder selector
"""
from aspe.extractors.F360.Mudp.Builders.OAL.F360MudpOALObjectsBuilderV4 import F360MudpOALObjectsBuilderV4
from aspe.extractors.Mudp.IMudpBuilderSelector import IMudpBuilderSelector


class F360MudpOALObjectsBuilderSelector(IMudpBuilderSelector):
    """
    Output Adaptation Layer objects builder selector for F360 MUDP data.
    """
    required_stream_numbers = {33}

    available_builders = (
        F360MudpOALObjectsBuilderV4,
    )
