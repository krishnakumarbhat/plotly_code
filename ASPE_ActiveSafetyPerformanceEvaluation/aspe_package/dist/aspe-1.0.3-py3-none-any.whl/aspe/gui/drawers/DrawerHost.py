from PyQt5.QtGui import QColor
from aspe.gui.drawers.abstract_drawers.DrawerComposite import DrawerComposite
from aspe.gui.drawers.DrawerBBoxes import DrawerBBoxes
from aspe.gui.drawers.DrawerHostBBox import DrawerHostBBox
from aspe.gui.drawers.DrawerVelocity import DrawerVelocity
import math


class DrawerHost(DrawerComposite):
    def __init__(self, parent, extracted_data_set, plot_item, name):
        super().__init__(parent, extracted_data_set, plot_item, name)
        self.data_set.signals['center_x'] = -2.5
        self.data_set.signals['center_y'] = 0.0
        self.data_set.signals['bounding_box_orientation'] = 0.0
        self.data_set.signals['bounding_box_dimensions_x'] = 5.0
        self.data_set.signals['bounding_box_dimensions_y'] = 2.5

    def create_selection_drawer(self, plot_item):
        return DrawerBBoxes(self, 'HostSelection', plot_item, color=QColor(255, 0, 0), line_style='--', line_width=2)

    def create_drawers(self, plot_item):
        host_bbox = DrawerHostBBox(self, 'BBox', plot_item, color=QColor(0, 128, 128))
        velocities_drawer = DrawerVelocity(self, 'Velocity', plot_item, color=QColor(50, 100, 200), line_style='-', line_width=1)
        width = self.data_set.bounding_box_dimensions_x
        length = self.data_set.bounding_box_dimensions_y
        if math.isnan(width): width = 2.0  # TODO this should be handled by extractor
        if math.isnan(length): length = 5.0

        host_bbox.set_data(self.data_set.signals, 'position_x', 'position_y', length, width)
        velocities_drawer.set_data(self.data_set.signals, 'position_x', 'position_y', 'velocity_otg_x', 'velocity_otg_y')
        return [velocities_drawer, host_bbox]

    def on_click(self, clicked_drawer, click_event):
        if clicked_drawer is self.selection_drawer:
            self.deselect()
        else:
            selected_df_index = self.data_set.signals.loc[self.data_set.signals.loc[:, 'scan_index'] == self.current_scan_index, :].index[0]
            if selected_df_index is not None:
                self.select(selected_df_index)

    def select(self, df_index):
        selected_row = self.data_set.signals.loc[df_index]
        if not self.selected_unique_id == selected_row.unique_id:
            self.selected_unique_id = selected_row.unique_id
            selected_df = self.data_set.signals.loc[self.data_set.signals.loc[:, 'unique_id'] == self.selected_unique_id, :]
            self.selected_data = selected_df
            self.selection_drawer.set_data(selected_df, 'center_x', 'center_y', 'bounding_box_orientation',
                                           'bounding_box_dimensions_x', 'bounding_box_dimensions_y')
            self.selection_drawer.plot_scan_index(self.current_scan_index)
            self.parent.on_select(self)
        else:
            self.deselect()