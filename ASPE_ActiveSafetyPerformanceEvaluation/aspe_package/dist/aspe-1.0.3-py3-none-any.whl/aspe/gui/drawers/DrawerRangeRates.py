from aspe.gui.drawers.DrawerLines import DrawerLines
import pyqtgraph as pg
import numpy as np


class DrawerRangeRates(DrawerLines):
    def __init__(self, parent, name: str, plot_item: pg.PlotItem, color: tuple, line_style: str, line_width: float):
        super().__init__(parent, name, plot_item, color, line_style, line_width)
        self.line_points = 2

    def set_data(self, data_df, vector_origin_x_signautre, vector_origin_y_signature, vector_magnitude_signature,
                 vector_orientation_signature):
        for scan_index, scan_df in data_df.groupby(by='scan_index'):
            df_indexes = scan_df.index.to_numpy()
            x_1 = scan_df.loc[:, vector_origin_x_signautre].to_numpy().astype(np.float32)
            y_1 = scan_df.loc[:, vector_origin_y_signature].to_numpy().astype(np.float32)
            magnitudes = scan_df.loc[:,  vector_magnitude_signature].to_numpy().astype(np.float32)
            orientations = scan_df.loc[:, vector_orientation_signature].to_numpy().astype(np.float32)

            magnitudes[magnitudes < -50] = 0
            x_2 = magnitudes * np.cos(orientations) * 0.3 + x_1
            y_2 = magnitudes * np.sin(orientations) * 0.3 + y_1

            nan_vec = np.full(shape=x_1.shape[0], fill_value=np.nan)

            x_data = np.vstack([x_1, x_2, nan_vec]).T.reshape(-1)
            y_data = np.vstack([y_1, y_2, nan_vec]).T.reshape(-1)

            self.x_data[scan_index] = x_data
            self.y_data[scan_index] = y_data

            nan_mask = np.isnan(x_data)
            connect_mask = ~(nan_mask | np.roll(nan_mask, -1))
            self.is_visible[scan_index] = connect_mask

            df_indexes_flat = np.tile(df_indexes, (3, 1)).T.reshape(-1)
            self.df_indexes[scan_index] = df_indexes_flat
