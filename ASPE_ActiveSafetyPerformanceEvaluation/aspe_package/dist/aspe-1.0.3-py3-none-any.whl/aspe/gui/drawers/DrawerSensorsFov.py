from aspe.gui.drawers.DrawerFilledPolygon import DrawerFilledPolygon
import pyqtgraph as pg
from PyQt5.QtGui import QColor


class DrawerSensorsFov(DrawerFilledPolygon):
    def __init__(self, parent, sensors_data, plot_item: pg.PlotItem, name: str):
        super().__init__(parent, name, plot_item, QColor(124,124,124))
        self.data_set = sensors_data

    def set_data(self, sensors_data):
        pass
