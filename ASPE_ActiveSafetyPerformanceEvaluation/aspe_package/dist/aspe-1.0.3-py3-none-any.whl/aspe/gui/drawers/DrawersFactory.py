from aspe.gui.drawers.DrawerBinaryClassification import DrawerBinaryClassification
from aspe.gui.drawers.DrawerDetToObjAssociation import DrawerDetToObjAssociation
from aspe.gui.drawers.DrawerRefToEstAssociation import DrawerRefToEstAssociation
from aspe.gui.drawers.DrawerRelevancy import DrawerRelevancy
from aspe.gui.drawers.DrawerSensorsFov import DrawerSensorsFov
from aspe.gui.drawers.DrawerDetections import DrawerDetections
from aspe.gui.drawers.DrawerObjects import DrawerObjects
from aspe.gui.drawers.DrawerHost import DrawerHost


class DrawersFactory:
    birds_eye_view = None

    @staticmethod
    def create_objects_drawer(data_source, extracted_objects, name):
        drawer = DrawerObjects(data_source, extracted_objects, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_detection_drawer(data_source, extracted_detections, name, rrate_signal_name, azimuth_signal_name):
        drawer = DrawerDetections(data_source, extracted_detections, DrawersFactory.birds_eye_view, name,
                                  rrate_signal_name, azimuth_signal_name)
        return drawer

    @staticmethod
    def create_host_drawer(data_source, extracted_host, name):
        drawer = DrawerHost(data_source, extracted_host, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_sensors_fov_drawer(parent_drawer, extracted_sensors, name):
        drawer = DrawerSensorsFov(parent_drawer, extracted_sensors, DrawersFactory.birds_eye_view, name)
        return drawer

    @staticmethod
    def create_det_to_obj_association_drawer(parent_drawer, associations, name):
        drawer = DrawerDetToObjAssociation(parent_drawer, name, DrawersFactory.birds_eye_view, associations)
        return drawer

    @staticmethod
    def create_est_to_ref_association_drawer(parent_drawer, associations, name):
        drawer = DrawerRefToEstAssociation(parent_drawer, name, DrawersFactory.birds_eye_view, associations)
        return drawer

    @staticmethod
    def create_not_relevant_objs_drawer(parent_drawer, not_relevant_objs, name):
        drawer = DrawerRelevancy(parent_drawer, name, DrawersFactory.birds_eye_view, not_relevant_objs)
        return drawer

    @staticmethod
    def create_binary_classification_drawer(parent_drawer, binary_classification, name):
        drawer = DrawerBinaryClassification(parent_drawer, binary_classification, DrawersFactory.birds_eye_view, name)
        return drawer
