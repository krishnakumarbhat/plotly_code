from aspe.gui.drawers.F360BmwMidDrawer import F360BmwMidDrawer
from aspe.gui.drawers.F360MudpDrawer import F360MudpDrawer
from aspe.gui.drawers.RtRangeDrawer import RtRangeDrawer
from aspe.gui.drawers.DrawerAspeResults import DrawerAspeResults
from aspe.gui.drawers.PandoraDrawer import PandoraDrawer
from aspe.extractors.Interfaces.ExtractedData import ExtractedData
from aspe.extractors.F360.DataSets.F360MudpExtractedData import F360MudpExtractedData
from aspe.extractors.F360.DataSets.F360Mf4BmwExtractedData import F360Mf4BmwExtractedData
from aspe.evaluation.RadarObjectsEvaluation.DataStructures.PEObjectsEvaluationOutput import PEObjectsEvaluationOutputSingleLog
from aspe.extractors.ReferenceExtractor.SDB.DataSets.SDB_ExtractedData import SDB_ExtractedData


class DrawersExtractedDataFactory:
    @staticmethod
    def create_extracted_data_drawer(drawers_controller, data_model):
        drawer = None
        if isinstance(data_model.extracted, F360MudpExtractedData):
            drawer = F360MudpDrawer(drawers_controller, data_model)
        elif isinstance(data_model.extracted, F360Mf4BmwExtractedData):
            drawer = F360BmwMidDrawer(drawers_controller, data_model)
        elif isinstance(data_model.extracted, SDB_ExtractedData):
            drawer = PandoraDrawer(drawers_controller, data_model)
        elif isinstance(data_model.extracted, ExtractedData):  # RT RANGE DATA
            drawer = RtRangeDrawer(drawers_controller, data_model)
        elif issubclass(type(data_model.extracted), PEObjectsEvaluationOutputSingleLog):
            drawer = DrawerAspeResults(drawers_controller, data_model)
        return drawer
