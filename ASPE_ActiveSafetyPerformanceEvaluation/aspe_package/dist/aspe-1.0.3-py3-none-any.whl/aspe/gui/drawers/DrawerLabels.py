from aspe.gui.drawers.abstract_drawers.DrawerLeaf import DrawerLeaf
import pyqtgraph as pg
import numpy as np
from aspe.gui.views.settings.DrawerLabelsSettingsWidget import DrawerLabelsSettingsWidget
from PyQt5.Qt import QFont
import pandas as pd


class DrawerLabels(DrawerLeaf):
    def __init__(self, parent, name: str, plot_item: pg.PlotItem, color: str):
        super().__init__(parent, name, plot_item, color)
        self.is_enabled = False
        self.labeled_signal = 'position_x'
        self.show_signal_name = True
        self.graphic_object = []  # place for TextItems
        self.labels_text = {}
        self.font_size = 8

    def set_data(self, signals_df, raw_signals_df, x_signal_signature, y_signal_signature):
        if raw_signals_df is not None:
            self.data_df = pd.concat([signals_df, raw_signals_df], axis=1)
        else:
            self.data_df = signals_df
        samples_per_scan = self.data_df.groupby(by='scan_index').count()
        max_count_per_scan = samples_per_scan.to_numpy().max()

        for _ in range(0, max_count_per_scan):
            text_item = pg.TextItem()
            self.plot_item.addItem(text_item)
            self.graphic_object.append(text_item)

        for scan_index, scan_df in self.data_df.groupby(by='scan_index'):
            self.x_data[scan_index] = scan_df.loc[:, x_signal_signature].to_numpy().astype(np.float32)
            self.y_data[scan_index] = scan_df.loc[:, y_signal_signature].to_numpy().astype(np.float32)
            self.df_indexes[scan_index] = scan_df.index.to_numpy()
        self.set_labels_text()

    def plot_scan_index(self, scan_index):
        if self.is_enabled:
            try:
                x = self.x_data[scan_index]
                y = self.y_data[scan_index]
                labels = self.labels_text[scan_index]
                for n in range(0, len(x)):
                    text_item = self.graphic_object[n]
                    text_item.setPos(y[n], x[n])
                    text_item.setText(labels[n])
                for n in range(len(x), len(self.graphic_object)):
                    self.graphic_object[n].setText('')
            except KeyError:
                pass

    def plot_empty_data(self):
        for text_item in self.graphic_object:
            text_item.setText('')

    def set_labels_text(self):
        for scan_index, scan_df in self.data_df.groupby(by='scan_index'):
            text_array = scan_df.loc[:, self.labeled_signal].to_numpy().astype(str)
            if self.show_signal_name:
                self.labels_text[scan_index] = [f'{self.labeled_signal}: {n}' for n in text_array]
            else:
                self.labels_text[scan_index] = text_array

    def create_settings_widget(self):
        self.settings_widget = DrawerLabelsSettingsWidget(self.name, self)
        self.settings_widget.fill_signals_combo_box(self.data_df.columns)
        return self.settings_widget

    def set_color(self, color):
        self.color = color
        for text_item in self.graphic_object:
            text_item.setColor(color)

    def set_show_name(self, show_name):
        self.show_signal_name = show_name
        self.set_labels_text()
        self.plot_scan_index(self.parent.current_scan_index)

    def set_labeled_signal(self, signal_signature):
        self.labeled_signal = signal_signature
        self.set_labels_text()
        self.plot_scan_index(self.parent.current_scan_index)

    def set_font_size(self, font_size):
        self.font_size = font_size
        for text_item in self.graphic_object:
            text_item.setFont(QFont('', font_size))

    def get_state(self):
        state = {
            'is_enabled': self.is_enabled,
            'color': self.color,
            'show_signal_name': self.show_signal_name,
            'font_size': self.font_size,
            'labeled_signal': self.labeled_signal
        }
        return state

    def load_state(self, state):
        is_enabled = state['is_enabled']
        if is_enabled:
            self.enable()
        else:
            self.disable()
        self.set_color(state['color'])
        self.set_labeled_signal(state['labeled_signal'])
        self.set_show_name(state['show_signal_name'])
        self.set_font_size(state['font_size'])
        self.settings_widget.load_state(state)