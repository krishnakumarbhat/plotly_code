from PyQt5.QtGui import QColor
from aspe.gui.drawers.DrawerLines import DrawerLines
import pyqtgraph as pg
import numpy as np


class DrawerDetToObjAssociation(DrawerLines):
    def __init__(self, parent, name: str, plot_item: pg.PlotItem, associated_data):
        super().__init__(parent, name, plot_item, QColor(255, 0, 0), '--', 1)
        self.line_points = 2
        self.set_data(associated_data)
        self.settings_widget = self.create_settings_widget()

    def set_data(self, data_df):
        for scan_index, scan_df in data_df.groupby(level=0):
            x_1 = scan_df.loc[:, 'position_x_obj'].to_numpy().astype(np.float32)
            y_1 = scan_df.loc[:, 'position_y_obj'].to_numpy().astype(np.float32)

            x_2 = scan_df.loc[:, 'position_x_det'].to_numpy().astype(np.float32)
            y_2 = scan_df.loc[:, 'position_y_det'].to_numpy().astype(np.float32)

            nan_vec = np.full(shape=x_1.shape[0], fill_value=np.nan)

            x_data = np.vstack([x_1, x_2, nan_vec]).T.reshape(-1)
            y_data = np.vstack([y_1, y_2, nan_vec]).T.reshape(-1)

            self.x_data[scan_index] = x_data
            self.y_data[scan_index] = y_data

            nan_mask = np.isnan(x_data)
            connect_mask = ~(nan_mask | np.roll(nan_mask, -1))
            self.is_visible[scan_index] = connect_mask

    def on_click(self, mouse_click_event):
        pass  # do nothing