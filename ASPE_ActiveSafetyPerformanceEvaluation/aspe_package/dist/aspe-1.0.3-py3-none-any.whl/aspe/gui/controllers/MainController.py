from aspe.gui.controllers.SignalPlotterController import SignalPlotterController
import os
from aspe.utilities.SupportingFunctions import load_from_pkl, save_to_pkl
import numpy as np
from aspe.gui.controllers.DataModelsController import DataModelsManager

SETTINGS_STATE_FILE_NAME = 'settings_state.pickle'


def get_user_data_dir():
    controller_file_dir = os.path.abspath(os.path.dirname(__file__))
    project_dir, _ = os.path.split(controller_file_dir)
    user_data_dir = os.path.join(project_dir, '.user_data')
    if not os.path.isdir(user_data_dir):
        os.mkdir(user_data_dir)
    return user_data_dir


class MainController:
    def __init__(self):
        self.data_models_controller = DataModelsManager()
        self.playback_controller = None
        self.drawers_controller = None
        self.selection_controller = None
        self.data_viewer_controller = None
        self.signal_plotter_controller = SignalPlotterController()
        self.current_scan_index = None
        self.is_playing = False
        self.scan_indexes = None
        self.user_data_dir = get_user_data_dir()

    def update_current_scan_index(self, scan_index):
        self.current_scan_index = scan_index
        self.selection_controller.update_current_scan_index(scan_index)
        self.signal_plotter_controller.update_current_scan_index(scan_index)
        self.drawers_controller.plot_scan_index(scan_index)

    def on_play(self):
        self.is_playing = True

    def on_stop(self):
        self.is_playing = False

    def update_scan_index_values(self, scan_indexes):
        vals = scan_indexes[~np.isnan(scan_indexes.astype(float))]
        self.scan_indexes = vals
        self.playback_controller.update_scan_index_values(vals)

    def on_select(self, selected_data_source, selected_data_set):
        self.selection_controller.on_select(selected_data_set)

    def on_deselect(self):
        self.selection_controller.on_deselect()

    def save_state(self):
        state = {
            'data_sources': self.drawers_controller.get_state()
        }
        state_file_path = os.path.join(self.user_data_dir, SETTINGS_STATE_FILE_NAME)
        save_to_pkl(state, state_file_path)
        return state

    def on_close(self):
        self.save_state()

    def load_state(self):
        state_file_path = os.path.join(self.user_data_dir, SETTINGS_STATE_FILE_NAME)
        if os.path.isfile(state_file_path):
            state = load_from_pkl(state_file_path)
            state_data_sources = state['data_sources']
            self.drawers_controller.load_state(state_data_sources)

    def load_data_using_source_info(self, source_info):
        data_model = self.data_models_controller.load_data_using_source_info(source_info)
        self.drawers_controller.add_drawer(data_model)
        self.data_viewer_controller.add_data_model(data_model)

    def remove_data(self, source_info):
        data_model_to_remove = self.data_models_controller.get_model_using_source_info(source_info)
        self.drawers_controller.remove_drawer_using_data_model(data_model_to_remove)
        self.data_viewer_controller.remove_data_model(data_model_to_remove)

    def remove_all_data(self):
        self.drawers_controller.remove_all_drawers()
        self.data_viewer_controller.remove_all_data()