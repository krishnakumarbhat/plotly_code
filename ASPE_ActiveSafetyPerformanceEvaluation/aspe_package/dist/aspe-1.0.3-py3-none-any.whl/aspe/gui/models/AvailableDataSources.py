import pandas as pd
from os import path
import glob
from aspe.gui.models.DataSourceInfo import DataSourceInfo


class AvailableDataSources:
    def __init__(self, log_path):
        self.log_path = log_path
        self.sources_info = pd.DataFrame(columns=['pickle_path', 'root_folder', 'suffix', 'type'])
        self._fill_sources_info()

    def _fill_sources_info(self):
        pickle_paths = self._find_pickle_paths()
        for pickle_path in pickle_paths:
            root_folder = pickle_path.split('\\')[-2]
            if '_f360_mudp_extracted' in pickle_path:
                suffix = '_f360_mudp_extracted'
                type = 'F360 .mudp data'
            elif '_f360_mf4_bmw_mid_extracted' in pickle_path:
                suffix = '_f360_mf4_bmw_mid_extracted'
                type = 'F360 .mf4 BMW mid data'
            elif '_rt_range_3000_dvl_extracted' in pickle_path:
                suffix = '_rt_range_3000_dvl_extracted'
                type = 'RTRange3000 .dvl data'
            elif '_rt_range_3000_mdf_extracted' in pickle_path:
                suffix = '_rt_range_mdf_dvl_extracted'
                type = 'RTRange3000 .mf4 data'
            elif 'pe_output' in pickle_path:
                suffix = '_pe_output.pickle'
                type = 'ASPE output'
            elif '_sdb_extracted' in pickle_path:
                suffix = '_sdb_extracted'
                type = 'Pandora SDB data'
            else:
                continue
            self.sources_info = self.sources_info.append({'pickle_path': pickle_path,
                                                          'root_folder': root_folder,
                                                          'suffix': suffix,
                                                          'type': type}, ignore_index=True)

    def _find_pickle_paths(self):
        dir_path, log_name = path.split(self.log_path)
        log_wo_ext, log_ext = path.splitext(log_name)
        pickle_files_paths = glob.glob(f'{dir_path}\\**\\{log_wo_ext}*.pickle', recursive=True)
        pickle_files_paths = [p.replace('/', '\\')for p in pickle_files_paths]
        return pickle_files_paths

    def get_source_info_using_dict(self, source_info_dict):
        root_folder = self.sources_info.loc[:, 'root_folder']
        suffix = self.sources_info.loc[:, 'suffix']
        root_folder_mask = root_folder == source_info_dict['root_folder']
        suffix_mask = suffix == source_info_dict['suffix']
        source = self.sources_info.loc[root_folder_mask & suffix_mask, :]
        data_source_info = DataSourceInfo(source.pickle_path.iat[0], source.root_folder.iat[0], source.suffix.iat[0], source.type.iat[0])
        return data_source_info
