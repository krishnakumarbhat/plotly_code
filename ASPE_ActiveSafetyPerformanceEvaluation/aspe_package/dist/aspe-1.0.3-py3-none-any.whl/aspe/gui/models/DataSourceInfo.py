from dataclasses import dataclass


@dataclass
class DataSourceInfo:
    pickle_path: str
    root_folder: str
    suffix: str
    type: str

    def __eq__(self, other):
        is_equal = self.pickle_path == other.pickle_path and  \
                   self.root_folder == other.root_folder and \
                   self.suffix == other.suffix and self.type == other.type
        return is_equal