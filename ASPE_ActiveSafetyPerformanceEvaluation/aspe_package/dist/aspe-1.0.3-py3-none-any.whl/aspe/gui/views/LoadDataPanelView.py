from aspe.gui.views.uis.load_data_panel import Ui_LoadDataPanel
from PyQt5.Qt import QFileDialog
from PyQt5.QtWidgets import QMessageBox
from os import path


class LoadDataPanelView(Ui_LoadDataPanel):
    def __init__(self):
        super().__init__()
        self.setupUi()
        self.connect_signals()
        self.last_dir = 'c:\\'
        self.load_data_panel_controler = None
        self.data_sources_table.parent_widget = self
        self.setAcceptDrops(True)

    def connect_signals(self):
        self.open_file_dialog_button.clicked.connect(self.on_load_data_button_click)
        self.log_path_combo_box.lineEdit().returnPressed.connect(self.on_log_path_changed)

    def on_load_data_button_click(self):
        log_path, filter = QFileDialog.getOpenFileName(self, 'Open file', self.last_dir, "Log files (*.dvl *.mudp *.mf4)")
        if len(log_path) != 0:
            dir_path, log_name = path.split(log_path)
            self.last_dir = dir_path
            self.log_path_combo_box.setCurrentText(log_path)
            self.on_log_path_changed()

    def on_log_path_changed(self):
        current_log_path = self.log_path_combo_box.currentText().replace('\'', '').replace('\"', '')
        if self.load_data_panel_controler.curr_log_path != current_log_path:
            if self.load_data_panel_controler.is_valid_file_path(current_log_path):
                try:
                    self.load_data_panel_controler.main_controller.remove_all_data()
                    data_sources = self.load_data_panel_controler.load_data_sources(current_log_path)
                    self.set_data_sources(data_sources)
                except FileNotFoundError:
                    msg = QMessageBox()
                    msg.setIcon(QMessageBox.Critical)
                    msg.setText("Log file load error")
                    msg.setInformativeText('Given log file path does not exist')
                    msg.setWindowTitle("Error")
                    msg.exec_()

    def set_data_sources(self, data_sources):
        self.data_sources_table.clear_sources()
        for row, data_source in data_sources.iterrows():
            self.data_sources_table.add_row(data_source)

    def on_load_data_from_source(self, source_info_dict):
        return self.load_data_panel_controler.on_load_data_from_source(source_info_dict)

    def clear_data_using_source_info_dict(self, source_info_dict):
        self.load_data_panel_controler.clear_data_using_source_info_dict(source_info_dict)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            url_path = url.toLocalFile()
            if path.isfile(url_path):
                self.log_path_combo_box.setCurrentText(url_path)
                self.on_log_path_changed()

    def clear_sources(self):
        self.data_sources_table.clear_sources()
        self.load_data_panel_controler.clear_sources()