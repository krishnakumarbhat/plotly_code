from aspe.extractors.Interfaces.IDataSet import IDataSet
import pandas as pd


class PESingleObjects(IDataSet):
    '''
    Class which stores tracker objects evaluation results for reference or estimated data. Each row contains single
    object data within single time instance.
    '''

    def __init__(self):
        super().__init__()
        signal_names = [
            'relevancy_flag',
            'is_associated',
            'binary_classification'
        ]
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=signal_names)], sort=False)

    def get_base_name(self):
        return 'PESingleObjects'
