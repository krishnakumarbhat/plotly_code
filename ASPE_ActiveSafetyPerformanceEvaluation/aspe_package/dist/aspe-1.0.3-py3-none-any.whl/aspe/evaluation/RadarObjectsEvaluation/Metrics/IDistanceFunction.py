from abc import ABC, abstractmethod
import pandas as pd


class IDistanceFunction(ABC):

    def __init__(self, *args, **kwargs):
        """
        Init function realise class configuration: all distance function parameters should be set here.

        :param args: any parameters needed for distance calculation
        :param kwargs: same as above
        """
        pass

    @abstractmethod
    def calculate_distance(self, data_a: pd.DataFrame, data_b: pd.DataFrame, *args, **kwargs) -> pd.Series:
        """
        Abstract function which calculates distance between two data frames using specified columns. Must be implemented
        in child class.

        :param data_a: DataFrame for which metric should be calculated, (should be same shape as data_b)
        :type data_a: pandas.DataFrame
        :param data_b: DataFrame for which metric should be calculated (should be same shape as data_a)
        :type data_b: pandas.DataFrame
        :param args:
        :param kwargs:
        :return: pandas.Series: - series with the same length as input data frame with distance values
        """
        raise NotImplementedError('This method is an abstract -> please overwrite it or use or use one of the existing classes')