from abc import ABC, abstractmethod

import pandas as pd


class IAssociation(ABC):
    @abstractmethod
    def associate(self, pe_pairs: pd.DataFrame) -> pd.Series:
        pass
