from .deviation import *
from .nees import *
from .deviation.deviation_cr2cr import PositionDeviationCR2CR
DEFAULT_PAIRS_FEATURES_LIST = [
    PositionDeviationCR2CR(),
    SpeedDeviation(),
    OrientationDeviation(),
    VelocityDeviationR2R(),
    VelocityRelativeDeviationR2R(),
    AccelerationDeviationR2R(),
    AccelerationRelativeDeviationR2R(),
    DimensionsDeviation(),
    YawRateDeviation()
    ]

EXTENDED_PAIRS_FEATURES_LIST = [
    *DEFAULT_PAIRS_FEATURES_LIST,
    PositionNeesValuesR2R(),
    VelocityNeesValuesR2R(),
]

C2C_DEVIATION_METHOD_LIST = [
    PositionDeviationC2C(),
    ]
CR2CR_DEVIATION_METHOD_LIST = [
    PositionDeviationCR2CR(),
    ]
R2R_DEVIATION_METHOD_LIST = [
    PositionDeviationR2R(),
    VelocityDeviationR2R(),
    ]
