import pandas as pd

from aspe.evaluation.RadarObjectsEvaluation.Association import IAssociation


class SingleInstanceNN(IAssociation):
    def __init__(self, assoc_distance_threshold: float = 3.0):
        super().__init__()
        self.assoc_distance_threshold = assoc_distance_threshold

    def associate(self, pe_pairs: pd.DataFrame) -> pd.Series:
        is_associated_series = pd.Series(False, index=pe_pairs.index)
        if not pe_pairs.empty:
            pe_pairs_local = pe_pairs.loc[:, ['scan_index', 'unique_id_ref', 'association_distance']]
            columns_to_group = ['scan_index', 'unique_id_ref']
            min_distances_multi_index_array = pe_pairs_local.groupby(by=columns_to_group).idxmin().values
            min_distances_multi_index = pd.Index(min_distances_multi_index_array)
            is_associated_series[min_distances_multi_index] = True

            over_thr_mask = pe_pairs_local.loc[:, 'association_distance'] > self.assoc_distance_threshold
            is_associated_series.loc[over_thr_mask] = False
        return is_associated_series


if __name__ == "__main__":
    test_df = pd.DataFrame({
        'scan_index': [0, 0, 1, 1],
        'unique_id_ref': [0, 0, 0, 0],
        'unique_id_est': [1, 2, 1, 2],
        'association_distance': [0.2, 1, 0.2, 1]
    })
    test_df.drop([0], inplace=True)
    association = SingleInstanceNN(0.8)
    association.associate(test_df)
