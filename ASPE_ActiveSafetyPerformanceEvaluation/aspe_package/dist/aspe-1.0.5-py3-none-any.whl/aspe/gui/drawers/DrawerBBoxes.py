from aspe.gui.drawers.DrawerLines import DrawerLines
import pyqtgraph as pg
import numpy as np
from aspe.gui.utilities.calc_bbox_corners import calc_bbox_corners, flatten_single_scan_corners_data
import pandas as pd


class DrawerBBoxes(DrawerLines):
    def __init__(self, parent, name: str, plot_item: pg.PlotItem, color: tuple, line_style: str, line_width: float):
        super().__init__(parent, name, plot_item, color, line_style, line_width)
        self.line_points = 5

    def set_data(self, data_df, center_x_signature, center_y_signature, orientation_signature, length_signature, width_signature):
        corners_x, corners_y = calc_bbox_corners(data_df.loc[:, center_x_signature], data_df.loc[:, center_y_signature],
                                    data_df.loc[:, orientation_signature],
                                    data_df.loc[:, length_signature], data_df.loc[:, width_signature])
        scan_index_raw = data_df.loc[:, 'scan_index'].to_numpy()
        df_indexes_raw = data_df.index.to_numpy()
        scan_index_repeated = np.tile(scan_index_raw, (6, 1)).T.reshape(-1)
        df_index_repeated = np.tile(df_indexes_raw, (6, 1)).T.reshape(-1)

        corners = pd.DataFrame({'corners_x': corners_x.astype(np.float32),
                                  'corners_y': corners_y.astype(np.float32),
                                  'scan_index': scan_index_repeated,
                                  'df_indexes': df_index_repeated})

        for scan_index, scan_df in corners.groupby(by='scan_index'):
            self.x_data[scan_index] = scan_df.loc[:, 'corners_x'].to_numpy()
            self.y_data[scan_index] = scan_df.loc[:, 'corners_y'].to_numpy()
            nan_mask = np.isnan(self.x_data[scan_index])
            connect_mask = ~(nan_mask | np.roll(nan_mask, -1))
            self.is_visible[scan_index] = connect_mask
            self.df_indexes[scan_index] = scan_df.loc[:, 'df_indexes'].to_numpy()
