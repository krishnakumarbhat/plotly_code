# coding=utf-8
"""
F360 Radar's Detections Data Set
"""
from aspe.extractors.Interfaces.IRadarDetections import IRadarDetections
import pandas as pd
from enum import Enum


class F360RadarDetections(IRadarDetections):
    """
    F360 Radar Detections dataset class
    """
    def __init__(self):
        super().__init__()
        signal_names = {
            'raw_det_id': int,
            'assigned_obj_id': int,
            'cluster_id': int,
            'range_rate_comp': float,
            'range_rate_dealiased': float,
            'motion_status': Enum,
            'wheel_spin_status': Enum,
            'f_dealiased': bool
        }

        signals_info_local = pd.DataFrame({'signal_name': list(signal_names.keys()),
                                           'signal_type': list(signal_names.values())})
        self.signals_info = self.signals_info.append(signals_info_local)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=list(signal_names.keys()))], sort=False)


if __name__ == '__main__':
    f360_dets = F360RadarDetections()
