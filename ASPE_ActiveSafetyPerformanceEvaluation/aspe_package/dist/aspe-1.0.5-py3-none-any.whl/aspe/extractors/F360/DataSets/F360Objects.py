# coding=utf-8
"""
F360 Reduced Objects Data Set
"""
from aspe.extractors.Interfaces.IObjects import IObjects
import pandas as pd
from enum import Enum


class F360Objects(IObjects):
    """
    F360 Reduced Objects Data Set class
    """
    def __init__(self):
        super().__init__()
        signal_names = {
            'filter_type': Enum,
            'tracker_id': int,
            'status': int,  # TODO change this to enum
            'curvature': float,
            'confidence_level': float,
            'n_dets': int,
            'f_moving': bool,
            'f_moveable': bool,
            'f360_object_class': int,  # TODO change this to enum
            # TODO: CEA-148; due to disagreement of handling - skip this
            #'supplemental_state_covariance',
            #'state_variance'
        }
        signals_info_local = pd.DataFrame({'signal_name': list(signal_names.keys()),
                                           'signal_type': list(signal_names.values())})
        self.signals_info = self.signals_info.append(signals_info_local)
        self.signals = pd.concat([self.signals, pd.DataFrame(columns=list(signal_names.keys()))], sort=False)
