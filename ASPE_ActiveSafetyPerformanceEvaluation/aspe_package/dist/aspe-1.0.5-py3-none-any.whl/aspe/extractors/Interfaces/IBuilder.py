# coding=utf-8
"""
Main Builder interface. All project builders shall inherit after IBuilder
"""
from abc import ABC, abstractmethod

from aspe.extractors.Interfaces import IDataSet


class IBuilder(ABC):
    """
    Builder interface. This class should be overwritten by any project builder
    :parsed_data: data from parsers
    """
    def __init__(self, parsed_data, **kwargs):
        self._parsed_data = parsed_data
        self.data_set: IDataSet = None

    @abstractmethod
    def build(self):
        """
        Main builder method for data set creation
        :return: filled (extracted) data set
        """
        return self.data_set
