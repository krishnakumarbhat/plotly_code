class Constants:
   __slots__ = ()
   M_2_KM = 0.001
   EPSILON = 0.0000001
   SCALE_P21_TO_FLOAT = (4.768371582e-07)