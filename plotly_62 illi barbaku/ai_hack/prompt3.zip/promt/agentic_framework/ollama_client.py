
import os
from openai import OpenAI

class LLM_Client:
    def __init__(self, model_name: str, endpoint: str):
        self.model_name = model_name
        self.base_url   = endpoint

    def send_prompt(self, content: str, prompt: str) -> str:

        client = OpenAI(
            api_key="sk-hackahton",
            base_url= self.base_url 
        )

        response = client.completions.create(
            model  = self.model_name,
            prompt = prompt,
            max_tokens=512,
            temperature=0.5
        )
        return response.choices[0].text.strip()
    