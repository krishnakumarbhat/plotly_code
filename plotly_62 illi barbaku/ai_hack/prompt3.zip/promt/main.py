import os
import os
import sys
from agentic_framework.ollama_client import LLM_Client
from rag_pipeline.rag_processor import RAGProcessor

# TODO: This script's functionality should be integrated into the new architecture.
# - File reading and processing could be part of the 'agentic_framework' or triggered via 'backend' API.
# - The 'send_to_ollama_deepsek_r1' function should be implemented within the 'rag_pipeline' or 'agentic_framework'.

def main(txt_file_path: str, prompt: str):
    """
    Main function to process files using RAG and an LLM  model.

    Args:
        txt_file_path (str): Path to the text file containing a list of file paths to process.
        prompt (str): The prompt to use with the LLM model.

    Returns:
        list: A list of tuples, where each tuple contains the file path and the model's response.
    """

    BASE_URL = "http://10.60.16.12:8000/v1"
    MODEL = "microsoft/phi-1_5"

    LLM_client = LLM_Client( MODEL, BASE_URL ) # You can specify a model name if needed, e.g., OllamaClient(model_name='your_model')
    rag_processor = RAGProcessor(LLM_client)

    responses = rag_processor.process_rag(txt_file_path, prompt)
    return responses


if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("Usage: python main.py <file_paths_txt> ")
        sys.exit(1)
    txt_file_path = sys.argv[1]
   # prompt = "give me the detail what is the equation of sel attention transfomer"
    prompt = "in given xml give how many High is present "
    responses = main(txt_file_path, prompt)
    for file_path, response in responses:
        print(f"File: {file_path}\nResponse: {response}\n")
