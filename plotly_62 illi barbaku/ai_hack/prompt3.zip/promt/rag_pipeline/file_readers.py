import os
from abc import ABC, abstractmethod
from docx import Document
import xml.etree.ElementTree as ET

class FileReader(ABC):
    @abstractmethod
    def read(self, file_path: str) -> str:
        pass

class DocxReader(FileReader):
    def read(self, file_path: str) -> str:
        doc = Document(file_path)
        full_text = []
        for para in doc.paragraphs:
            full_text.append(para.text)
        return '\n'.join(full_text)

class XmlReader(FileReader):
    def read(self, file_path: str) -> str:
        tree = ET.parse(file_path)
        root = tree.getroot()
        return ET.tostring(root, encoding='unicode')

class FileReaderFactory:
    def get_reader(self, file_path: str) -> FileReader:
        if file_path.endswith('.docx'):
            return DocxReader()
        elif file_path.endswith('.xml'):
            return XmlReader()
        else:
            raise ValueError(f"Unsupported file type: {file_path}")