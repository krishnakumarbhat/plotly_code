import os
from rag_pipeline.file_readers import FileReaderFactory
from agentic_framework.ollama_client import LLM_Client

class RAGProcessor:
    def __init__(self, ollama_client: LLM_Client):
        self.file_reader_factory = FileReaderFactory()
        self.ollama_client = ollama_client

    def read_file_paths(self, txt_file_path: str) -> list[str]:
        with open(txt_file_path, 'r') as file:
            paths = [line.strip() for line in file if line.strip()]
        return paths

    def process_rag(self, txt_file_path: str, prompt: str) -> list[tuple[str, str]]:
        file_paths = self.read_file_paths(txt_file_path)
        results = []
        for file_path in file_paths:
            if not os.path.exists(file_path):
                print(f"File not found: {file_path}")
                continue
            try:
                reader = self.file_reader_factory.get_reader(file_path)
                content = reader.read(file_path)
                response = self.ollama_client.send_prompt(content, prompt)
                results.append((file_path, response))
            except ValueError as e:
                print(f"Error processing {file_path}: {e}")
            except Exception as e:
                print(f"An unexpected error occurred with {file_path}: {e}")
        return results