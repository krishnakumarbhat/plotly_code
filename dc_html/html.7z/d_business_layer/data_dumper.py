import h5py
import numpy as np
import os
import logging
from typing import Dict, List, Any
from c_data_storage.data_model_storage import DataModelStorage

class DataDumper:
    """
    Utility class for dumping specific datasets from HDF files to text files.
    Extracts data from Tracker_Information/OLP and OSI_Ground_Truth/Object datasets.
    Stores data in DataModelStorage format before dumping.
    """
    
    def __init__(self, hdf_file_path: str, output_dir: str = "html"):
        """
        Initialize the DataDumper.
        
        Args:
            hdf_file_path: Path to the HDF file
            output_dir: Directory to save output files
        """
        self.hdf_file_path = hdf_file_path
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)
        
        # Initialize DataModelStorage instances
        self.tracker_storage = DataModelStorage()
        self.osi_storage = DataModelStorage()
        
    def dump_tracker_data(self) -> bool:
        """
        Dump Tracker_Information/OLP datasets to Track.txt using DataModelStorage format
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with h5py.File(self.hdf_file_path, 'r') as f:
                if 'Tracker_Information' not in f or 'OLP' not in f['Tracker_Information']:
                    self.logger.warning("Tracker_Information/OLP not found in HDF file")
                    return False
                
                olp_group = f['Tracker_Information']['OLP']
                tracker_datasets = ['vcs_accel_x', 'vcs_accel_y', 'vcs_pos_x', 'vcs_pos_y', 'vcs_vel_x', 'vcs_vel_y']
                
                # Check if all required datasets exist
                missing_datasets = [ds for ds in tracker_datasets if ds not in olp_group]
                if missing_datasets:
                    self.logger.warning(f"Missing datasets in Tracker_Information/OLP: {missing_datasets}")
                
                # Initialize storage with scan indices
                # For tracker data, we'll use row indices as scan indices
                first_dataset = None
                for dataset_name in tracker_datasets:
                    if dataset_name in olp_group:
                        first_dataset = olp_group[dataset_name]
                        break
                
                if first_dataset is None:
                    self.logger.error("No valid datasets found in Tracker_Information/OLP")
                    return False
                
                # Create scan indices based on the dataset shape
                scan_indices = list(range(first_dataset.shape[0]))
                self.tracker_storage.initialize(scan_indices, "Tracker", "OLP")
                self.tracker_storage.init_parent("OLP")
                
                # Extract and store data
                for dataset_name in tracker_datasets:
                    if dataset_name in olp_group:
                        dataset = olp_group[dataset_name][()]
                        self.tracker_storage.set_value(dataset, dataset_name, "OLP")
                
                # Save to file in DataModelStorage format
                output_file = os.path.join(self.output_dir, "Track.txt")
                self._save_data_model_storage_to_file(self.tracker_storage, output_file, "Tracker Information - OLP")
                
                self.logger.info(f"Successfully dumped Tracker_Information/OLP data to {output_file}")
                return True
                
        except Exception as e:
            self.logger.error(f"Error dumping Tracker_Information data: {e}")
            return False
    
    def dump_osi_data(self) -> bool:
        """
        Dump OSI_Ground_Truth/Object datasets to OSI track.txt using DataModelStorage format
        
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            with h5py.File(self.hdf_file_path, 'r') as f:
                if 'OSI_Ground_Truth' not in f or 'Object' not in f['OSI_Ground_Truth']:
                    self.logger.warning("OSI_Ground_Truth/Object not found in HDF file")
                    return False
                
                object_group = f['OSI_Ground_Truth']['Object']
                osi_datasets = ['length', 'speed', 'vcs_lat_accel', 'vcs_lat_posn', 'vcs_lat_vel', 
                               'vcs_long_accel', 'vcs_long_posn', 'vcs_long_vel']
                
                # Check if all required datasets exist
                missing_datasets = [ds for ds in osi_datasets if ds not in object_group]
                if missing_datasets:
                    self.logger.warning(f"Missing datasets in OSI_Ground_Truth/Object: {missing_datasets}")
                
                # Initialize storage with scan indices
                # For OSI data, we'll use row indices as scan indices
                first_dataset = None
                for dataset_name in osi_datasets:
                    if dataset_name in object_group:
                        first_dataset = object_group[dataset_name]
                        break
                
                if first_dataset is None:
                    self.logger.error("No valid datasets found in OSI_Ground_Truth/Object")
                    return False
                
                # Create scan indices based on the dataset shape
                scan_indices = list(range(first_dataset.shape[0]))
                self.osi_storage.initialize(scan_indices, "OSI", "Object")
                self.osi_storage.init_parent("Object")
                
                # Extract and store data
                for dataset_name in osi_datasets:
                    if dataset_name in object_group:
                        dataset = object_group[dataset_name][()]
                        self.osi_storage.set_value(dataset, dataset_name, "Object")
                
                # Save to file in DataModelStorage format
                output_file = os.path.join(self.output_dir, "OSI track.txt")
                self._save_data_model_storage_to_file(self.osi_storage, output_file, "OSI Ground Truth - Object")
                
                self.logger.info(f"Successfully dumped OSI_Ground_Truth/Object data to {output_file}")
                return True
                
        except Exception as e:
            self.logger.error(f"Error dumping OSI_Ground_Truth data: {e}")
            return False
    
    def _save_data_model_storage_to_file(self, storage: DataModelStorage, output_file: str, header: str):
        """
        Save DataModelStorage data to a text file with proper formatting.
        
        Args:
            storage: DataModelStorage instance containing the data
            output_file: Path to output file
            header: Header text for the file
        """
        with open(output_file, 'w') as f:
            # Write header
            f.write(f"# {header}\n")
            f.write(f"# Generated from: {self.hdf_file_path}\n")
            f.write(f"# DataModelStorage Format\n")
            f.write("#" + "="*80 + "\n\n")
            
            # Write storage structure information
            f.write("# DataModelStorage Structure:\n")
            f.write(f"# - Number of scan indices: {len(storage._data_container)}\n")
            f.write(f"# - Number of signals: {len(storage._signal_to_value)}\n")
            f.write(f"# - Parent counter: {storage._parent_counter}\n")
            f.write(f"# - Child counter: {storage._child_counter}\n")
            f.write(f"# - Stream name: {getattr(storage, 'stream_name', 'N/A')}\n\n")
            
            # Write signal mappings
            f.write("# Signal Mappings:\n")
            f.write("# _signal_to_value:\n")
            for signal_name, value in storage._signal_to_value.items():
                f.write(f"#   {signal_name}: {value}\n")
            f.write("\n")
            
            f.write("# _value_to_signal:\n")
            for value, signal_name in storage._value_to_signal.items():
                f.write(f"#   {value}: {signal_name}\n")
            f.write("\n")
            
            # Write data container structure
            f.write("# Data Container Structure:\n")
            f.write(f"# Scan indices: {sorted(storage._data_container.keys())}\n\n")
            
            # Write detailed data for each scan index
            for scan_idx in sorted(storage._data_container.keys()):
                f.write(f"# Scan Index {scan_idx}:\n")
                data_list = storage._data_container[scan_idx]
                
                if not data_list:
                    f.write(f"#   Empty data\n")
                else:
                    for group_idx, group_data in enumerate(data_list):
                        f.write(f"#   Group {group_idx}:\n")
                        if isinstance(group_data, list):
                            for item_idx, item in enumerate(group_data):
                                if isinstance(item, np.ndarray):
                                    # Show non-zero values for cleaner output
                                    non_zero_indices = np.nonzero(item)[0]
                                    if len(non_zero_indices) > 0:
                                        f.write(f"#     Item {item_idx}: ")
                                        for idx in non_zero_indices:
                                            f.write(f"Col{idx}={item[idx]:.6f} ")
                                        f.write("\n")
                                    else:
                                        f.write(f"#     Item {item_idx}: All zeros\n")
                                else:
                                    f.write(f"#     Item {item_idx}: {item}\n")
                        else:
                            f.write(f"#     {group_data}\n")
                f.write("\n")
            
            # Write summary statistics
            f.write("# Summary Statistics:\n")
            total_data_points = sum(len(data_list) for data_list in storage._data_container.values())
            f.write(f"# - Total data points: {total_data_points}\n")
            f.write(f"# - Average data points per scan: {total_data_points / len(storage._data_container) if storage._data_container else 0:.2f}\n")
            f.write("\n")
            
            # Write signal information
            f.write("# Signal Information:\n")
            for signal_name in storage._signal_to_value.keys():
                if signal_name in storage._value_to_signal.values():
                    f.write(f"# - {signal_name}: Available\n")
                else:
                    f.write(f"# - {signal_name}: Not found in value mappings\n")
    
    def dump_all_data(self) -> Dict[str, bool]:
        """
        Dump both Tracker_Information and OSI_Ground_Truth data.
        
        Returns:
            Dict[str, bool]: Dictionary with results for each dump operation
        """
        results = {}
        results['tracker'] = self.dump_tracker_data()
        results['osi'] = self.dump_osi_data()
        return results 