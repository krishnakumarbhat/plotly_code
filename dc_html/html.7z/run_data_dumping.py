#!/usr/bin/env python3
"""
Minimal script to run data dumping functionality.
Extracts and dumps specified datasets from HDF files using DataModelStorage format.
"""

import os
import sys
import logging
from d_business_layer.data_dumper import DataDumper

def main():
    """Main function to run data dumping."""
    # Setup logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    
    # Configuration
    hdf_file = "hdf_dc.h5"
    output_dir = "html"
    
    # Check if HDF file exists
    if not os.path.exists(hdf_file):
        logger.error(f"HDF file not found: {hdf_file}")
        return False
    
    logger.info(f"Processing HDF file: {hdf_file}")
    
    try:
        # Create DataDumper and dump all data
        dumper = DataDumper(hdf_file, output_dir)
        results = dumper.dump_all_data()
        
        # Report results
        success = all(results.values())
        if success:
            logger.info("✅ All data dumped successfully!")
        else:
            logger.error("❌ Some data dumping operations failed")
        
        return success
        
    except Exception as e:
        logger.error(f"Error during data dumping: {e}")
        return False

if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1) 