# Dictionary of signal patterns for data extraction
Gen7V1_V2 = {
    "Tracker_Information": {
        "vcs_accel_x": {},
        "vcs_accel_y": {},
        "vcs_pos_x": {},
        "vcs_pos_y": {},
        "vcs_vel_x": {},
        "vcs_vel_y": {}
    },
    "OSI_Ground_Truth": {
        "length": {},
        "speed": {},
        "vcs_lat_accel": {},
        "vcs_lat_posn": {},
        "vcs_lat_vel": {},
        "vcs_long_accel": {},
        "vcs_long_posn": {},
        "vcs_long_vel": {}
    }
}
